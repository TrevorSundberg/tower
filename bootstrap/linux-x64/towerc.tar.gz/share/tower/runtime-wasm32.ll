; ModuleID = '/cache/defer-stage1/guest-wasm32-unbound.ll'
source_filename = "Tower"
target datalayout = "e-m:e-p:32:32-p10:8:8-p20:8:8-i64:64-n32:64-S128-ni:1:10:20"
target triple = "wasm32-unknown-unknown"

@0 = private unnamed_addr constant [17 x i8] c"Division by zero\00", align 1
@1 = private unnamed_addr constant [67 x i8] c"Numeric conversion out of range; use bits for bit reinterpretation\00", align 1
@2 = private unnamed_addr constant [17 x i8] c"Division by zero\00", align 1
@3 = private unnamed_addr constant [17 x i8] c"Division by zero\00", align 1
@4 = private unnamed_addr constant [17 x i8] c"Division by zero\00", align 1
@5 = private unnamed_addr constant [17 x i8] c"Division by zero\00", align 1
@6 = private unnamed_addr constant [67 x i8] c"Numeric conversion out of range; use bits for bit reinterpretation\00", align 1
@7 = private unnamed_addr constant [67 x i8] c"Numeric conversion out of range; use bits for bit reinterpretation\00", align 1
@8 = private unnamed_addr constant [67 x i8] c"Numeric conversion out of range; use bits for bit reinterpretation\00", align 1
@9 = private unnamed_addr constant [67 x i8] c"Numeric conversion out of range; use bits for bit reinterpretation\00", align 1
@10 = private unnamed_addr constant [67 x i8] c"Numeric conversion out of range; use bits for bit reinterpretation\00", align 1
@11 = private unnamed_addr constant [17 x i8] c"Division by zero\00", align 1
@12 = private unnamed_addr constant [67 x i8] c"Numeric conversion out of range; use bits for bit reinterpretation\00", align 1
@__heap_base = external global i8
@tower.runtime.wasm.heap = private global [3 x i32] zeroinitializer, align 4

declare void @tower_print(i32, i64, i32) #0

declare void @tower_trap(ptr, i32) #1

define internal i8 @tower.fn.guest_runtime_product(i32 %0, i32 %1) {
entry:
  %count = alloca i32, align 4
  %size = alloca i32, align 4
  %maximum = alloca i32, align 4
  %sized = alloca i8, align 1
  %limit = alloca i32, align 4
  %overflow = alloca i8, align 1
  %"control value 156" = alloca ptr, align 4
  %"control value 157" = alloca i32, align 4
  %"control value 158" = alloca i32, align 4
  %"control value 159" = alloca i32, align 4
  %"control value 160" = alloca i8, align 1
  %"control value 161" = alloca i8, align 1
  %"control value 162" = alloca i32, align 4
  %"control value 163" = alloca i32, align 4
  %"control value 164" = alloca i32, align 4
  %"control value 165" = alloca i32, align 4
  %"control value 166" = alloca i32, align 4
  %"control value 167" = alloca i8, align 1
  %"control value 168" = alloca i8, align 1
  store i32 %0, ptr %count, align 1
  store i32 %1, ptr %size, align 1
  store i32 0, ptr %maximum, align 1
  store ptr %maximum, ptr %"control value 156", align 1
  %2 = load ptr, ptr %"control value 156", align 1
  %3 = load i32, ptr %2, align 1
  store i32 %3, ptr %"control value 157", align 1
  %4 = load i32, ptr %"control value 157", align 1
  %5 = sub i32 %4, 1
  store i32 %5, ptr %"control value 158", align 1
  %6 = load ptr, ptr %"control value 156", align 1
  %7 = load i32, ptr %"control value 158", align 1
  store i32 %7, ptr %6, align 1
  %8 = load i32, ptr %size, align 1
  store i32 %8, ptr %"control value 159", align 1
  %9 = load i32, ptr %"control value 159", align 1
  %10 = icmp ne i32 %9, 0
  %11 = zext i1 %10 to i8
  store i8 %11, ptr %"control value 160", align 1
  %12 = load i8, ptr %"control value 160", align 1
  store i8 %12, ptr %sized, align 1
  %13 = load i8, ptr %sized, align 1
  store i8 %13, ptr %"control value 161", align 1
  %14 = load i8, ptr %"control value 161", align 1
  %15 = icmp ne i8 %14, 0
  br i1 %15, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  %16 = load i32, ptr %maximum, align 1
  store i32 %16, ptr %"control value 162", align 1
  %17 = load i32, ptr %size, align 1
  store i32 %17, ptr %"control value 163", align 1
  %18 = load i32, ptr %"control value 162", align 1
  %19 = load i32, ptr %"control value 163", align 1
  %20 = icmp ne i32 %19, 0
  br i1 %20, label %valid, label %error

if.else:                                          ; preds = %entry
  br label %if.end

if.end:                                           ; preds = %if.end3, %if.else
  ret i8 1

valid:                                            ; preds = %if.body
  %21 = udiv i32 %18, %19
  store i32 %21, ptr %"control value 164", align 1
  %22 = load i32, ptr %"control value 164", align 1
  store i32 %22, ptr %limit, align 1
  %23 = load i32, ptr %count, align 1
  store i32 %23, ptr %"control value 165", align 1
  %24 = load i32, ptr %limit, align 1
  store i32 %24, ptr %"control value 166", align 1
  %25 = load i32, ptr %"control value 165", align 1
  %26 = load i32, ptr %"control value 166", align 1
  %27 = icmp ugt i32 %25, %26
  %28 = zext i1 %27 to i8
  store i8 %28, ptr %"control value 167", align 1
  %29 = load i8, ptr %"control value 167", align 1
  store i8 %29, ptr %overflow, align 1
  %30 = load i8, ptr %overflow, align 1
  store i8 %30, ptr %"control value 168", align 1
  %31 = load i8, ptr %"control value 168", align 1
  %32 = icmp ne i8 %31, 0
  br i1 %32, label %if.body1, label %if.else2

error:                                            ; preds = %if.body
  call void @tower_trap(ptr @0, i32 13711)
  unreachable

if.body1:                                         ; preds = %valid
  ret i8 0

if.else2:                                         ; preds = %valid
  br label %if.end3

if.end3:                                          ; preds = %if.else2
  br label %if.end
}

define ptr @tower_allocate(i32 %0, i32 %1) {
entry:
  %count = alloca i32, align 4
  %size = alloca i32, align 4
  %bytes = alloca i32, align 4
  %"control value 169" = alloca i32, align 4
  %"control value 170" = alloca i32, align 4
  %"control value 171" = alloca i8, align 1
  %"control value 172" = alloca i8, align 1
  %"control value 173" = alloca i32, align 4
  %"control value 174" = alloca i32, align 4
  %"control value 175" = alloca i32, align 4
  %"control value 176" = alloca i32, align 4
  %"control value 177" = alloca ptr, align 4
  store i32 %0, ptr %count, align 1
  store i32 %1, ptr %size, align 1
  %2 = load i32, ptr %count, align 1
  store i32 %2, ptr %"control value 169", align 1
  %3 = load i32, ptr %size, align 1
  store i32 %3, ptr %"control value 170", align 1
  %4 = load i32, ptr %"control value 169", align 1
  %5 = load i32, ptr %"control value 170", align 1
  %6 = call i8 @tower.fn.guest_runtime_product(i32 %4, i32 %5)
  store i8 %6, ptr %"control value 171", align 1
  %7 = load i8, ptr %"control value 171", align 1
  %8 = icmp eq i8 0, %7
  %9 = zext i1 %8 to i8
  store i8 %9, ptr %"control value 172", align 1
  %10 = load i8, ptr %"control value 172", align 1
  %11 = icmp ne i8 %10, 0
  br i1 %11, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  ret ptr null

if.else:                                          ; preds = %entry
  br label %if.end

if.end:                                           ; preds = %if.else
  %12 = load i32, ptr %count, align 1
  store i32 %12, ptr %"control value 173", align 1
  %13 = load i32, ptr %size, align 1
  store i32 %13, ptr %"control value 174", align 1
  %14 = load i32, ptr %"control value 173", align 1
  %15 = load i32, ptr %"control value 174", align 1
  %16 = mul i32 %14, %15
  store i32 %16, ptr %"control value 175", align 1
  %17 = load i32, ptr %"control value 175", align 1
  store i32 %17, ptr %bytes, align 1
  %18 = load i32, ptr %bytes, align 1
  store i32 %18, ptr %"control value 176", align 1
  %19 = load i32, ptr %"control value 176", align 1
  %20 = call ptr @malloc(i32 %19) #8
  store ptr %20, ptr %"control value 177", align 1
  %21 = load ptr, ptr %"control value 177", align 1
  ret ptr %21
}

define ptr @tower_reallocate(ptr %0, i32 %1, i32 %2) {
entry:
  %pointer = alloca ptr, align 4
  %count = alloca i32, align 4
  %size = alloca i32, align 4
  %bytes = alloca i32, align 4
  %"control value 178" = alloca i32, align 4
  %"control value 179" = alloca i32, align 4
  %"control value 180" = alloca i8, align 1
  %"control value 181" = alloca i8, align 1
  %"control value 182" = alloca i32, align 4
  %"control value 183" = alloca i32, align 4
  %"control value 184" = alloca i32, align 4
  %"control value 185" = alloca ptr, align 4
  %"control value 186" = alloca i32, align 4
  %"control value 187" = alloca ptr, align 4
  store ptr %0, ptr %pointer, align 1
  store i32 %1, ptr %count, align 1
  store i32 %2, ptr %size, align 1
  %3 = load i32, ptr %count, align 1
  store i32 %3, ptr %"control value 178", align 1
  %4 = load i32, ptr %size, align 1
  store i32 %4, ptr %"control value 179", align 1
  %5 = load i32, ptr %"control value 178", align 1
  %6 = load i32, ptr %"control value 179", align 1
  %7 = call i8 @tower.fn.guest_runtime_product(i32 %5, i32 %6)
  store i8 %7, ptr %"control value 180", align 1
  %8 = load i8, ptr %"control value 180", align 1
  %9 = icmp eq i8 0, %8
  %10 = zext i1 %9 to i8
  store i8 %10, ptr %"control value 181", align 1
  %11 = load i8, ptr %"control value 181", align 1
  %12 = icmp ne i8 %11, 0
  br i1 %12, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  ret ptr null

if.else:                                          ; preds = %entry
  br label %if.end

if.end:                                           ; preds = %if.else
  %13 = load i32, ptr %count, align 1
  store i32 %13, ptr %"control value 182", align 1
  %14 = load i32, ptr %size, align 1
  store i32 %14, ptr %"control value 183", align 1
  %15 = load i32, ptr %"control value 182", align 1
  %16 = load i32, ptr %"control value 183", align 1
  %17 = mul i32 %15, %16
  store i32 %17, ptr %"control value 184", align 1
  %18 = load i32, ptr %"control value 184", align 1
  store i32 %18, ptr %bytes, align 1
  %19 = load ptr, ptr %pointer, align 1
  store ptr %19, ptr %"control value 185", align 1
  %20 = load i32, ptr %bytes, align 1
  store i32 %20, ptr %"control value 186", align 1
  %21 = load ptr, ptr %"control value 185", align 1
  %22 = load i32, ptr %"control value 186", align 1
  %23 = call ptr @realloc(ptr %21, i32 %22) #9
  store ptr %23, ptr %"control value 187", align 1
  %24 = load ptr, ptr %"control value 187", align 1
  ret ptr %24
}

define void @tower_deallocate(ptr %0) {
entry:
  %pointer = alloca ptr, align 4
  %"control value 188" = alloca ptr, align 4
  store ptr %0, ptr %pointer, align 1
  %1 = load ptr, ptr %pointer, align 1
  store ptr %1, ptr %"control value 188", align 1
  %2 = load ptr, ptr %"control value 188", align 1
  call void @free(ptr %2) #10
  ret void
}

define ptr @memcpy(ptr %0, ptr %1, i32 %2) {
entry:
  %destination = alloca ptr, align 4
  %source = alloca ptr, align 4
  %count = alloca i32, align 4
  %out = alloca ptr, align 4
  %input = alloca ptr, align 4
  %i = alloca i32, align 4
  %"control value 153" = alloca i8, align 1
  %"control value 189" = alloca ptr, align 4
  %"control value 190" = alloca ptr, align 4
  %"control value 191" = alloca ptr, align 4
  %"control value 192" = alloca ptr, align 4
  %"control value 193" = alloca i32, align 4
  %"control value 194" = alloca i32, align 4
  %"control value 195" = alloca i8, align 1
  %"control value 196" = alloca i8, align 1
  %"control value 197" = alloca ptr, align 4
  %"control value 198" = alloca i32, align 4
  %"control value 199" = alloca ptr, align 4
  %"control value 200" = alloca ptr, align 4
  %"control value 201" = alloca i32, align 4
  %"control value 202" = alloca i8, align 1
  %"control value 203" = alloca ptr, align 4
  %"control value 204" = alloca i32, align 4
  %"control value 205" = alloca i32, align 4
  %"control value 206" = alloca ptr, align 4
  store ptr %0, ptr %destination, align 1
  store ptr %1, ptr %source, align 1
  store i32 %2, ptr %count, align 1
  %3 = load ptr, ptr %destination, align 1
  store ptr %3, ptr %"control value 189", align 1
  %4 = load ptr, ptr %"control value 189", align 1
  store ptr %4, ptr %"control value 190", align 1
  %5 = load ptr, ptr %"control value 190", align 1
  store ptr %5, ptr %out, align 1
  %6 = load ptr, ptr %source, align 1
  store ptr %6, ptr %"control value 191", align 1
  %7 = load ptr, ptr %"control value 191", align 1
  store ptr %7, ptr %"control value 192", align 1
  %8 = load ptr, ptr %"control value 192", align 1
  store ptr %8, ptr %input, align 1
  store i32 0, ptr %i, align 1
  br label %loop

loop:                                             ; preds = %if.end, %entry
  %9 = load i32, ptr %i, align 1
  store i32 %9, ptr %"control value 193", align 1
  %10 = load i32, ptr %count, align 1
  store i32 %10, ptr %"control value 194", align 1
  %11 = load i32, ptr %"control value 193", align 1
  %12 = load i32, ptr %"control value 194", align 1
  %13 = icmp ult i32 %11, %12
  %14 = zext i1 %13 to i8
  store i8 %14, ptr %"control value 195", align 1
  %15 = load i8, ptr %"control value 195", align 1
  store i8 %15, ptr %"control value 153", align 1
  %16 = load i8, ptr %"control value 153", align 1
  store i8 %16, ptr %"control value 196", align 1
  %17 = load i8, ptr %"control value 196", align 1
  %18 = icmp ne i8 %17, 0
  br i1 %18, label %if.body, label %if.else

loop.end:                                         ; preds = %if.else
  %19 = load ptr, ptr %destination, align 1
  store ptr %19, ptr %"control value 206", align 1
  %20 = load ptr, ptr %"control value 206", align 1
  ret ptr %20

if.body:                                          ; preds = %loop
  %21 = load ptr, ptr %out, align 1
  store ptr %21, ptr %"control value 197", align 1
  %22 = load i32, ptr %i, align 1
  store i32 %22, ptr %"control value 198", align 1
  %23 = load ptr, ptr %"control value 197", align 1
  %24 = load i32, ptr %"control value 198", align 1
  %25 = mul i32 %24, 1
  %26 = getelementptr i8, ptr %23, i32 %25
  store ptr %26, ptr %"control value 199", align 1
  %27 = load ptr, ptr %input, align 1
  store ptr %27, ptr %"control value 200", align 1
  %28 = load i32, ptr %i, align 1
  store i32 %28, ptr %"control value 201", align 1
  %29 = load ptr, ptr %"control value 200", align 1
  %30 = load i32, ptr %"control value 201", align 1
  %31 = mul i32 %30, 1
  %32 = getelementptr i8, ptr %29, i32 %31
  %33 = load i8, ptr %32, align 1
  store i8 %33, ptr %"control value 202", align 1
  %34 = load ptr, ptr %"control value 199", align 1
  %35 = load i8, ptr %"control value 202", align 1
  store i8 %35, ptr %34, align 1
  store ptr %i, ptr %"control value 203", align 1
  %36 = load ptr, ptr %"control value 203", align 1
  %37 = load i32, ptr %36, align 1
  store i32 %37, ptr %"control value 204", align 1
  %38 = load i32, ptr %"control value 204", align 1
  %39 = add i32 %38, 1
  store i32 %39, ptr %"control value 205", align 1
  %40 = load ptr, ptr %"control value 203", align 1
  %41 = load i32, ptr %"control value 205", align 1
  store i32 %41, ptr %40, align 1
  br label %if.end

if.else:                                          ; preds = %loop
  br label %loop.end

if.end:                                           ; preds = %if.body
  br label %loop
}

define ptr @memmove(ptr %0, ptr %1, i32 %2) {
entry:
  %destination = alloca ptr, align 4
  %source = alloca ptr, align 4
  %count = alloca i32, align 4
  %out = alloca ptr, align 4
  %input = alloca ptr, align 4
  %forward = alloca i8, align 1
  %i = alloca i32, align 4
  %"control value 154" = alloca i8, align 1
  %"control value 207" = alloca ptr, align 4
  %"control value 208" = alloca ptr, align 4
  %"control value 209" = alloca ptr, align 4
  %"control value 210" = alloca ptr, align 4
  %"control value 211" = alloca ptr, align 4
  %"control value 212" = alloca i32, align 4
  %"control value 213" = alloca ptr, align 4
  %"control value 214" = alloca i32, align 4
  %"control value 215" = alloca i8, align 1
  %"control value 216" = alloca i8, align 1
  %"control value 217" = alloca ptr, align 4
  %"control value 218" = alloca ptr, align 4
  %"control value 219" = alloca i32, align 4
  %"control value 220" = alloca ptr, align 4
  %"control value 221" = alloca i32, align 4
  %"control value 222" = alloca i32, align 4
  %"control value 223" = alloca i8, align 1
  %"control value 224" = alloca i8, align 1
  %"control value 225" = alloca ptr, align 4
  %"control value 226" = alloca i32, align 4
  %"control value 227" = alloca i32, align 4
  %"control value 228" = alloca ptr, align 4
  %"control value 229" = alloca i32, align 4
  %"control value 230" = alloca ptr, align 4
  %"control value 231" = alloca ptr, align 4
  %"control value 232" = alloca i32, align 4
  %"control value 233" = alloca i8, align 1
  %"control value 234" = alloca ptr, align 4
  store ptr %0, ptr %destination, align 1
  store ptr %1, ptr %source, align 1
  store i32 %2, ptr %count, align 1
  %3 = load ptr, ptr %destination, align 1
  store ptr %3, ptr %"control value 207", align 1
  %4 = load ptr, ptr %"control value 207", align 1
  store ptr %4, ptr %"control value 208", align 1
  %5 = load ptr, ptr %"control value 208", align 1
  store ptr %5, ptr %out, align 1
  %6 = load ptr, ptr %source, align 1
  store ptr %6, ptr %"control value 209", align 1
  %7 = load ptr, ptr %"control value 209", align 1
  store ptr %7, ptr %"control value 210", align 1
  %8 = load ptr, ptr %"control value 210", align 1
  store ptr %8, ptr %input, align 1
  %9 = load ptr, ptr %out, align 1
  store ptr %9, ptr %"control value 211", align 1
  %10 = load ptr, ptr %"control value 211", align 1
  %11 = ptrtoint ptr %10 to i32
  store i32 %11, ptr %"control value 212", align 1
  %12 = load ptr, ptr %input, align 1
  store ptr %12, ptr %"control value 213", align 1
  %13 = load ptr, ptr %"control value 213", align 1
  %14 = ptrtoint ptr %13 to i32
  store i32 %14, ptr %"control value 214", align 1
  %15 = load i32, ptr %"control value 212", align 1
  %16 = load i32, ptr %"control value 214", align 1
  %17 = icmp ult i32 %15, %16
  %18 = zext i1 %17 to i8
  store i8 %18, ptr %"control value 215", align 1
  %19 = load i8, ptr %"control value 215", align 1
  store i8 %19, ptr %forward, align 1
  %20 = load i8, ptr %forward, align 1
  store i8 %20, ptr %"control value 216", align 1
  %21 = load i8, ptr %"control value 216", align 1
  %22 = icmp ne i8 %21, 0
  br i1 %22, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  %23 = load ptr, ptr %destination, align 1
  store ptr %23, ptr %"control value 217", align 1
  %24 = load ptr, ptr %source, align 1
  store ptr %24, ptr %"control value 218", align 1
  %25 = load i32, ptr %count, align 1
  store i32 %25, ptr %"control value 219", align 1
  %26 = load ptr, ptr %"control value 217", align 1
  %27 = load ptr, ptr %"control value 218", align 1
  %28 = load i32, ptr %"control value 219", align 1
  %29 = call ptr @memcpy(ptr %26, ptr %27, i32 %28) #11
  store ptr %29, ptr %"control value 220", align 1
  %30 = load ptr, ptr %"control value 220", align 1
  ret ptr %30

if.else:                                          ; preds = %entry
  br label %if.end

if.end:                                           ; preds = %if.else
  %31 = load i32, ptr %count, align 1
  store i32 %31, ptr %"control value 221", align 1
  %32 = load i32, ptr %"control value 221", align 1
  store i32 %32, ptr %i, align 1
  br label %loop

loop:                                             ; preds = %if.end3, %if.end
  %33 = load i32, ptr %i, align 1
  store i32 %33, ptr %"control value 222", align 1
  %34 = load i32, ptr %"control value 222", align 1
  %35 = icmp ne i32 %34, 0
  %36 = zext i1 %35 to i8
  store i8 %36, ptr %"control value 223", align 1
  %37 = load i8, ptr %"control value 223", align 1
  store i8 %37, ptr %"control value 154", align 1
  %38 = load i8, ptr %"control value 154", align 1
  store i8 %38, ptr %"control value 224", align 1
  %39 = load i8, ptr %"control value 224", align 1
  %40 = icmp ne i8 %39, 0
  br i1 %40, label %if.body1, label %if.else2

loop.end:                                         ; preds = %if.else2
  %41 = load ptr, ptr %destination, align 1
  store ptr %41, ptr %"control value 234", align 1
  %42 = load ptr, ptr %"control value 234", align 1
  ret ptr %42

if.body1:                                         ; preds = %loop
  store ptr %i, ptr %"control value 225", align 1
  %43 = load ptr, ptr %"control value 225", align 1
  %44 = load i32, ptr %43, align 1
  store i32 %44, ptr %"control value 226", align 1
  %45 = load i32, ptr %"control value 226", align 1
  %46 = sub i32 %45, 1
  store i32 %46, ptr %"control value 227", align 1
  %47 = load ptr, ptr %"control value 225", align 1
  %48 = load i32, ptr %"control value 227", align 1
  store i32 %48, ptr %47, align 1
  %49 = load ptr, ptr %out, align 1
  store ptr %49, ptr %"control value 228", align 1
  %50 = load i32, ptr %i, align 1
  store i32 %50, ptr %"control value 229", align 1
  %51 = load ptr, ptr %"control value 228", align 1
  %52 = load i32, ptr %"control value 229", align 1
  %53 = mul i32 %52, 1
  %54 = getelementptr i8, ptr %51, i32 %53
  store ptr %54, ptr %"control value 230", align 1
  %55 = load ptr, ptr %input, align 1
  store ptr %55, ptr %"control value 231", align 1
  %56 = load i32, ptr %i, align 1
  store i32 %56, ptr %"control value 232", align 1
  %57 = load ptr, ptr %"control value 231", align 1
  %58 = load i32, ptr %"control value 232", align 1
  %59 = mul i32 %58, 1
  %60 = getelementptr i8, ptr %57, i32 %59
  %61 = load i8, ptr %60, align 1
  store i8 %61, ptr %"control value 233", align 1
  %62 = load ptr, ptr %"control value 230", align 1
  %63 = load i8, ptr %"control value 233", align 1
  store i8 %63, ptr %62, align 1
  br label %if.end3

if.else2:                                         ; preds = %loop
  br label %loop.end

if.end3:                                          ; preds = %if.body1
  br label %loop
}

define ptr @memset(ptr %0, i32 %1, i32 %2) {
entry:
  %destination = alloca ptr, align 4
  %value = alloca i32, align 4
  %count = alloca i32, align 4
  %out = alloca ptr, align 4
  %low = alloca i32, align 4
  %byte = alloca i8, align 1
  %i = alloca i32, align 4
  %"control value 155" = alloca i8, align 1
  %"control value 235" = alloca ptr, align 4
  %"control value 236" = alloca ptr, align 4
  %"control value 237" = alloca i32, align 4
  %"control value 238" = alloca i32, align 4
  %"control value 239" = alloca i32, align 4
  %"control value 240" = alloca i32, align 4
  %"control value 241" = alloca i8, align 1
  %"control value 242" = alloca i32, align 4
  %"control value 243" = alloca i32, align 4
  %"control value 244" = alloca i8, align 1
  %"control value 245" = alloca i8, align 1
  %"control value 246" = alloca ptr, align 4
  %"control value 247" = alloca i32, align 4
  %"control value 248" = alloca ptr, align 4
  %"control value 249" = alloca i8, align 1
  %"control value 250" = alloca ptr, align 4
  %"control value 251" = alloca i32, align 4
  %"control value 252" = alloca i32, align 4
  %"control value 253" = alloca ptr, align 4
  store ptr %0, ptr %destination, align 1
  store i32 %1, ptr %value, align 1
  store i32 %2, ptr %count, align 1
  %3 = load ptr, ptr %destination, align 1
  store ptr %3, ptr %"control value 235", align 1
  %4 = load ptr, ptr %"control value 235", align 1
  store ptr %4, ptr %"control value 236", align 1
  %5 = load ptr, ptr %"control value 236", align 1
  store ptr %5, ptr %out, align 1
  %6 = load i32, ptr %value, align 1
  store i32 %6, ptr %"control value 237", align 1
  %7 = load i32, ptr %"control value 237", align 1
  store i32 %7, ptr %"control value 238", align 1
  %8 = load i32, ptr %"control value 238", align 1
  %9 = and i32 %8, 255
  store i32 %9, ptr %"control value 239", align 1
  %10 = load i32, ptr %"control value 239", align 1
  store i32 %10, ptr %low, align 1
  %11 = load i32, ptr %low, align 1
  store i32 %11, ptr %"control value 240", align 1
  %12 = load i32, ptr %"control value 240", align 1
  %13 = zext i32 %12 to i64
  %14 = icmp ule i64 %13, 255
  %15 = and i1 true, %14
  br i1 %15, label %valid, label %error

valid:                                            ; preds = %entry
  %16 = trunc i32 %12 to i8
  store i8 %16, ptr %"control value 241", align 1
  %17 = load i8, ptr %"control value 241", align 1
  store i8 %17, ptr %byte, align 1
  store i32 0, ptr %i, align 1
  br label %loop

error:                                            ; preds = %entry
  call void @tower_trap(ptr @1, i32 14909)
  unreachable

loop:                                             ; preds = %if.end, %valid
  %18 = load i32, ptr %i, align 1
  store i32 %18, ptr %"control value 242", align 1
  %19 = load i32, ptr %count, align 1
  store i32 %19, ptr %"control value 243", align 1
  %20 = load i32, ptr %"control value 242", align 1
  %21 = load i32, ptr %"control value 243", align 1
  %22 = icmp ult i32 %20, %21
  %23 = zext i1 %22 to i8
  store i8 %23, ptr %"control value 244", align 1
  %24 = load i8, ptr %"control value 244", align 1
  store i8 %24, ptr %"control value 155", align 1
  %25 = load i8, ptr %"control value 155", align 1
  store i8 %25, ptr %"control value 245", align 1
  %26 = load i8, ptr %"control value 245", align 1
  %27 = icmp ne i8 %26, 0
  br i1 %27, label %if.body, label %if.else

loop.end:                                         ; preds = %if.else
  %28 = load ptr, ptr %destination, align 1
  store ptr %28, ptr %"control value 253", align 1
  %29 = load ptr, ptr %"control value 253", align 1
  ret ptr %29

if.body:                                          ; preds = %loop
  %30 = load ptr, ptr %out, align 1
  store ptr %30, ptr %"control value 246", align 1
  %31 = load i32, ptr %i, align 1
  store i32 %31, ptr %"control value 247", align 1
  %32 = load ptr, ptr %"control value 246", align 1
  %33 = load i32, ptr %"control value 247", align 1
  %34 = mul i32 %33, 1
  %35 = getelementptr i8, ptr %32, i32 %34
  store ptr %35, ptr %"control value 248", align 1
  %36 = load i8, ptr %byte, align 1
  store i8 %36, ptr %"control value 249", align 1
  %37 = load ptr, ptr %"control value 248", align 1
  %38 = load i8, ptr %"control value 249", align 1
  store i8 %38, ptr %37, align 1
  store ptr %i, ptr %"control value 250", align 1
  %39 = load ptr, ptr %"control value 250", align 1
  %40 = load i32, ptr %39, align 1
  store i32 %40, ptr %"control value 251", align 1
  %41 = load i32, ptr %"control value 251", align 1
  %42 = add i32 %41, 1
  store i32 %42, ptr %"control value 252", align 1
  %43 = load ptr, ptr %"control value 250", align 1
  %44 = load i32, ptr %"control value 252", align 1
  store i32 %44, ptr %43, align 1
  br label %if.end

if.else:                                          ; preds = %loop
  br label %loop.end

if.end:                                           ; preds = %if.body
  br label %loop
}

define zeroext i8 @guest_heap_init(ptr %0, ptr %1, ptr %2) {
entry:
  %heap = alloca ptr, align 4
  %begin = alloca ptr, align 4
  %end = alloca ptr, align 4
  %first = alloca i32, align 4
  %limit = alloca i32, align 4
  %invalid = alloca i8, align 1
  %aligned = alloca i32, align 4
  %"control value 254" = alloca ptr, align 4
  %"control value 255" = alloca i32, align 4
  %"control value 256" = alloca ptr, align 4
  %"control value 257" = alloca i32, align 4
  %"control value 258" = alloca ptr, align 4
  %"control value 259" = alloca i32, align 4
  %"control value 260" = alloca i32, align 4
  %"control value 261" = alloca i8, align 1
  %"control value 262" = alloca i8, align 1
  %"control value 263" = alloca i32, align 4
  %"control value 264" = alloca i32, align 4
  %"control value 265" = alloca ptr, align 4
  %"control value 266" = alloca i32, align 4
  %"control value 267" = alloca i32, align 4
  %"control value 268" = alloca i8, align 1
  %"control value 269" = alloca i8, align 1
  %"control value 270" = alloca ptr, align 4
  %"control value 271" = alloca i32, align 4
  %"control value 272" = alloca i32, align 4
  %"control value 273" = alloca ptr, align 4
  %"control value 274" = alloca i32, align 4
  %"control value 275" = alloca i32, align 4
  %"control value 276" = alloca ptr, align 4
  %"control value 277" = alloca i32, align 4
  %"control value 278" = alloca i32, align 4
  %"control value 279" = alloca i8, align 1
  %"control value 280" = alloca i8, align 1
  %"control value 281" = alloca ptr, align 4
  %"control value 282" = alloca ptr, align 4
  %"control value 283" = alloca i32, align 4
  %"control value 284" = alloca ptr, align 4
  %"control value 285" = alloca ptr, align 4
  %"control value 286" = alloca i32, align 4
  store ptr %0, ptr %heap, align 1
  store ptr %1, ptr %begin, align 1
  store ptr %2, ptr %end, align 1
  %3 = load ptr, ptr %heap, align 1
  store ptr %3, ptr %"control value 254", align 1
  store i32 12, ptr %"control value 255", align 1
  %4 = load ptr, ptr %"control value 254", align 1
  %5 = load i32, ptr %"control value 255", align 1
  call void @llvm.memset.p0.i32(ptr align 1 %4, i8 0, i32 %5, i1 false)
  %6 = load ptr, ptr %begin, align 1
  store ptr %6, ptr %"control value 256", align 1
  %7 = load ptr, ptr %"control value 256", align 1
  %8 = ptrtoint ptr %7 to i32
  store i32 %8, ptr %"control value 257", align 1
  %9 = load i32, ptr %"control value 257", align 1
  store i32 %9, ptr %first, align 1
  %10 = load ptr, ptr %end, align 1
  store ptr %10, ptr %"control value 258", align 1
  %11 = load ptr, ptr %"control value 258", align 1
  %12 = ptrtoint ptr %11 to i32
  store i32 %12, ptr %"control value 259", align 1
  %13 = load i32, ptr %"control value 259", align 1
  store i32 %13, ptr %limit, align 1
  %14 = load i32, ptr %first, align 1
  store i32 %14, ptr %"control value 260", align 1
  %15 = load i32, ptr %"control value 260", align 1
  %16 = icmp eq i32 %15, 0
  %17 = zext i1 %16 to i8
  store i8 %17, ptr %"control value 261", align 1
  %18 = load i8, ptr %"control value 261", align 1
  store i8 %18, ptr %invalid, align 1
  %19 = load i8, ptr %invalid, align 1
  store i8 %19, ptr %"control value 262", align 1
  %20 = load i8, ptr %"control value 262", align 1
  %21 = icmp ne i8 %20, 0
  br i1 %21, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  ret i8 0

if.else:                                          ; preds = %entry
  br label %if.end

if.end:                                           ; preds = %if.else
  %22 = load i32, ptr %first, align 1
  store i32 %22, ptr %"control value 263", align 1
  %23 = load i32, ptr %"control value 263", align 1
  %24 = add i32 %23, 15
  store i32 %24, ptr %"control value 264", align 1
  %25 = load i32, ptr %"control value 264", align 1
  store i32 %25, ptr %aligned, align 1
  store ptr %invalid, ptr %"control value 265", align 1
  %26 = load i32, ptr %aligned, align 1
  store i32 %26, ptr %"control value 266", align 1
  %27 = load i32, ptr %first, align 1
  store i32 %27, ptr %"control value 267", align 1
  %28 = load i32, ptr %"control value 266", align 1
  %29 = load i32, ptr %"control value 267", align 1
  %30 = icmp ult i32 %28, %29
  %31 = zext i1 %30 to i8
  store i8 %31, ptr %"control value 268", align 1
  %32 = load ptr, ptr %"control value 265", align 1
  %33 = load i8, ptr %"control value 268", align 1
  store i8 %33, ptr %32, align 1
  %34 = load i8, ptr %invalid, align 1
  store i8 %34, ptr %"control value 269", align 1
  %35 = load i8, ptr %"control value 269", align 1
  %36 = icmp ne i8 %35, 0
  br i1 %36, label %if.body1, label %if.else2

if.body1:                                         ; preds = %if.end
  ret i8 0

if.else2:                                         ; preds = %if.end
  br label %if.end3

if.end3:                                          ; preds = %if.else2
  store ptr %aligned, ptr %"control value 270", align 1
  %37 = load i32, ptr %aligned, align 1
  store i32 %37, ptr %"control value 271", align 1
  %38 = load i32, ptr %"control value 271", align 1
  br i1 true, label %valid, label %error

valid:                                            ; preds = %if.end3
  %39 = udiv i32 %38, 16
  store i32 %39, ptr %"control value 272", align 1
  %40 = load ptr, ptr %"control value 270", align 1
  %41 = load i32, ptr %"control value 272", align 1
  store i32 %41, ptr %40, align 1
  store ptr %aligned, ptr %"control value 273", align 1
  %42 = load i32, ptr %aligned, align 1
  store i32 %42, ptr %"control value 274", align 1
  %43 = load i32, ptr %"control value 274", align 1
  %44 = mul i32 %43, 16
  store i32 %44, ptr %"control value 275", align 1
  %45 = load ptr, ptr %"control value 273", align 1
  %46 = load i32, ptr %"control value 275", align 1
  store i32 %46, ptr %45, align 1
  store ptr %invalid, ptr %"control value 276", align 1
  %47 = load i32, ptr %aligned, align 1
  store i32 %47, ptr %"control value 277", align 1
  %48 = load i32, ptr %limit, align 1
  store i32 %48, ptr %"control value 278", align 1
  %49 = load i32, ptr %"control value 277", align 1
  %50 = load i32, ptr %"control value 278", align 1
  %51 = icmp ugt i32 %49, %50
  %52 = zext i1 %51 to i8
  store i8 %52, ptr %"control value 279", align 1
  %53 = load ptr, ptr %"control value 276", align 1
  %54 = load i8, ptr %"control value 279", align 1
  store i8 %54, ptr %53, align 1
  %55 = load i8, ptr %invalid, align 1
  store i8 %55, ptr %"control value 280", align 1
  %56 = load i8, ptr %"control value 280", align 1
  %57 = icmp ne i8 %56, 0
  br i1 %57, label %if.body4, label %if.else5

error:                                            ; preds = %if.end3
  call void @tower_trap(ptr @2, i32 16075)
  unreachable

if.body4:                                         ; preds = %valid
  ret i8 0

if.else5:                                         ; preds = %valid
  br label %if.end6

if.end6:                                          ; preds = %if.else5
  %58 = load ptr, ptr %heap, align 1
  store ptr %58, ptr %"control value 281", align 1
  %59 = load ptr, ptr %"control value 281", align 1
  %60 = getelementptr i8, ptr %59, i32 4
  store ptr %60, ptr %"control value 282", align 1
  %61 = load i32, ptr %aligned, align 1
  store i32 %61, ptr %"control value 283", align 1
  %62 = load ptr, ptr %"control value 282", align 1
  %63 = load i32, ptr %"control value 283", align 1
  store i32 %63, ptr %62, align 1
  %64 = load ptr, ptr %heap, align 1
  store ptr %64, ptr %"control value 284", align 1
  %65 = load ptr, ptr %"control value 284", align 1
  %66 = getelementptr i8, ptr %65, i32 8
  store ptr %66, ptr %"control value 285", align 1
  %67 = load i32, ptr %limit, align 1
  store i32 %67, ptr %"control value 286", align 1
  %68 = load ptr, ptr %"control value 285", align 1
  %69 = load i32, ptr %"control value 286", align 1
  store i32 %69, ptr %68, align 1
  ret i8 1
}

define zeroext i8 @guest_heap_extend(ptr %0, ptr %1) {
entry:
  %heap = alloca ptr, align 4
  %end = alloca ptr, align 4
  %limit = alloca i32, align 4
  %invalid = alloca i8, align 1
  %"control value 287" = alloca ptr, align 4
  %"control value 288" = alloca i32, align 4
  %"control value 289" = alloca i32, align 4
  %"control value 290" = alloca ptr, align 4
  %"control value 291" = alloca i32, align 4
  %"control value 292" = alloca i8, align 1
  %"control value 293" = alloca i8, align 1
  %"control value 294" = alloca ptr, align 4
  %"control value 295" = alloca ptr, align 4
  %"control value 296" = alloca i32, align 4
  store ptr %0, ptr %heap, align 1
  store ptr %1, ptr %end, align 1
  %2 = load ptr, ptr %end, align 1
  store ptr %2, ptr %"control value 287", align 1
  %3 = load ptr, ptr %"control value 287", align 1
  %4 = ptrtoint ptr %3 to i32
  store i32 %4, ptr %"control value 288", align 1
  %5 = load i32, ptr %"control value 288", align 1
  store i32 %5, ptr %limit, align 1
  %6 = load i32, ptr %limit, align 1
  store i32 %6, ptr %"control value 289", align 1
  %7 = load ptr, ptr %heap, align 1
  store ptr %7, ptr %"control value 290", align 1
  %8 = load ptr, ptr %"control value 290", align 1
  %9 = getelementptr i8, ptr %8, i32 8
  %10 = load i32, ptr %9, align 1
  store i32 %10, ptr %"control value 291", align 1
  %11 = load i32, ptr %"control value 289", align 1
  %12 = load i32, ptr %"control value 291", align 1
  %13 = icmp ult i32 %11, %12
  %14 = zext i1 %13 to i8
  store i8 %14, ptr %"control value 292", align 1
  %15 = load i8, ptr %"control value 292", align 1
  store i8 %15, ptr %invalid, align 1
  %16 = load i8, ptr %invalid, align 1
  store i8 %16, ptr %"control value 293", align 1
  %17 = load i8, ptr %"control value 293", align 1
  %18 = icmp ne i8 %17, 0
  br i1 %18, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  ret i8 0

if.else:                                          ; preds = %entry
  br label %if.end

if.end:                                           ; preds = %if.else
  %19 = load ptr, ptr %heap, align 1
  store ptr %19, ptr %"control value 294", align 1
  %20 = load ptr, ptr %"control value 294", align 1
  %21 = getelementptr i8, ptr %20, i32 8
  store ptr %21, ptr %"control value 295", align 1
  %22 = load i32, ptr %limit, align 1
  store i32 %22, ptr %"control value 296", align 1
  %23 = load ptr, ptr %"control value 295", align 1
  %24 = load i32, ptr %"control value 296", align 1
  store i32 %24, ptr %23, align 1
  ret i8 1
}

define internal i32 @tower.fn.guest_heap_request_size(i32 %0, i32 %1) {
entry:
  %count = alloca i32, align 4
  %size = alloca i32, align 4
  %maximum = alloca i32, align 4
  %sized = alloca i8, align 1
  %limit = alloca i32, align 4
  %overflow = alloca i8, align 1
  %bytes = alloca i32, align 4
  %limit1 = alloca i32, align 4
  %overflow2 = alloca i8, align 1
  %empty = alloca i8, align 1
  %"control value 297" = alloca ptr, align 4
  %"control value 298" = alloca i32, align 4
  %"control value 299" = alloca i32, align 4
  %"control value 300" = alloca i32, align 4
  %"control value 301" = alloca i8, align 1
  %"control value 302" = alloca i8, align 1
  %"control value 303" = alloca i32, align 4
  %"control value 304" = alloca i32, align 4
  %"control value 305" = alloca i32, align 4
  %"control value 306" = alloca i32, align 4
  %"control value 307" = alloca i32, align 4
  %"control value 308" = alloca i8, align 1
  %"control value 309" = alloca i8, align 1
  %"control value 310" = alloca i32, align 4
  %"control value 311" = alloca i32, align 4
  %"control value 312" = alloca i32, align 4
  %"control value 313" = alloca i32, align 4
  %"control value 314" = alloca i32, align 4
  %"control value 315" = alloca i32, align 4
  %"control value 316" = alloca i32, align 4
  %"control value 317" = alloca i8, align 1
  %"control value 318" = alloca i8, align 1
  %"control value 319" = alloca ptr, align 4
  %"control value 320" = alloca i32, align 4
  %"control value 321" = alloca i32, align 4
  %"control value 322" = alloca ptr, align 4
  %"control value 323" = alloca i32, align 4
  %"control value 324" = alloca i32, align 4
  %"control value 325" = alloca ptr, align 4
  %"control value 326" = alloca i32, align 4
  %"control value 327" = alloca i32, align 4
  %"control value 328" = alloca i32, align 4
  %"control value 329" = alloca i8, align 1
  %"control value 330" = alloca i8, align 1
  %"control value 331" = alloca ptr, align 4
  %"control value 332" = alloca i32, align 4
  store i32 %0, ptr %count, align 1
  store i32 %1, ptr %size, align 1
  store i32 0, ptr %maximum, align 1
  store ptr %maximum, ptr %"control value 297", align 1
  %2 = load ptr, ptr %"control value 297", align 1
  %3 = load i32, ptr %2, align 1
  store i32 %3, ptr %"control value 298", align 1
  %4 = load i32, ptr %"control value 298", align 1
  %5 = sub i32 %4, 1
  store i32 %5, ptr %"control value 299", align 1
  %6 = load ptr, ptr %"control value 297", align 1
  %7 = load i32, ptr %"control value 299", align 1
  store i32 %7, ptr %6, align 1
  %8 = load i32, ptr %size, align 1
  store i32 %8, ptr %"control value 300", align 1
  %9 = load i32, ptr %"control value 300", align 1
  %10 = icmp ne i32 %9, 0
  %11 = zext i1 %10 to i8
  store i8 %11, ptr %"control value 301", align 1
  %12 = load i8, ptr %"control value 301", align 1
  store i8 %12, ptr %sized, align 1
  %13 = load i8, ptr %sized, align 1
  store i8 %13, ptr %"control value 302", align 1
  %14 = load i8, ptr %"control value 302", align 1
  %15 = icmp ne i8 %14, 0
  br i1 %15, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  %16 = load i32, ptr %maximum, align 1
  store i32 %16, ptr %"control value 303", align 1
  %17 = load i32, ptr %size, align 1
  store i32 %17, ptr %"control value 304", align 1
  %18 = load i32, ptr %"control value 303", align 1
  %19 = load i32, ptr %"control value 304", align 1
  %20 = icmp ne i32 %19, 0
  br i1 %20, label %valid, label %error

if.else:                                          ; preds = %entry
  br label %if.end

if.end:                                           ; preds = %if.end5, %if.else
  %21 = load i32, ptr %count, align 1
  store i32 %21, ptr %"control value 310", align 1
  %22 = load i32, ptr %size, align 1
  store i32 %22, ptr %"control value 311", align 1
  %23 = load i32, ptr %"control value 310", align 1
  %24 = load i32, ptr %"control value 311", align 1
  %25 = mul i32 %23, %24
  store i32 %25, ptr %"control value 312", align 1
  %26 = load i32, ptr %"control value 312", align 1
  store i32 %26, ptr %bytes, align 1
  %27 = load i32, ptr %maximum, align 1
  store i32 %27, ptr %"control value 313", align 1
  %28 = load i32, ptr %"control value 313", align 1
  %29 = sub i32 %28, 15
  store i32 %29, ptr %"control value 314", align 1
  %30 = load i32, ptr %"control value 314", align 1
  store i32 %30, ptr %limit1, align 1
  %31 = load i32, ptr %bytes, align 1
  store i32 %31, ptr %"control value 315", align 1
  %32 = load i32, ptr %limit1, align 1
  store i32 %32, ptr %"control value 316", align 1
  %33 = load i32, ptr %"control value 315", align 1
  %34 = load i32, ptr %"control value 316", align 1
  %35 = icmp ugt i32 %33, %34
  %36 = zext i1 %35 to i8
  store i8 %36, ptr %"control value 317", align 1
  %37 = load i8, ptr %"control value 317", align 1
  store i8 %37, ptr %overflow2, align 1
  %38 = load i8, ptr %overflow2, align 1
  store i8 %38, ptr %"control value 318", align 1
  %39 = load i8, ptr %"control value 318", align 1
  %40 = icmp ne i8 %39, 0
  br i1 %40, label %if.body6, label %if.else7

valid:                                            ; preds = %if.body
  %41 = udiv i32 %18, %19
  store i32 %41, ptr %"control value 305", align 1
  %42 = load i32, ptr %"control value 305", align 1
  store i32 %42, ptr %limit, align 1
  %43 = load i32, ptr %count, align 1
  store i32 %43, ptr %"control value 306", align 1
  %44 = load i32, ptr %limit, align 1
  store i32 %44, ptr %"control value 307", align 1
  %45 = load i32, ptr %"control value 306", align 1
  %46 = load i32, ptr %"control value 307", align 1
  %47 = icmp ugt i32 %45, %46
  %48 = zext i1 %47 to i8
  store i8 %48, ptr %"control value 308", align 1
  %49 = load i8, ptr %"control value 308", align 1
  store i8 %49, ptr %overflow, align 1
  %50 = load i8, ptr %overflow, align 1
  store i8 %50, ptr %"control value 309", align 1
  %51 = load i8, ptr %"control value 309", align 1
  %52 = icmp ne i8 %51, 0
  br i1 %52, label %if.body3, label %if.else4

error:                                            ; preds = %if.body
  call void @tower_trap(ptr @3, i32 16075)
  unreachable

if.body3:                                         ; preds = %valid
  ret i32 0

if.else4:                                         ; preds = %valid
  br label %if.end5

if.end5:                                          ; preds = %if.else4
  br label %if.end

if.body6:                                         ; preds = %if.end
  ret i32 0

if.else7:                                         ; preds = %if.end
  br label %if.end8

if.end8:                                          ; preds = %if.else7
  store ptr %bytes, ptr %"control value 319", align 1
  %53 = load i32, ptr %bytes, align 1
  store i32 %53, ptr %"control value 320", align 1
  %54 = load i32, ptr %"control value 320", align 1
  %55 = add i32 %54, 15
  store i32 %55, ptr %"control value 321", align 1
  %56 = load ptr, ptr %"control value 319", align 1
  %57 = load i32, ptr %"control value 321", align 1
  store i32 %57, ptr %56, align 1
  store ptr %bytes, ptr %"control value 322", align 1
  %58 = load i32, ptr %bytes, align 1
  store i32 %58, ptr %"control value 323", align 1
  %59 = load i32, ptr %"control value 323", align 1
  br i1 true, label %valid9, label %error10

valid9:                                           ; preds = %if.end8
  %60 = udiv i32 %59, 16
  store i32 %60, ptr %"control value 324", align 1
  %61 = load ptr, ptr %"control value 322", align 1
  %62 = load i32, ptr %"control value 324", align 1
  store i32 %62, ptr %61, align 1
  store ptr %bytes, ptr %"control value 325", align 1
  %63 = load i32, ptr %bytes, align 1
  store i32 %63, ptr %"control value 326", align 1
  %64 = load i32, ptr %"control value 326", align 1
  %65 = mul i32 %64, 16
  store i32 %65, ptr %"control value 327", align 1
  %66 = load ptr, ptr %"control value 325", align 1
  %67 = load i32, ptr %"control value 327", align 1
  store i32 %67, ptr %66, align 1
  %68 = load i32, ptr %bytes, align 1
  store i32 %68, ptr %"control value 328", align 1
  %69 = load i32, ptr %"control value 328", align 1
  %70 = icmp eq i32 %69, 0
  %71 = zext i1 %70 to i8
  store i8 %71, ptr %"control value 329", align 1
  %72 = load i8, ptr %"control value 329", align 1
  store i8 %72, ptr %empty, align 1
  %73 = load i8, ptr %empty, align 1
  store i8 %73, ptr %"control value 330", align 1
  %74 = load i8, ptr %"control value 330", align 1
  %75 = icmp ne i8 %74, 0
  br i1 %75, label %if.body11, label %if.else12

error10:                                          ; preds = %if.end8
  call void @tower_trap(ptr @4, i32 16075)
  unreachable

if.body11:                                        ; preds = %valid9
  store ptr %bytes, ptr %"control value 331", align 1
  %76 = load ptr, ptr %"control value 331", align 1
  store i32 16, ptr %76, align 1
  br label %if.end13

if.else12:                                        ; preds = %valid9
  br label %if.end13

if.end13:                                         ; preds = %if.else12, %if.body11
  %77 = load i32, ptr %bytes, align 1
  store i32 %77, ptr %"control value 332", align 1
  %78 = load i32, ptr %"control value 332", align 1
  ret i32 %78
}

define ptr @guest_heap_allocate(ptr %0, i32 %1, i32 %2) {
entry:
  %heap = alloca ptr, align 4
  %count = alloca i32, align 4
  %size = alloca i32, align 4
  %bytes = alloca i32, align 4
  %overflow = alloca i8, align 1
  %header = alloca i32, align 4
  %link = alloca ptr, align 4
  %block = alloca ptr, align 4
  %absent = alloca i8, align 1
  %enough = alloca i8, align 1
  %spare = alloca i32, align 4
  %minimum = alloca i32, align 4
  %split = alloca i8, align 1
  %data = alloca ptr, align 4
  %remainder = alloca ptr, align 4
  %result = alloca ptr, align 4
  %remaining = alloca i32, align 4
  %short_header = alloca i8, align 1
  %short_data = alloca i8, align 1
  %block1 = alloca ptr, align 4
  %result2 = alloca ptr, align 4
  %"control value 333" = alloca i32, align 4
  %"control value 334" = alloca i32, align 4
  %"control value 335" = alloca i32, align 4
  %"control value 336" = alloca i32, align 4
  %"control value 337" = alloca i8, align 1
  %"control value 338" = alloca i8, align 1
  %"control value 339" = alloca i32, align 4
  %"control value 340" = alloca ptr, align 4
  %"control value 341" = alloca ptr, align 4
  %"control value 342" = alloca ptr, align 4
  %"control value 343" = alloca ptr, align 4
  %"control value 344" = alloca ptr, align 4
  %"control value 345" = alloca i8, align 1
  %"control value 346" = alloca i8, align 1
  %"control value 347" = alloca ptr, align 4
  %"control value 348" = alloca i32, align 4
  %"control value 349" = alloca i32, align 4
  %"control value 350" = alloca i8, align 1
  %"control value 351" = alloca i8, align 1
  %"control value 352" = alloca ptr, align 4
  %"control value 353" = alloca i32, align 4
  %"control value 354" = alloca i32, align 4
  %"control value 355" = alloca i32, align 4
  %"control value 356" = alloca i32, align 4
  %"control value 357" = alloca i32, align 4
  %"control value 358" = alloca i32, align 4
  %"control value 359" = alloca i32, align 4
  %"control value 360" = alloca i8, align 1
  %"control value 361" = alloca i8, align 1
  %"control value 362" = alloca ptr, align 4
  %"control value 363" = alloca ptr, align 4
  %"control value 364" = alloca ptr, align 4
  %"control value 365" = alloca ptr, align 4
  %"control value 366" = alloca i32, align 4
  %"control value 367" = alloca ptr, align 4
  %"control value 368" = alloca ptr, align 4
  %"control value 369" = alloca ptr, align 4
  %"control value 370" = alloca i32, align 4
  %"control value 371" = alloca ptr, align 4
  %"control value 372" = alloca ptr, align 4
  %"control value 373" = alloca ptr, align 4
  %"control value 374" = alloca ptr, align 4
  %"control value 375" = alloca ptr, align 4
  %"control value 376" = alloca i32, align 4
  %"control value 377" = alloca i32, align 4
  %"control value 378" = alloca i32, align 4
  %"control value 379" = alloca ptr, align 4
  %"control value 380" = alloca ptr, align 4
  %"control value 381" = alloca ptr, align 4
  %"control value 382" = alloca ptr, align 4
  %"control value 383" = alloca ptr, align 4
  %"control value 384" = alloca ptr, align 4
  %"control value 385" = alloca ptr, align 4
  %"control value 386" = alloca ptr, align 4
  %"control value 387" = alloca i32, align 4
  %"control value 388" = alloca ptr, align 4
  %"control value 389" = alloca ptr, align 4
  %"control value 390" = alloca ptr, align 4
  %"control value 391" = alloca ptr, align 4
  %"control value 392" = alloca ptr, align 4
  %"control value 393" = alloca ptr, align 4
  %"control value 394" = alloca ptr, align 4
  %"control value 395" = alloca ptr, align 4
  %"control value 396" = alloca ptr, align 4
  %"control value 397" = alloca ptr, align 4
  %"control value 398" = alloca ptr, align 4
  %"control value 399" = alloca i32, align 4
  %"control value 400" = alloca ptr, align 4
  %"control value 401" = alloca i32, align 4
  %"control value 402" = alloca i32, align 4
  %"control value 403" = alloca i32, align 4
  %"control value 404" = alloca i32, align 4
  %"control value 405" = alloca i8, align 1
  %"control value 406" = alloca i8, align 1
  %"control value 407" = alloca ptr, align 4
  %"control value 408" = alloca i32, align 4
  %"control value 409" = alloca i32, align 4
  %"control value 410" = alloca i32, align 4
  %"control value 411" = alloca i32, align 4
  %"control value 412" = alloca i32, align 4
  %"control value 413" = alloca i8, align 1
  %"control value 414" = alloca i8, align 1
  %"control value 415" = alloca ptr, align 4
  %"control value 416" = alloca i32, align 4
  %"control value 417" = alloca ptr, align 4
  %"control value 418" = alloca ptr, align 4
  %"control value 419" = alloca ptr, align 4
  %"control value 420" = alloca i32, align 4
  %"control value 421" = alloca ptr, align 4
  %"control value 422" = alloca ptr, align 4
  %"control value 423" = alloca ptr, align 4
  %"control value 424" = alloca i32, align 4
  %"control value 425" = alloca i32, align 4
  %"control value 426" = alloca i32, align 4
  %"control value 427" = alloca ptr, align 4
  %"control value 428" = alloca ptr, align 4
  %"control value 429" = alloca ptr, align 4
  %"control value 430" = alloca i32, align 4
  %"control value 431" = alloca i32, align 4
  %"control value 432" = alloca i32, align 4
  %"control value 433" = alloca ptr, align 4
  %"control value 434" = alloca ptr, align 4
  %"control value 435" = alloca ptr, align 4
  %"control value 436" = alloca ptr, align 4
  store ptr %0, ptr %heap, align 1
  store i32 %1, ptr %count, align 1
  store i32 %2, ptr %size, align 1
  %3 = load i32, ptr %count, align 1
  store i32 %3, ptr %"control value 333", align 1
  %4 = load i32, ptr %size, align 1
  store i32 %4, ptr %"control value 334", align 1
  %5 = load i32, ptr %"control value 333", align 1
  %6 = load i32, ptr %"control value 334", align 1
  %7 = call i32 @tower.fn.guest_heap_request_size(i32 %5, i32 %6)
  store i32 %7, ptr %"control value 335", align 1
  %8 = load i32, ptr %"control value 335", align 1
  store i32 %8, ptr %bytes, align 1
  %9 = load i32, ptr %bytes, align 1
  store i32 %9, ptr %"control value 336", align 1
  %10 = load i32, ptr %"control value 336", align 1
  %11 = icmp eq i32 %10, 0
  %12 = zext i1 %11 to i8
  store i8 %12, ptr %"control value 337", align 1
  %13 = load i8, ptr %"control value 337", align 1
  store i8 %13, ptr %overflow, align 1
  %14 = load i8, ptr %overflow, align 1
  store i8 %14, ptr %"control value 338", align 1
  %15 = load i8, ptr %"control value 338", align 1
  %16 = icmp ne i8 %15, 0
  br i1 %16, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  ret ptr null

if.else:                                          ; preds = %entry
  br label %if.end

if.end:                                           ; preds = %if.else
  store i32 16, ptr %"control value 339", align 1
  %17 = load i32, ptr %"control value 339", align 1
  store i32 %17, ptr %header, align 1
  %18 = load ptr, ptr %heap, align 1
  store ptr %18, ptr %"control value 340", align 1
  %19 = load ptr, ptr %"control value 340", align 1
  %20 = getelementptr i8, ptr %19, i32 0
  store ptr %20, ptr %"control value 341", align 1
  %21 = load ptr, ptr %"control value 341", align 1
  store ptr %21, ptr %link, align 1
  br label %loop

loop:                                             ; preds = %if.end8, %if.end
  %22 = load ptr, ptr %link, align 1
  store ptr %22, ptr %"control value 342", align 1
  %23 = load ptr, ptr %"control value 342", align 1
  %24 = load ptr, ptr %23, align 1
  store ptr %24, ptr %"control value 343", align 1
  %25 = load ptr, ptr %"control value 343", align 1
  store ptr %25, ptr %block, align 1
  %26 = load ptr, ptr %block, align 1
  store ptr %26, ptr %"control value 344", align 1
  %27 = load ptr, ptr %"control value 344", align 1
  %28 = icmp eq ptr %27, null
  %29 = zext i1 %28 to i8
  store i8 %29, ptr %"control value 345", align 1
  %30 = load i8, ptr %"control value 345", align 1
  store i8 %30, ptr %absent, align 1
  %31 = load i8, ptr %absent, align 1
  store i8 %31, ptr %"control value 346", align 1
  %32 = load i8, ptr %"control value 346", align 1
  %33 = icmp ne i8 %32, 0
  br i1 %33, label %if.body3, label %if.else4

loop.end:                                         ; preds = %if.body3
  %34 = load ptr, ptr %heap, align 1
  store ptr %34, ptr %"control value 398", align 1
  %35 = load ptr, ptr %"control value 398", align 1
  %36 = getelementptr i8, ptr %35, i32 8
  %37 = load i32, ptr %36, align 1
  store i32 %37, ptr %"control value 399", align 1
  %38 = load ptr, ptr %heap, align 1
  store ptr %38, ptr %"control value 400", align 1
  %39 = load ptr, ptr %"control value 400", align 1
  %40 = getelementptr i8, ptr %39, i32 4
  %41 = load i32, ptr %40, align 1
  store i32 %41, ptr %"control value 401", align 1
  %42 = load i32, ptr %"control value 399", align 1
  %43 = load i32, ptr %"control value 401", align 1
  %44 = sub i32 %42, %43
  store i32 %44, ptr %"control value 402", align 1
  %45 = load i32, ptr %"control value 402", align 1
  store i32 %45, ptr %remaining, align 1
  %46 = load i32, ptr %remaining, align 1
  store i32 %46, ptr %"control value 403", align 1
  %47 = load i32, ptr %header, align 1
  store i32 %47, ptr %"control value 404", align 1
  %48 = load i32, ptr %"control value 403", align 1
  %49 = load i32, ptr %"control value 404", align 1
  %50 = icmp ult i32 %48, %49
  %51 = zext i1 %50 to i8
  store i8 %51, ptr %"control value 405", align 1
  %52 = load i8, ptr %"control value 405", align 1
  store i8 %52, ptr %short_header, align 1
  %53 = load i8, ptr %short_header, align 1
  store i8 %53, ptr %"control value 406", align 1
  %54 = load i8, ptr %"control value 406", align 1
  %55 = icmp ne i8 %54, 0
  br i1 %55, label %if.body12, label %if.else13

if.body3:                                         ; preds = %loop
  br label %loop.end

if.else4:                                         ; preds = %loop
  br label %if.end5

if.end5:                                          ; preds = %if.else4
  %56 = load ptr, ptr %block, align 1
  store ptr %56, ptr %"control value 347", align 1
  %57 = load ptr, ptr %"control value 347", align 1
  %58 = getelementptr i8, ptr %57, i32 0
  %59 = load i32, ptr %58, align 1
  store i32 %59, ptr %"control value 348", align 1
  %60 = load i32, ptr %bytes, align 1
  store i32 %60, ptr %"control value 349", align 1
  %61 = load i32, ptr %"control value 348", align 1
  %62 = load i32, ptr %"control value 349", align 1
  %63 = icmp uge i32 %61, %62
  %64 = zext i1 %63 to i8
  store i8 %64, ptr %"control value 350", align 1
  %65 = load i8, ptr %"control value 350", align 1
  store i8 %65, ptr %enough, align 1
  %66 = load i8, ptr %enough, align 1
  store i8 %66, ptr %"control value 351", align 1
  %67 = load i8, ptr %"control value 351", align 1
  %68 = icmp ne i8 %67, 0
  br i1 %68, label %if.body6, label %if.else7

if.body6:                                         ; preds = %if.end5
  %69 = load ptr, ptr %block, align 1
  store ptr %69, ptr %"control value 352", align 1
  %70 = load ptr, ptr %"control value 352", align 1
  %71 = getelementptr i8, ptr %70, i32 0
  %72 = load i32, ptr %71, align 1
  store i32 %72, ptr %"control value 353", align 1
  %73 = load i32, ptr %bytes, align 1
  store i32 %73, ptr %"control value 354", align 1
  %74 = load i32, ptr %"control value 353", align 1
  %75 = load i32, ptr %"control value 354", align 1
  %76 = sub i32 %74, %75
  store i32 %76, ptr %"control value 355", align 1
  %77 = load i32, ptr %"control value 355", align 1
  store i32 %77, ptr %spare, align 1
  %78 = load i32, ptr %header, align 1
  store i32 %78, ptr %"control value 356", align 1
  %79 = load i32, ptr %"control value 356", align 1
  %80 = add i32 %79, 16
  store i32 %80, ptr %"control value 357", align 1
  %81 = load i32, ptr %"control value 357", align 1
  store i32 %81, ptr %minimum, align 1
  %82 = load i32, ptr %spare, align 1
  store i32 %82, ptr %"control value 358", align 1
  %83 = load i32, ptr %minimum, align 1
  store i32 %83, ptr %"control value 359", align 1
  %84 = load i32, ptr %"control value 358", align 1
  %85 = load i32, ptr %"control value 359", align 1
  %86 = icmp uge i32 %84, %85
  %87 = zext i1 %86 to i8
  store i8 %87, ptr %"control value 360", align 1
  %88 = load i8, ptr %"control value 360", align 1
  store i8 %88, ptr %split, align 1
  %89 = load i8, ptr %split, align 1
  store i8 %89, ptr %"control value 361", align 1
  %90 = load i8, ptr %"control value 361", align 1
  %91 = icmp ne i8 %90, 0
  br i1 %91, label %if.body9, label %if.else10

if.else7:                                         ; preds = %if.end5
  br label %if.end8

if.end8:                                          ; preds = %if.else7
  store ptr %link, ptr %"control value 395", align 1
  %92 = load ptr, ptr %block, align 1
  store ptr %92, ptr %"control value 396", align 1
  %93 = load ptr, ptr %"control value 396", align 1
  %94 = getelementptr i8, ptr %93, i32 4
  store ptr %94, ptr %"control value 397", align 1
  %95 = load ptr, ptr %"control value 395", align 1
  %96 = load ptr, ptr %"control value 397", align 1
  store ptr %96, ptr %95, align 1
  br label %loop

if.body9:                                         ; preds = %if.body6
  %97 = load ptr, ptr %block, align 1
  store ptr %97, ptr %"control value 362", align 1
  %98 = load ptr, ptr %"control value 362", align 1
  store ptr %98, ptr %"control value 363", align 1
  %99 = load ptr, ptr %"control value 363", align 1
  store ptr %99, ptr %data, align 1
  store ptr %data, ptr %"control value 364", align 1
  %100 = load ptr, ptr %data, align 1
  store ptr %100, ptr %"control value 365", align 1
  %101 = load i32, ptr %header, align 1
  store i32 %101, ptr %"control value 366", align 1
  %102 = load ptr, ptr %"control value 365", align 1
  %103 = load i32, ptr %"control value 366", align 1
  %104 = mul i32 %103, 1
  %105 = getelementptr i8, ptr %102, i32 %104
  store ptr %105, ptr %"control value 367", align 1
  %106 = load ptr, ptr %"control value 364", align 1
  %107 = load ptr, ptr %"control value 367", align 1
  store ptr %107, ptr %106, align 1
  store ptr %data, ptr %"control value 368", align 1
  %108 = load ptr, ptr %data, align 1
  store ptr %108, ptr %"control value 369", align 1
  %109 = load i32, ptr %bytes, align 1
  store i32 %109, ptr %"control value 370", align 1
  %110 = load ptr, ptr %"control value 369", align 1
  %111 = load i32, ptr %"control value 370", align 1
  %112 = mul i32 %111, 1
  %113 = getelementptr i8, ptr %110, i32 %112
  store ptr %113, ptr %"control value 371", align 1
  %114 = load ptr, ptr %"control value 368", align 1
  %115 = load ptr, ptr %"control value 371", align 1
  store ptr %115, ptr %114, align 1
  %116 = load ptr, ptr %data, align 1
  store ptr %116, ptr %"control value 372", align 1
  %117 = load ptr, ptr %"control value 372", align 1
  store ptr %117, ptr %"control value 373", align 1
  %118 = load ptr, ptr %"control value 373", align 1
  store ptr %118, ptr %remainder, align 1
  %119 = load ptr, ptr %remainder, align 1
  store ptr %119, ptr %"control value 374", align 1
  %120 = load ptr, ptr %"control value 374", align 1
  %121 = getelementptr i8, ptr %120, i32 0
  store ptr %121, ptr %"control value 375", align 1
  %122 = load i32, ptr %spare, align 1
  store i32 %122, ptr %"control value 376", align 1
  %123 = load i32, ptr %header, align 1
  store i32 %123, ptr %"control value 377", align 1
  %124 = load i32, ptr %"control value 376", align 1
  %125 = load i32, ptr %"control value 377", align 1
  %126 = sub i32 %124, %125
  store i32 %126, ptr %"control value 378", align 1
  %127 = load ptr, ptr %"control value 375", align 1
  %128 = load i32, ptr %"control value 378", align 1
  store i32 %128, ptr %127, align 1
  %129 = load ptr, ptr %remainder, align 1
  store ptr %129, ptr %"control value 379", align 1
  %130 = load ptr, ptr %"control value 379", align 1
  %131 = getelementptr i8, ptr %130, i32 4
  store ptr %131, ptr %"control value 380", align 1
  %132 = load ptr, ptr %block, align 1
  store ptr %132, ptr %"control value 381", align 1
  %133 = load ptr, ptr %"control value 381", align 1
  %134 = getelementptr i8, ptr %133, i32 4
  %135 = load ptr, ptr %134, align 1
  store ptr %135, ptr %"control value 382", align 1
  %136 = load ptr, ptr %"control value 380", align 1
  %137 = load ptr, ptr %"control value 382", align 1
  store ptr %137, ptr %136, align 1
  %138 = load ptr, ptr %link, align 1
  store ptr %138, ptr %"control value 383", align 1
  %139 = load ptr, ptr %remainder, align 1
  store ptr %139, ptr %"control value 384", align 1
  %140 = load ptr, ptr %"control value 383", align 1
  %141 = load ptr, ptr %"control value 384", align 1
  store ptr %141, ptr %140, align 1
  %142 = load ptr, ptr %block, align 1
  store ptr %142, ptr %"control value 385", align 1
  %143 = load ptr, ptr %"control value 385", align 1
  %144 = getelementptr i8, ptr %143, i32 0
  store ptr %144, ptr %"control value 386", align 1
  %145 = load i32, ptr %bytes, align 1
  store i32 %145, ptr %"control value 387", align 1
  %146 = load ptr, ptr %"control value 386", align 1
  %147 = load i32, ptr %"control value 387", align 1
  store i32 %147, ptr %146, align 1
  br label %if.end11

if.else10:                                        ; preds = %if.body6
  %148 = load ptr, ptr %link, align 1
  store ptr %148, ptr %"control value 388", align 1
  %149 = load ptr, ptr %block, align 1
  store ptr %149, ptr %"control value 389", align 1
  %150 = load ptr, ptr %"control value 389", align 1
  %151 = getelementptr i8, ptr %150, i32 4
  %152 = load ptr, ptr %151, align 1
  store ptr %152, ptr %"control value 390", align 1
  %153 = load ptr, ptr %"control value 388", align 1
  %154 = load ptr, ptr %"control value 390", align 1
  store ptr %154, ptr %153, align 1
  br label %if.end11

if.end11:                                         ; preds = %if.else10, %if.body9
  %155 = load ptr, ptr %block, align 1
  store ptr %155, ptr %"control value 391", align 1
  %156 = load ptr, ptr %"control value 391", align 1
  %157 = getelementptr i8, ptr %156, i32 16
  store ptr %157, ptr %"control value 392", align 1
  %158 = load ptr, ptr %"control value 392", align 1
  store ptr %158, ptr %result, align 1
  %159 = load ptr, ptr %result, align 1
  store ptr %159, ptr %"control value 393", align 1
  %160 = load ptr, ptr %"control value 393", align 1
  store ptr %160, ptr %"control value 394", align 1
  %161 = load ptr, ptr %"control value 394", align 1
  ret ptr %161

if.body12:                                        ; preds = %loop.end
  ret ptr null

if.else13:                                        ; preds = %loop.end
  br label %if.end14

if.end14:                                         ; preds = %if.else13
  store ptr %remaining, ptr %"control value 407", align 1
  %162 = load i32, ptr %remaining, align 1
  store i32 %162, ptr %"control value 408", align 1
  %163 = load i32, ptr %header, align 1
  store i32 %163, ptr %"control value 409", align 1
  %164 = load i32, ptr %"control value 408", align 1
  %165 = load i32, ptr %"control value 409", align 1
  %166 = sub i32 %164, %165
  store i32 %166, ptr %"control value 410", align 1
  %167 = load ptr, ptr %"control value 407", align 1
  %168 = load i32, ptr %"control value 410", align 1
  store i32 %168, ptr %167, align 1
  %169 = load i32, ptr %remaining, align 1
  store i32 %169, ptr %"control value 411", align 1
  %170 = load i32, ptr %bytes, align 1
  store i32 %170, ptr %"control value 412", align 1
  %171 = load i32, ptr %"control value 411", align 1
  %172 = load i32, ptr %"control value 412", align 1
  %173 = icmp ult i32 %171, %172
  %174 = zext i1 %173 to i8
  store i8 %174, ptr %"control value 413", align 1
  %175 = load i8, ptr %"control value 413", align 1
  store i8 %175, ptr %short_data, align 1
  %176 = load i8, ptr %short_data, align 1
  store i8 %176, ptr %"control value 414", align 1
  %177 = load i8, ptr %"control value 414", align 1
  %178 = icmp ne i8 %177, 0
  br i1 %178, label %if.body15, label %if.else16

if.body15:                                        ; preds = %if.end14
  ret ptr null

if.else16:                                        ; preds = %if.end14
  br label %if.end17

if.end17:                                         ; preds = %if.else16
  %179 = load ptr, ptr %heap, align 1
  store ptr %179, ptr %"control value 415", align 1
  %180 = load ptr, ptr %"control value 415", align 1
  %181 = getelementptr i8, ptr %180, i32 4
  %182 = load i32, ptr %181, align 1
  store i32 %182, ptr %"control value 416", align 1
  %183 = load i32, ptr %"control value 416", align 1
  %184 = inttoptr i32 %183 to ptr
  store ptr %184, ptr %"control value 417", align 1
  %185 = load ptr, ptr %"control value 417", align 1
  store ptr %185, ptr %block1, align 1
  %186 = load ptr, ptr %block1, align 1
  store ptr %186, ptr %"control value 418", align 1
  %187 = load ptr, ptr %"control value 418", align 1
  %188 = getelementptr i8, ptr %187, i32 0
  store ptr %188, ptr %"control value 419", align 1
  %189 = load i32, ptr %bytes, align 1
  store i32 %189, ptr %"control value 420", align 1
  %190 = load ptr, ptr %"control value 419", align 1
  %191 = load i32, ptr %"control value 420", align 1
  store i32 %191, ptr %190, align 1
  %192 = load ptr, ptr %heap, align 1
  store ptr %192, ptr %"control value 421", align 1
  %193 = load ptr, ptr %"control value 421", align 1
  %194 = getelementptr i8, ptr %193, i32 4
  store ptr %194, ptr %"control value 422", align 1
  %195 = load ptr, ptr %heap, align 1
  store ptr %195, ptr %"control value 423", align 1
  %196 = load ptr, ptr %"control value 423", align 1
  %197 = getelementptr i8, ptr %196, i32 4
  %198 = load i32, ptr %197, align 1
  store i32 %198, ptr %"control value 424", align 1
  %199 = load i32, ptr %header, align 1
  store i32 %199, ptr %"control value 425", align 1
  %200 = load i32, ptr %"control value 424", align 1
  %201 = load i32, ptr %"control value 425", align 1
  %202 = add i32 %200, %201
  store i32 %202, ptr %"control value 426", align 1
  %203 = load ptr, ptr %"control value 422", align 1
  %204 = load i32, ptr %"control value 426", align 1
  store i32 %204, ptr %203, align 1
  %205 = load ptr, ptr %heap, align 1
  store ptr %205, ptr %"control value 427", align 1
  %206 = load ptr, ptr %"control value 427", align 1
  %207 = getelementptr i8, ptr %206, i32 4
  store ptr %207, ptr %"control value 428", align 1
  %208 = load ptr, ptr %heap, align 1
  store ptr %208, ptr %"control value 429", align 1
  %209 = load ptr, ptr %"control value 429", align 1
  %210 = getelementptr i8, ptr %209, i32 4
  %211 = load i32, ptr %210, align 1
  store i32 %211, ptr %"control value 430", align 1
  %212 = load i32, ptr %bytes, align 1
  store i32 %212, ptr %"control value 431", align 1
  %213 = load i32, ptr %"control value 430", align 1
  %214 = load i32, ptr %"control value 431", align 1
  %215 = add i32 %213, %214
  store i32 %215, ptr %"control value 432", align 1
  %216 = load ptr, ptr %"control value 428", align 1
  %217 = load i32, ptr %"control value 432", align 1
  store i32 %217, ptr %216, align 1
  %218 = load ptr, ptr %block1, align 1
  store ptr %218, ptr %"control value 433", align 1
  %219 = load ptr, ptr %"control value 433", align 1
  %220 = getelementptr i8, ptr %219, i32 16
  store ptr %220, ptr %"control value 434", align 1
  %221 = load ptr, ptr %"control value 434", align 1
  store ptr %221, ptr %result2, align 1
  %222 = load ptr, ptr %result2, align 1
  store ptr %222, ptr %"control value 435", align 1
  %223 = load ptr, ptr %"control value 435", align 1
  store ptr %223, ptr %"control value 436", align 1
  %224 = load ptr, ptr %"control value 436", align 1
  ret ptr %224
}

define internal void @tower.fn.guest_heap_merge(ptr %0) {
entry:
  %block = alloca ptr, align 4
  %next = alloca ptr, align 4
  %present = alloca i8, align 1
  %data = alloca ptr, align 4
  %end = alloca ptr, align 4
  %adjacent = alloca i8, align 1
  %"control value 437" = alloca ptr, align 4
  %"control value 438" = alloca ptr, align 4
  %"control value 439" = alloca ptr, align 4
  %"control value 440" = alloca i8, align 1
  %"control value 441" = alloca i8, align 1
  %"control value 442" = alloca ptr, align 4
  %"control value 443" = alloca ptr, align 4
  %"control value 444" = alloca ptr, align 4
  %"control value 445" = alloca ptr, align 4
  %"control value 446" = alloca ptr, align 4
  %"control value 447" = alloca ptr, align 4
  %"control value 448" = alloca ptr, align 4
  %"control value 449" = alloca i32, align 4
  %"control value 450" = alloca ptr, align 4
  %"control value 451" = alloca ptr, align 4
  %"control value 452" = alloca ptr, align 4
  %"control value 453" = alloca ptr, align 4
  %"control value 454" = alloca i8, align 1
  %"control value 455" = alloca i8, align 1
  %"control value 456" = alloca ptr, align 4
  %"control value 457" = alloca ptr, align 4
  %"control value 458" = alloca ptr, align 4
  %"control value 459" = alloca i32, align 4
  %"control value 460" = alloca i32, align 4
  %"control value 461" = alloca i32, align 4
  %"control value 462" = alloca ptr, align 4
  %"control value 463" = alloca ptr, align 4
  %"control value 464" = alloca ptr, align 4
  %"control value 465" = alloca i32, align 4
  %"control value 466" = alloca ptr, align 4
  %"control value 467" = alloca i32, align 4
  %"control value 468" = alloca i32, align 4
  %"control value 469" = alloca ptr, align 4
  %"control value 470" = alloca ptr, align 4
  %"control value 471" = alloca ptr, align 4
  %"control value 472" = alloca ptr, align 4
  store ptr %0, ptr %block, align 1
  %1 = load ptr, ptr %block, align 1
  store ptr %1, ptr %"control value 437", align 1
  %2 = load ptr, ptr %"control value 437", align 1
  %3 = getelementptr i8, ptr %2, i32 4
  %4 = load ptr, ptr %3, align 1
  store ptr %4, ptr %"control value 438", align 1
  %5 = load ptr, ptr %"control value 438", align 1
  store ptr %5, ptr %next, align 1
  %6 = load ptr, ptr %next, align 1
  store ptr %6, ptr %"control value 439", align 1
  %7 = load ptr, ptr %"control value 439", align 1
  %8 = icmp ne ptr %7, null
  %9 = zext i1 %8 to i8
  store i8 %9, ptr %"control value 440", align 1
  %10 = load i8, ptr %"control value 440", align 1
  store i8 %10, ptr %present, align 1
  %11 = load i8, ptr %present, align 1
  store i8 %11, ptr %"control value 441", align 1
  %12 = load i8, ptr %"control value 441", align 1
  %13 = icmp ne i8 %12, 0
  br i1 %13, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  %14 = load ptr, ptr %block, align 1
  store ptr %14, ptr %"control value 442", align 1
  %15 = load ptr, ptr %"control value 442", align 1
  %16 = getelementptr i8, ptr %15, i32 16
  store ptr %16, ptr %"control value 443", align 1
  %17 = load ptr, ptr %"control value 443", align 1
  store ptr %17, ptr %data, align 1
  %18 = load ptr, ptr %data, align 1
  store ptr %18, ptr %"control value 444", align 1
  %19 = load ptr, ptr %"control value 444", align 1
  store ptr %19, ptr %"control value 445", align 1
  %20 = load ptr, ptr %"control value 445", align 1
  store ptr %20, ptr %end, align 1
  store ptr %end, ptr %"control value 446", align 1
  %21 = load ptr, ptr %end, align 1
  store ptr %21, ptr %"control value 447", align 1
  %22 = load ptr, ptr %block, align 1
  store ptr %22, ptr %"control value 448", align 1
  %23 = load ptr, ptr %"control value 448", align 1
  %24 = getelementptr i8, ptr %23, i32 0
  %25 = load i32, ptr %24, align 1
  store i32 %25, ptr %"control value 449", align 1
  %26 = load ptr, ptr %"control value 447", align 1
  %27 = load i32, ptr %"control value 449", align 1
  %28 = mul i32 %27, 1
  %29 = getelementptr i8, ptr %26, i32 %28
  store ptr %29, ptr %"control value 450", align 1
  %30 = load ptr, ptr %"control value 446", align 1
  %31 = load ptr, ptr %"control value 450", align 1
  store ptr %31, ptr %30, align 1
  %32 = load ptr, ptr %end, align 1
  store ptr %32, ptr %"control value 451", align 1
  %33 = load ptr, ptr %next, align 1
  store ptr %33, ptr %"control value 452", align 1
  %34 = load ptr, ptr %"control value 452", align 1
  store ptr %34, ptr %"control value 453", align 1
  %35 = load ptr, ptr %"control value 451", align 1
  %36 = load ptr, ptr %"control value 453", align 1
  %37 = icmp eq ptr %35, %36
  %38 = zext i1 %37 to i8
  store i8 %38, ptr %"control value 454", align 1
  %39 = load i8, ptr %"control value 454", align 1
  store i8 %39, ptr %adjacent, align 1
  %40 = load i8, ptr %adjacent, align 1
  store i8 %40, ptr %"control value 455", align 1
  %41 = load i8, ptr %"control value 455", align 1
  %42 = icmp ne i8 %41, 0
  br i1 %42, label %if.body1, label %if.else2

if.else:                                          ; preds = %entry
  br label %if.end

if.end:                                           ; preds = %if.end3, %if.else
  ret void

if.body1:                                         ; preds = %if.body
  %43 = load ptr, ptr %block, align 1
  store ptr %43, ptr %"control value 456", align 1
  %44 = load ptr, ptr %"control value 456", align 1
  %45 = getelementptr i8, ptr %44, i32 0
  store ptr %45, ptr %"control value 457", align 1
  %46 = load ptr, ptr %block, align 1
  store ptr %46, ptr %"control value 458", align 1
  %47 = load ptr, ptr %"control value 458", align 1
  %48 = getelementptr i8, ptr %47, i32 0
  %49 = load i32, ptr %48, align 1
  store i32 %49, ptr %"control value 459", align 1
  store i32 16, ptr %"control value 460", align 1
  %50 = load i32, ptr %"control value 459", align 1
  %51 = load i32, ptr %"control value 460", align 1
  %52 = add i32 %50, %51
  store i32 %52, ptr %"control value 461", align 1
  %53 = load ptr, ptr %"control value 457", align 1
  %54 = load i32, ptr %"control value 461", align 1
  store i32 %54, ptr %53, align 1
  %55 = load ptr, ptr %block, align 1
  store ptr %55, ptr %"control value 462", align 1
  %56 = load ptr, ptr %"control value 462", align 1
  %57 = getelementptr i8, ptr %56, i32 0
  store ptr %57, ptr %"control value 463", align 1
  %58 = load ptr, ptr %block, align 1
  store ptr %58, ptr %"control value 464", align 1
  %59 = load ptr, ptr %"control value 464", align 1
  %60 = getelementptr i8, ptr %59, i32 0
  %61 = load i32, ptr %60, align 1
  store i32 %61, ptr %"control value 465", align 1
  %62 = load ptr, ptr %next, align 1
  store ptr %62, ptr %"control value 466", align 1
  %63 = load ptr, ptr %"control value 466", align 1
  %64 = getelementptr i8, ptr %63, i32 0
  %65 = load i32, ptr %64, align 1
  store i32 %65, ptr %"control value 467", align 1
  %66 = load i32, ptr %"control value 465", align 1
  %67 = load i32, ptr %"control value 467", align 1
  %68 = add i32 %66, %67
  store i32 %68, ptr %"control value 468", align 1
  %69 = load ptr, ptr %"control value 463", align 1
  %70 = load i32, ptr %"control value 468", align 1
  store i32 %70, ptr %69, align 1
  %71 = load ptr, ptr %block, align 1
  store ptr %71, ptr %"control value 469", align 1
  %72 = load ptr, ptr %"control value 469", align 1
  %73 = getelementptr i8, ptr %72, i32 4
  store ptr %73, ptr %"control value 470", align 1
  %74 = load ptr, ptr %next, align 1
  store ptr %74, ptr %"control value 471", align 1
  %75 = load ptr, ptr %"control value 471", align 1
  %76 = getelementptr i8, ptr %75, i32 4
  %77 = load ptr, ptr %76, align 1
  store ptr %77, ptr %"control value 472", align 1
  %78 = load ptr, ptr %"control value 470", align 1
  %79 = load ptr, ptr %"control value 472", align 1
  store ptr %79, ptr %78, align 1
  br label %if.end3

if.else2:                                         ; preds = %if.body
  br label %if.end3

if.end3:                                          ; preds = %if.else2, %if.body1
  br label %if.end
}

define void @guest_heap_free(ptr %0, ptr %1) {
entry:
  %heap = alloca ptr, align 4
  %pointer = alloca ptr, align 4
  %absent = alloca i8, align 1
  %block = alloca ptr, align 4
  %address = alloca i32, align 4
  %previous = alloca ptr, align 4
  %link = alloca ptr, align 4
  %previous_link = alloca ptr, align 4
  %next = alloca ptr, align 4
  %follows = alloca i8, align 1
  %present = alloca i8, align 1
  %data = alloca ptr, align 4
  %previous_end = alloca ptr, align 4
  %adjacent = alloca i8, align 1
  %data1 = alloca ptr, align 4
  %end = alloca i32, align 4
  %tail = alloca i8, align 1
  %"control value 473" = alloca ptr, align 4
  %"control value 474" = alloca i8, align 1
  %"control value 475" = alloca i8, align 1
  %"control value 476" = alloca ptr, align 4
  %"control value 477" = alloca ptr, align 4
  %"control value 478" = alloca ptr, align 4
  %"control value 479" = alloca ptr, align 4
  %"control value 480" = alloca ptr, align 4
  %"control value 481" = alloca ptr, align 4
  %"control value 482" = alloca i32, align 4
  %"control value 483" = alloca ptr, align 4
  %"control value 484" = alloca ptr, align 4
  %"control value 485" = alloca ptr, align 4
  %"control value 486" = alloca ptr, align 4
  %"control value 487" = alloca ptr, align 4
  %"control value 488" = alloca ptr, align 4
  %"control value 489" = alloca ptr, align 4
  %"control value 490" = alloca i8, align 1
  %"control value 491" = alloca i8, align 1
  %"control value 492" = alloca ptr, align 4
  %"control value 493" = alloca i32, align 4
  %"control value 494" = alloca i32, align 4
  %"control value 495" = alloca i8, align 1
  %"control value 496" = alloca i8, align 1
  %"control value 497" = alloca ptr, align 4
  %"control value 498" = alloca ptr, align 4
  %"control value 499" = alloca ptr, align 4
  %"control value 500" = alloca ptr, align 4
  %"control value 501" = alloca ptr, align 4
  %"control value 502" = alloca ptr, align 4
  %"control value 503" = alloca ptr, align 4
  %"control value 504" = alloca ptr, align 4
  %"control value 505" = alloca ptr, align 4
  %"control value 506" = alloca ptr, align 4
  %"control value 507" = alloca ptr, align 4
  %"control value 508" = alloca ptr, align 4
  %"control value 509" = alloca ptr, align 4
  %"control value 510" = alloca ptr, align 4
  %"control value 511" = alloca ptr, align 4
  %"control value 512" = alloca i8, align 1
  %"control value 513" = alloca i8, align 1
  %"control value 514" = alloca ptr, align 4
  %"control value 515" = alloca ptr, align 4
  %"control value 516" = alloca ptr, align 4
  %"control value 517" = alloca ptr, align 4
  %"control value 518" = alloca ptr, align 4
  %"control value 519" = alloca ptr, align 4
  %"control value 520" = alloca ptr, align 4
  %"control value 521" = alloca i32, align 4
  %"control value 522" = alloca ptr, align 4
  %"control value 523" = alloca ptr, align 4
  %"control value 524" = alloca ptr, align 4
  %"control value 525" = alloca ptr, align 4
  %"control value 526" = alloca i8, align 1
  %"control value 527" = alloca ptr, align 4
  %"control value 528" = alloca i8, align 1
  %"control value 529" = alloca ptr, align 4
  %"control value 530" = alloca ptr, align 4
  %"control value 531" = alloca ptr, align 4
  %"control value 532" = alloca ptr, align 4
  %"control value 533" = alloca ptr, align 4
  %"control value 534" = alloca ptr, align 4
  %"control value 535" = alloca ptr, align 4
  %"control value 536" = alloca i32, align 4
  %"control value 537" = alloca ptr, align 4
  %"control value 538" = alloca i32, align 4
  %"control value 539" = alloca i32, align 4
  %"control value 540" = alloca i32, align 4
  %"control value 541" = alloca ptr, align 4
  %"control value 542" = alloca i32, align 4
  %"control value 543" = alloca i8, align 1
  %"control value 544" = alloca i8, align 1
  %"control value 545" = alloca ptr, align 4
  %"control value 546" = alloca ptr, align 4
  %"control value 547" = alloca ptr, align 4
  %"control value 548" = alloca i32, align 4
  %"control value 549" = alloca ptr, align 4
  %"control value 550" = alloca ptr, align 4
  %"control value 551" = alloca ptr, align 4
  store ptr %0, ptr %heap, align 1
  store ptr %1, ptr %pointer, align 1
  %2 = load ptr, ptr %pointer, align 1
  store ptr %2, ptr %"control value 473", align 1
  %3 = load ptr, ptr %"control value 473", align 1
  %4 = icmp eq ptr %3, null
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %"control value 474", align 1
  %6 = load i8, ptr %"control value 474", align 1
  store i8 %6, ptr %absent, align 1
  %7 = load i8, ptr %absent, align 1
  store i8 %7, ptr %"control value 475", align 1
  %8 = load i8, ptr %"control value 475", align 1
  %9 = icmp ne i8 %8, 0
  br i1 %9, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  ret void

if.else:                                          ; preds = %entry
  br label %if.end

if.end:                                           ; preds = %if.else
  %10 = load ptr, ptr %pointer, align 1
  store ptr %10, ptr %"control value 476", align 1
  %11 = load ptr, ptr %"control value 476", align 1
  store ptr %11, ptr %"control value 477", align 1
  %12 = load ptr, ptr %"control value 477", align 1
  store ptr %12, ptr %block, align 1
  store ptr %block, ptr %"control value 478", align 1
  %13 = load ptr, ptr %"control value 478", align 1
  %14 = load ptr, ptr %13, align 1
  store ptr %14, ptr %"control value 479", align 1
  %15 = load ptr, ptr %"control value 479", align 1
  %16 = getelementptr i8, ptr %15, i32 -16
  store ptr %16, ptr %"control value 480", align 1
  %17 = load ptr, ptr %"control value 478", align 1
  %18 = load ptr, ptr %"control value 480", align 1
  store ptr %18, ptr %17, align 1
  %19 = load ptr, ptr %block, align 1
  store ptr %19, ptr %"control value 481", align 1
  %20 = load ptr, ptr %"control value 481", align 1
  %21 = ptrtoint ptr %20 to i32
  store i32 %21, ptr %"control value 482", align 1
  %22 = load i32, ptr %"control value 482", align 1
  store i32 %22, ptr %address, align 1
  store ptr null, ptr %previous, align 1
  %23 = load ptr, ptr %heap, align 1
  store ptr %23, ptr %"control value 483", align 1
  %24 = load ptr, ptr %"control value 483", align 1
  %25 = getelementptr i8, ptr %24, i32 0
  store ptr %25, ptr %"control value 484", align 1
  %26 = load ptr, ptr %"control value 484", align 1
  store ptr %26, ptr %link, align 1
  %27 = load ptr, ptr %link, align 1
  store ptr %27, ptr %"control value 485", align 1
  %28 = load ptr, ptr %"control value 485", align 1
  store ptr %28, ptr %previous_link, align 1
  br label %loop

loop:                                             ; preds = %if.end7, %if.end
  %29 = load ptr, ptr %link, align 1
  store ptr %29, ptr %"control value 486", align 1
  %30 = load ptr, ptr %"control value 486", align 1
  %31 = load ptr, ptr %30, align 1
  store ptr %31, ptr %"control value 487", align 1
  %32 = load ptr, ptr %"control value 487", align 1
  store ptr %32, ptr %next, align 1
  store ptr %absent, ptr %"control value 488", align 1
  %33 = load ptr, ptr %next, align 1
  store ptr %33, ptr %"control value 489", align 1
  %34 = load ptr, ptr %"control value 489", align 1
  %35 = icmp eq ptr %34, null
  %36 = zext i1 %35 to i8
  store i8 %36, ptr %"control value 490", align 1
  %37 = load ptr, ptr %"control value 488", align 1
  %38 = load i8, ptr %"control value 490", align 1
  store i8 %38, ptr %37, align 1
  %39 = load i8, ptr %absent, align 1
  store i8 %39, ptr %"control value 491", align 1
  %40 = load i8, ptr %"control value 491", align 1
  %41 = icmp ne i8 %40, 0
  br i1 %41, label %if.body2, label %if.else3

loop.end:                                         ; preds = %if.body5, %if.body2
  %42 = load ptr, ptr %block, align 1
  store ptr %42, ptr %"control value 504", align 1
  %43 = load ptr, ptr %"control value 504", align 1
  %44 = getelementptr i8, ptr %43, i32 4
  store ptr %44, ptr %"control value 505", align 1
  %45 = load ptr, ptr %link, align 1
  store ptr %45, ptr %"control value 506", align 1
  %46 = load ptr, ptr %"control value 506", align 1
  %47 = load ptr, ptr %46, align 1
  store ptr %47, ptr %"control value 507", align 1
  %48 = load ptr, ptr %"control value 505", align 1
  %49 = load ptr, ptr %"control value 507", align 1
  store ptr %49, ptr %48, align 1
  %50 = load ptr, ptr %link, align 1
  store ptr %50, ptr %"control value 508", align 1
  %51 = load ptr, ptr %block, align 1
  store ptr %51, ptr %"control value 509", align 1
  %52 = load ptr, ptr %"control value 508", align 1
  %53 = load ptr, ptr %"control value 509", align 1
  store ptr %53, ptr %52, align 1
  %54 = load ptr, ptr %block, align 1
  store ptr %54, ptr %"control value 510", align 1
  %55 = load ptr, ptr %"control value 510", align 1
  call void @tower.fn.guest_heap_merge(ptr %55)
  %56 = load ptr, ptr %previous, align 1
  store ptr %56, ptr %"control value 511", align 1
  %57 = load ptr, ptr %"control value 511", align 1
  %58 = icmp ne ptr %57, null
  %59 = zext i1 %58 to i8
  store i8 %59, ptr %"control value 512", align 1
  %60 = load i8, ptr %"control value 512", align 1
  store i8 %60, ptr %present, align 1
  %61 = load i8, ptr %present, align 1
  store i8 %61, ptr %"control value 513", align 1
  %62 = load i8, ptr %"control value 513", align 1
  %63 = icmp ne i8 %62, 0
  br i1 %63, label %if.body8, label %if.else9

if.body2:                                         ; preds = %loop
  br label %loop.end

if.else3:                                         ; preds = %loop
  br label %if.end4

if.end4:                                          ; preds = %if.else3
  %64 = load ptr, ptr %next, align 1
  store ptr %64, ptr %"control value 492", align 1
  %65 = load ptr, ptr %"control value 492", align 1
  %66 = ptrtoint ptr %65 to i32
  store i32 %66, ptr %"control value 493", align 1
  %67 = load i32, ptr %address, align 1
  store i32 %67, ptr %"control value 494", align 1
  %68 = load i32, ptr %"control value 493", align 1
  %69 = load i32, ptr %"control value 494", align 1
  %70 = icmp uge i32 %68, %69
  %71 = zext i1 %70 to i8
  store i8 %71, ptr %"control value 495", align 1
  %72 = load i8, ptr %"control value 495", align 1
  store i8 %72, ptr %follows, align 1
  %73 = load i8, ptr %follows, align 1
  store i8 %73, ptr %"control value 496", align 1
  %74 = load i8, ptr %"control value 496", align 1
  %75 = icmp ne i8 %74, 0
  br i1 %75, label %if.body5, label %if.else6

if.body5:                                         ; preds = %if.end4
  br label %loop.end

if.else6:                                         ; preds = %if.end4
  br label %if.end7

if.end7:                                          ; preds = %if.else6
  store ptr %previous, ptr %"control value 497", align 1
  %76 = load ptr, ptr %next, align 1
  store ptr %76, ptr %"control value 498", align 1
  %77 = load ptr, ptr %"control value 497", align 1
  %78 = load ptr, ptr %"control value 498", align 1
  store ptr %78, ptr %77, align 1
  store ptr %previous_link, ptr %"control value 499", align 1
  %79 = load ptr, ptr %link, align 1
  store ptr %79, ptr %"control value 500", align 1
  %80 = load ptr, ptr %"control value 499", align 1
  %81 = load ptr, ptr %"control value 500", align 1
  store ptr %81, ptr %80, align 1
  store ptr %link, ptr %"control value 501", align 1
  %82 = load ptr, ptr %next, align 1
  store ptr %82, ptr %"control value 502", align 1
  %83 = load ptr, ptr %"control value 502", align 1
  %84 = getelementptr i8, ptr %83, i32 4
  store ptr %84, ptr %"control value 503", align 1
  %85 = load ptr, ptr %"control value 501", align 1
  %86 = load ptr, ptr %"control value 503", align 1
  store ptr %86, ptr %85, align 1
  br label %loop

if.body8:                                         ; preds = %loop.end
  %87 = load ptr, ptr %previous, align 1
  store ptr %87, ptr %"control value 514", align 1
  %88 = load ptr, ptr %"control value 514", align 1
  %89 = getelementptr i8, ptr %88, i32 16
  store ptr %89, ptr %"control value 515", align 1
  %90 = load ptr, ptr %"control value 515", align 1
  store ptr %90, ptr %data, align 1
  %91 = load ptr, ptr %data, align 1
  store ptr %91, ptr %"control value 516", align 1
  %92 = load ptr, ptr %"control value 516", align 1
  store ptr %92, ptr %"control value 517", align 1
  %93 = load ptr, ptr %"control value 517", align 1
  store ptr %93, ptr %previous_end, align 1
  store ptr %previous_end, ptr %"control value 518", align 1
  %94 = load ptr, ptr %previous_end, align 1
  store ptr %94, ptr %"control value 519", align 1
  %95 = load ptr, ptr %previous, align 1
  store ptr %95, ptr %"control value 520", align 1
  %96 = load ptr, ptr %"control value 520", align 1
  %97 = getelementptr i8, ptr %96, i32 0
  %98 = load i32, ptr %97, align 1
  store i32 %98, ptr %"control value 521", align 1
  %99 = load ptr, ptr %"control value 519", align 1
  %100 = load i32, ptr %"control value 521", align 1
  %101 = mul i32 %100, 1
  %102 = getelementptr i8, ptr %99, i32 %101
  store ptr %102, ptr %"control value 522", align 1
  %103 = load ptr, ptr %"control value 518", align 1
  %104 = load ptr, ptr %"control value 522", align 1
  store ptr %104, ptr %103, align 1
  %105 = load ptr, ptr %previous_end, align 1
  store ptr %105, ptr %"control value 523", align 1
  %106 = load ptr, ptr %block, align 1
  store ptr %106, ptr %"control value 524", align 1
  %107 = load ptr, ptr %"control value 524", align 1
  store ptr %107, ptr %"control value 525", align 1
  %108 = load ptr, ptr %"control value 523", align 1
  %109 = load ptr, ptr %"control value 525", align 1
  %110 = icmp eq ptr %108, %109
  %111 = zext i1 %110 to i8
  store i8 %111, ptr %"control value 526", align 1
  %112 = load i8, ptr %"control value 526", align 1
  store i8 %112, ptr %adjacent, align 1
  %113 = load ptr, ptr %previous, align 1
  store ptr %113, ptr %"control value 527", align 1
  %114 = load ptr, ptr %"control value 527", align 1
  call void @tower.fn.guest_heap_merge(ptr %114)
  %115 = load i8, ptr %adjacent, align 1
  store i8 %115, ptr %"control value 528", align 1
  %116 = load i8, ptr %"control value 528", align 1
  %117 = icmp ne i8 %116, 0
  br i1 %117, label %if.body11, label %if.else12

if.else9:                                         ; preds = %loop.end
  br label %if.end10

if.end10:                                         ; preds = %if.end13, %if.else9
  %118 = load ptr, ptr %block, align 1
  store ptr %118, ptr %"control value 533", align 1
  %119 = load ptr, ptr %"control value 533", align 1
  %120 = getelementptr i8, ptr %119, i32 16
  store ptr %120, ptr %"control value 534", align 1
  %121 = load ptr, ptr %"control value 534", align 1
  store ptr %121, ptr %data1, align 1
  %122 = load ptr, ptr %data1, align 1
  store ptr %122, ptr %"control value 535", align 1
  %123 = load ptr, ptr %"control value 535", align 1
  %124 = ptrtoint ptr %123 to i32
  store i32 %124, ptr %"control value 536", align 1
  %125 = load ptr, ptr %block, align 1
  store ptr %125, ptr %"control value 537", align 1
  %126 = load ptr, ptr %"control value 537", align 1
  %127 = getelementptr i8, ptr %126, i32 0
  %128 = load i32, ptr %127, align 1
  store i32 %128, ptr %"control value 538", align 1
  %129 = load i32, ptr %"control value 536", align 1
  %130 = load i32, ptr %"control value 538", align 1
  %131 = add i32 %129, %130
  store i32 %131, ptr %"control value 539", align 1
  %132 = load i32, ptr %"control value 539", align 1
  store i32 %132, ptr %end, align 1
  %133 = load i32, ptr %end, align 1
  store i32 %133, ptr %"control value 540", align 1
  %134 = load ptr, ptr %heap, align 1
  store ptr %134, ptr %"control value 541", align 1
  %135 = load ptr, ptr %"control value 541", align 1
  %136 = getelementptr i8, ptr %135, i32 4
  %137 = load i32, ptr %136, align 1
  store i32 %137, ptr %"control value 542", align 1
  %138 = load i32, ptr %"control value 540", align 1
  %139 = load i32, ptr %"control value 542", align 1
  %140 = icmp eq i32 %138, %139
  %141 = zext i1 %140 to i8
  store i8 %141, ptr %"control value 543", align 1
  %142 = load i8, ptr %"control value 543", align 1
  store i8 %142, ptr %tail, align 1
  %143 = load i8, ptr %tail, align 1
  store i8 %143, ptr %"control value 544", align 1
  %144 = load i8, ptr %"control value 544", align 1
  %145 = icmp ne i8 %144, 0
  br i1 %145, label %if.body14, label %if.else15

if.body11:                                        ; preds = %if.body8
  store ptr %block, ptr %"control value 529", align 1
  %146 = load ptr, ptr %previous, align 1
  store ptr %146, ptr %"control value 530", align 1
  %147 = load ptr, ptr %"control value 529", align 1
  %148 = load ptr, ptr %"control value 530", align 1
  store ptr %148, ptr %147, align 1
  store ptr %link, ptr %"control value 531", align 1
  %149 = load ptr, ptr %previous_link, align 1
  store ptr %149, ptr %"control value 532", align 1
  %150 = load ptr, ptr %"control value 531", align 1
  %151 = load ptr, ptr %"control value 532", align 1
  store ptr %151, ptr %150, align 1
  br label %if.end13

if.else12:                                        ; preds = %if.body8
  br label %if.end13

if.end13:                                         ; preds = %if.else12, %if.body11
  br label %if.end10

if.body14:                                        ; preds = %if.end10
  %152 = load ptr, ptr %heap, align 1
  store ptr %152, ptr %"control value 545", align 1
  %153 = load ptr, ptr %"control value 545", align 1
  %154 = getelementptr i8, ptr %153, i32 4
  store ptr %154, ptr %"control value 546", align 1
  %155 = load ptr, ptr %block, align 1
  store ptr %155, ptr %"control value 547", align 1
  %156 = load ptr, ptr %"control value 547", align 1
  %157 = ptrtoint ptr %156 to i32
  store i32 %157, ptr %"control value 548", align 1
  %158 = load ptr, ptr %"control value 546", align 1
  %159 = load i32, ptr %"control value 548", align 1
  store i32 %159, ptr %158, align 1
  %160 = load ptr, ptr %link, align 1
  store ptr %160, ptr %"control value 549", align 1
  %161 = load ptr, ptr %block, align 1
  store ptr %161, ptr %"control value 550", align 1
  %162 = load ptr, ptr %"control value 550", align 1
  %163 = getelementptr i8, ptr %162, i32 4
  %164 = load ptr, ptr %163, align 1
  store ptr %164, ptr %"control value 551", align 1
  %165 = load ptr, ptr %"control value 549", align 1
  %166 = load ptr, ptr %"control value 551", align 1
  store ptr %166, ptr %165, align 1
  br label %if.end16

if.else15:                                        ; preds = %if.end10
  br label %if.end16

if.end16:                                         ; preds = %if.else15, %if.body14
  ret void
}

define ptr @guest_heap_reallocate(ptr %0, ptr %1, i32 %2, i32 %3) {
entry:
  %heap = alloca ptr, align 4
  %pointer = alloca ptr, align 4
  %count = alloca i32, align 4
  %size = alloca i32, align 4
  %maximum = alloca i32, align 4
  %sized = alloca i8, align 1
  %limit = alloca i32, align 4
  %overflow = alloca i8, align 1
  %absent = alloca i8, align 1
  %bytes = alloca i32, align 4
  %empty = alloca i8, align 1
  %block = alloca ptr, align 4
  %enough = alloca i8, align 1
  %result = alloca ptr, align 4
  %ok = alloca i8, align 1
  %"control value 552" = alloca ptr, align 4
  %"control value 553" = alloca i32, align 4
  %"control value 554" = alloca i32, align 4
  %"control value 555" = alloca i32, align 4
  %"control value 556" = alloca i8, align 1
  %"control value 557" = alloca i8, align 1
  %"control value 558" = alloca i32, align 4
  %"control value 559" = alloca i32, align 4
  %"control value 560" = alloca i32, align 4
  %"control value 561" = alloca i32, align 4
  %"control value 562" = alloca i32, align 4
  %"control value 563" = alloca i8, align 1
  %"control value 564" = alloca i8, align 1
  %"control value 565" = alloca ptr, align 4
  %"control value 566" = alloca i8, align 1
  %"control value 567" = alloca i8, align 1
  %"control value 568" = alloca ptr, align 4
  %"control value 569" = alloca i32, align 4
  %"control value 570" = alloca i32, align 4
  %"control value 571" = alloca ptr, align 4
  %"control value 572" = alloca i32, align 4
  %"control value 573" = alloca i32, align 4
  %"control value 574" = alloca i32, align 4
  %"control value 575" = alloca i32, align 4
  %"control value 576" = alloca i8, align 1
  %"control value 577" = alloca i8, align 1
  %"control value 578" = alloca ptr, align 4
  %"control value 579" = alloca ptr, align 4
  %"control value 580" = alloca ptr, align 4
  %"control value 581" = alloca ptr, align 4
  %"control value 582" = alloca ptr, align 4
  %"control value 583" = alloca ptr, align 4
  %"control value 584" = alloca ptr, align 4
  %"control value 585" = alloca ptr, align 4
  %"control value 586" = alloca i32, align 4
  %"control value 587" = alloca i32, align 4
  %"control value 588" = alloca i8, align 1
  %"control value 589" = alloca i8, align 1
  %"control value 590" = alloca ptr, align 4
  %"control value 591" = alloca ptr, align 4
  %"control value 592" = alloca i32, align 4
  %"control value 593" = alloca i32, align 4
  %"control value 594" = alloca ptr, align 4
  %"control value 595" = alloca ptr, align 4
  %"control value 596" = alloca i8, align 1
  %"control value 597" = alloca i8, align 1
  %"control value 598" = alloca ptr, align 4
  %"control value 599" = alloca ptr, align 4
  %"control value 600" = alloca ptr, align 4
  %"control value 601" = alloca i32, align 4
  %"control value 602" = alloca ptr, align 4
  %"control value 603" = alloca ptr, align 4
  %"control value 604" = alloca ptr, align 4
  store ptr %0, ptr %heap, align 1
  store ptr %1, ptr %pointer, align 1
  store i32 %2, ptr %count, align 1
  store i32 %3, ptr %size, align 1
  store i32 0, ptr %maximum, align 1
  store ptr %maximum, ptr %"control value 552", align 1
  %4 = load ptr, ptr %"control value 552", align 1
  %5 = load i32, ptr %4, align 1
  store i32 %5, ptr %"control value 553", align 1
  %6 = load i32, ptr %"control value 553", align 1
  %7 = sub i32 %6, 1
  store i32 %7, ptr %"control value 554", align 1
  %8 = load ptr, ptr %"control value 552", align 1
  %9 = load i32, ptr %"control value 554", align 1
  store i32 %9, ptr %8, align 1
  %10 = load i32, ptr %size, align 1
  store i32 %10, ptr %"control value 555", align 1
  %11 = load i32, ptr %"control value 555", align 1
  %12 = icmp ne i32 %11, 0
  %13 = zext i1 %12 to i8
  store i8 %13, ptr %"control value 556", align 1
  %14 = load i8, ptr %"control value 556", align 1
  store i8 %14, ptr %sized, align 1
  %15 = load i8, ptr %sized, align 1
  store i8 %15, ptr %"control value 557", align 1
  %16 = load i8, ptr %"control value 557", align 1
  %17 = icmp ne i8 %16, 0
  br i1 %17, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  %18 = load i32, ptr %maximum, align 1
  store i32 %18, ptr %"control value 558", align 1
  %19 = load i32, ptr %size, align 1
  store i32 %19, ptr %"control value 559", align 1
  %20 = load i32, ptr %"control value 558", align 1
  %21 = load i32, ptr %"control value 559", align 1
  %22 = icmp ne i32 %21, 0
  br i1 %22, label %valid, label %error

if.else:                                          ; preds = %entry
  br label %if.end

if.end:                                           ; preds = %if.end3, %if.else
  %23 = load ptr, ptr %pointer, align 1
  store ptr %23, ptr %"control value 565", align 1
  %24 = load ptr, ptr %"control value 565", align 1
  %25 = icmp eq ptr %24, null
  %26 = zext i1 %25 to i8
  store i8 %26, ptr %"control value 566", align 1
  %27 = load i8, ptr %"control value 566", align 1
  store i8 %27, ptr %absent, align 1
  %28 = load i8, ptr %absent, align 1
  store i8 %28, ptr %"control value 567", align 1
  %29 = load i8, ptr %"control value 567", align 1
  %30 = icmp ne i8 %29, 0
  br i1 %30, label %if.body4, label %if.else5

valid:                                            ; preds = %if.body
  %31 = udiv i32 %20, %21
  store i32 %31, ptr %"control value 560", align 1
  %32 = load i32, ptr %"control value 560", align 1
  store i32 %32, ptr %limit, align 1
  %33 = load i32, ptr %count, align 1
  store i32 %33, ptr %"control value 561", align 1
  %34 = load i32, ptr %limit, align 1
  store i32 %34, ptr %"control value 562", align 1
  %35 = load i32, ptr %"control value 561", align 1
  %36 = load i32, ptr %"control value 562", align 1
  %37 = icmp ugt i32 %35, %36
  %38 = zext i1 %37 to i8
  store i8 %38, ptr %"control value 563", align 1
  %39 = load i8, ptr %"control value 563", align 1
  store i8 %39, ptr %overflow, align 1
  %40 = load i8, ptr %overflow, align 1
  store i8 %40, ptr %"control value 564", align 1
  %41 = load i8, ptr %"control value 564", align 1
  %42 = icmp ne i8 %41, 0
  br i1 %42, label %if.body1, label %if.else2

error:                                            ; preds = %if.body
  call void @tower_trap(ptr @5, i32 16075)
  unreachable

if.body1:                                         ; preds = %valid
  ret ptr null

if.else2:                                         ; preds = %valid
  br label %if.end3

if.end3:                                          ; preds = %if.else2
  br label %if.end

if.body4:                                         ; preds = %if.end
  %43 = load ptr, ptr %heap, align 1
  store ptr %43, ptr %"control value 568", align 1
  %44 = load i32, ptr %count, align 1
  store i32 %44, ptr %"control value 569", align 1
  %45 = load i32, ptr %size, align 1
  store i32 %45, ptr %"control value 570", align 1
  %46 = load ptr, ptr %"control value 568", align 1
  %47 = load i32, ptr %"control value 569", align 1
  %48 = load i32, ptr %"control value 570", align 1
  %49 = call ptr @guest_heap_allocate(ptr %46, i32 %47, i32 %48) #12
  store ptr %49, ptr %"control value 571", align 1
  %50 = load ptr, ptr %"control value 571", align 1
  ret ptr %50

if.else5:                                         ; preds = %if.end
  br label %if.end6

if.end6:                                          ; preds = %if.else5
  %51 = load i32, ptr %count, align 1
  store i32 %51, ptr %"control value 572", align 1
  %52 = load i32, ptr %size, align 1
  store i32 %52, ptr %"control value 573", align 1
  %53 = load i32, ptr %"control value 572", align 1
  %54 = load i32, ptr %"control value 573", align 1
  %55 = mul i32 %53, %54
  store i32 %55, ptr %"control value 574", align 1
  %56 = load i32, ptr %"control value 574", align 1
  store i32 %56, ptr %bytes, align 1
  %57 = load i32, ptr %bytes, align 1
  store i32 %57, ptr %"control value 575", align 1
  %58 = load i32, ptr %"control value 575", align 1
  %59 = icmp eq i32 %58, 0
  %60 = zext i1 %59 to i8
  store i8 %60, ptr %"control value 576", align 1
  %61 = load i8, ptr %"control value 576", align 1
  store i8 %61, ptr %empty, align 1
  %62 = load i8, ptr %empty, align 1
  store i8 %62, ptr %"control value 577", align 1
  %63 = load i8, ptr %"control value 577", align 1
  %64 = icmp ne i8 %63, 0
  br i1 %64, label %if.body7, label %if.else8

if.body7:                                         ; preds = %if.end6
  %65 = load ptr, ptr %heap, align 1
  store ptr %65, ptr %"control value 578", align 1
  %66 = load ptr, ptr %pointer, align 1
  store ptr %66, ptr %"control value 579", align 1
  %67 = load ptr, ptr %"control value 578", align 1
  %68 = load ptr, ptr %"control value 579", align 1
  call void @guest_heap_free(ptr %67, ptr %68) #13
  ret ptr null

if.else8:                                         ; preds = %if.end6
  br label %if.end9

if.end9:                                          ; preds = %if.else8
  %69 = load ptr, ptr %pointer, align 1
  store ptr %69, ptr %"control value 580", align 1
  %70 = load ptr, ptr %"control value 580", align 1
  store ptr %70, ptr %"control value 581", align 1
  %71 = load ptr, ptr %"control value 581", align 1
  store ptr %71, ptr %block, align 1
  store ptr %block, ptr %"control value 582", align 1
  %72 = load ptr, ptr %"control value 582", align 1
  %73 = load ptr, ptr %72, align 1
  store ptr %73, ptr %"control value 583", align 1
  %74 = load ptr, ptr %"control value 583", align 1
  %75 = getelementptr i8, ptr %74, i32 -16
  store ptr %75, ptr %"control value 584", align 1
  %76 = load ptr, ptr %"control value 582", align 1
  %77 = load ptr, ptr %"control value 584", align 1
  store ptr %77, ptr %76, align 1
  %78 = load ptr, ptr %block, align 1
  store ptr %78, ptr %"control value 585", align 1
  %79 = load ptr, ptr %"control value 585", align 1
  %80 = getelementptr i8, ptr %79, i32 0
  %81 = load i32, ptr %80, align 1
  store i32 %81, ptr %"control value 586", align 1
  %82 = load i32, ptr %bytes, align 1
  store i32 %82, ptr %"control value 587", align 1
  %83 = load i32, ptr %"control value 586", align 1
  %84 = load i32, ptr %"control value 587", align 1
  %85 = icmp uge i32 %83, %84
  %86 = zext i1 %85 to i8
  store i8 %86, ptr %"control value 588", align 1
  %87 = load i8, ptr %"control value 588", align 1
  store i8 %87, ptr %enough, align 1
  %88 = load i8, ptr %enough, align 1
  store i8 %88, ptr %"control value 589", align 1
  %89 = load i8, ptr %"control value 589", align 1
  %90 = icmp ne i8 %89, 0
  br i1 %90, label %if.body10, label %if.else11

if.body10:                                        ; preds = %if.end9
  %91 = load ptr, ptr %pointer, align 1
  store ptr %91, ptr %"control value 590", align 1
  %92 = load ptr, ptr %"control value 590", align 1
  ret ptr %92

if.else11:                                        ; preds = %if.end9
  br label %if.end12

if.end12:                                         ; preds = %if.else11
  %93 = load ptr, ptr %heap, align 1
  store ptr %93, ptr %"control value 591", align 1
  %94 = load i32, ptr %count, align 1
  store i32 %94, ptr %"control value 592", align 1
  %95 = load i32, ptr %size, align 1
  store i32 %95, ptr %"control value 593", align 1
  %96 = load ptr, ptr %"control value 591", align 1
  %97 = load i32, ptr %"control value 592", align 1
  %98 = load i32, ptr %"control value 593", align 1
  %99 = call ptr @guest_heap_allocate(ptr %96, i32 %97, i32 %98) #12
  store ptr %99, ptr %"control value 594", align 1
  %100 = load ptr, ptr %"control value 594", align 1
  store ptr %100, ptr %result, align 1
  %101 = load ptr, ptr %result, align 1
  store ptr %101, ptr %"control value 595", align 1
  %102 = load ptr, ptr %"control value 595", align 1
  %103 = icmp ne ptr %102, null
  %104 = zext i1 %103 to i8
  store i8 %104, ptr %"control value 596", align 1
  %105 = load i8, ptr %"control value 596", align 1
  store i8 %105, ptr %ok, align 1
  %106 = load i8, ptr %ok, align 1
  store i8 %106, ptr %"control value 597", align 1
  %107 = load i8, ptr %"control value 597", align 1
  %108 = icmp ne i8 %107, 0
  br i1 %108, label %if.body13, label %if.else14

if.body13:                                        ; preds = %if.end12
  %109 = load ptr, ptr %result, align 1
  store ptr %109, ptr %"control value 598", align 1
  %110 = load ptr, ptr %pointer, align 1
  store ptr %110, ptr %"control value 599", align 1
  %111 = load ptr, ptr %block, align 1
  store ptr %111, ptr %"control value 600", align 1
  %112 = load ptr, ptr %"control value 600", align 1
  %113 = getelementptr i8, ptr %112, i32 0
  %114 = load i32, ptr %113, align 1
  store i32 %114, ptr %"control value 601", align 1
  %115 = load ptr, ptr %"control value 598", align 1
  %116 = load ptr, ptr %"control value 599", align 1
  %117 = load i32, ptr %"control value 601", align 1
  call void @llvm.memmove.p0.p0.i32(ptr align 1 %115, ptr align 1 %116, i32 %117, i1 false)
  %118 = load ptr, ptr %heap, align 1
  store ptr %118, ptr %"control value 602", align 1
  %119 = load ptr, ptr %pointer, align 1
  store ptr %119, ptr %"control value 603", align 1
  %120 = load ptr, ptr %"control value 602", align 1
  %121 = load ptr, ptr %"control value 603", align 1
  call void @guest_heap_free(ptr %120, ptr %121) #13
  br label %if.end15

if.else14:                                        ; preds = %if.end12
  br label %if.end15

if.end15:                                         ; preds = %if.else14, %if.body13
  %122 = load ptr, ptr %result, align 1
  store ptr %122, ptr %"control value 604", align 1
  %123 = load ptr, ptr %"control value 604", align 1
  ret ptr %123
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare i32 @llvm.wasm.memory.size.i32(i32) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn
declare i32 @llvm.wasm.memory.grow.i32(i32, i32) #3

define internal i32 @tower.fn.guest_wasm_pages() {
entry:
  %"control value 605" = alloca i32, align 4
  %0 = call i32 @llvm.wasm.memory.size.i32(i32 0) #14
  store i32 %0, ptr %"control value 605", align 1
  %1 = load i32, ptr %"control value 605", align 1
  ret i32 %1
}

define internal i32 @tower.fn.guest_wasm_limit(i32 %0) {
entry:
  %pages = alloca i32, align 4
  %limit = alloca i64, align 8
  %full = alloca i8, align 1
  %"control value 606" = alloca i32, align 4
  %"control value 607" = alloca i64, align 8
  %"control value 608" = alloca i64, align 8
  %"control value 609" = alloca i64, align 8
  %"control value 610" = alloca i8, align 1
  %"control value 611" = alloca i8, align 1
  %"control value 612" = alloca ptr, align 4
  %"control value 613" = alloca i64, align 8
  %"control value 614" = alloca i32, align 4
  store i32 %0, ptr %pages, align 1
  %1 = load i32, ptr %pages, align 1
  store i32 %1, ptr %"control value 606", align 1
  %2 = load i32, ptr %"control value 606", align 1
  %3 = zext i32 %2 to i64
  %4 = icmp ule i64 %3, -1
  %5 = and i1 true, %4
  br i1 %5, label %valid, label %error

valid:                                            ; preds = %entry
  %6 = zext i32 %2 to i64
  store i64 %6, ptr %"control value 607", align 1
  %7 = load i64, ptr %"control value 607", align 1
  %8 = mul i64 %7, 65536
  store i64 %8, ptr %"control value 608", align 1
  %9 = load i64, ptr %"control value 608", align 1
  store i64 %9, ptr %limit, align 1
  %10 = load i64, ptr %limit, align 1
  store i64 %10, ptr %"control value 609", align 1
  %11 = load i64, ptr %"control value 609", align 1
  %12 = icmp ugt i64 %11, 4294967295
  %13 = zext i1 %12 to i8
  store i8 %13, ptr %"control value 610", align 1
  %14 = load i8, ptr %"control value 610", align 1
  store i8 %14, ptr %full, align 1
  %15 = load i8, ptr %full, align 1
  store i8 %15, ptr %"control value 611", align 1
  %16 = load i8, ptr %"control value 611", align 1
  %17 = icmp ne i8 %16, 0
  br i1 %17, label %if.body, label %if.else

error:                                            ; preds = %entry
  call void @tower_trap(ptr @6, i32 22672)
  unreachable

if.body:                                          ; preds = %valid
  store ptr %limit, ptr %"control value 612", align 1
  %18 = load ptr, ptr %"control value 612", align 1
  store i64 4294967295, ptr %18, align 1
  br label %if.end

if.else:                                          ; preds = %valid
  br label %if.end

if.end:                                           ; preds = %if.else, %if.body
  %19 = load i64, ptr %limit, align 1
  store i64 %19, ptr %"control value 613", align 1
  %20 = load i64, ptr %"control value 613", align 1
  %21 = icmp ule i64 %20, 4294967295
  %22 = and i1 true, %21
  br i1 %22, label %valid1, label %error2

valid1:                                           ; preds = %if.end
  %23 = trunc i64 %20 to i32
  store i32 %23, ptr %"control value 614", align 1
  %24 = load i32, ptr %"control value 614", align 1
  ret i32 %24

error2:                                           ; preds = %if.end
  call void @tower_trap(ptr @7, i32 22672)
  unreachable
}

define zeroext i8 @guest_wasm_init(ptr %0) {
entry:
  %heap = alloca ptr, align 4
  %pages = alloca i32, align 4
  %full = alloca i8, align 1
  %end = alloca ptr, align 4
  %"control value 615" = alloca i32, align 4
  %"control value 616" = alloca i32, align 4
  %"control value 617" = alloca i8, align 1
  %"control value 618" = alloca i8, align 1
  %"control value 619" = alloca i32, align 4
  %"control value 620" = alloca i32, align 4
  %"control value 621" = alloca ptr, align 4
  %"control value 622" = alloca ptr, align 4
  %"control value 623" = alloca ptr, align 4
  %"control value 624" = alloca ptr, align 4
  %"control value 625" = alloca i8, align 1
  store ptr %0, ptr %heap, align 1
  %1 = call i32 @tower.fn.guest_wasm_pages()
  store i32 %1, ptr %"control value 615", align 1
  %2 = load i32, ptr %"control value 615", align 1
  store i32 %2, ptr %pages, align 1
  %3 = load i32, ptr %pages, align 1
  store i32 %3, ptr %"control value 616", align 1
  %4 = load i32, ptr %"control value 616", align 1
  %5 = icmp uge i32 %4, 65536
  %6 = zext i1 %5 to i8
  store i8 %6, ptr %"control value 617", align 1
  %7 = load i8, ptr %"control value 617", align 1
  store i8 %7, ptr %full, align 1
  %8 = load i8, ptr %full, align 1
  store i8 %8, ptr %"control value 618", align 1
  %9 = load i8, ptr %"control value 618", align 1
  %10 = icmp ne i8 %9, 0
  br i1 %10, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  ret i8 0

if.else:                                          ; preds = %entry
  br label %if.end

if.end:                                           ; preds = %if.else
  %11 = load i32, ptr %pages, align 1
  store i32 %11, ptr %"control value 619", align 1
  %12 = load i32, ptr %"control value 619", align 1
  %13 = call i32 @tower.fn.guest_wasm_limit(i32 %12)
  store i32 %13, ptr %"control value 620", align 1
  %14 = load i32, ptr %"control value 620", align 1
  %15 = inttoptr i32 %14 to ptr
  store ptr %15, ptr %"control value 621", align 1
  %16 = load ptr, ptr %"control value 621", align 1
  store ptr %16, ptr %end, align 1
  %17 = load ptr, ptr %heap, align 1
  store ptr %17, ptr %"control value 622", align 1
  %18 = load ptr, ptr %end, align 1
  store ptr %18, ptr %"control value 623", align 1
  %19 = load ptr, ptr %end, align 1
  store ptr %19, ptr %"control value 624", align 1
  %20 = load ptr, ptr %"control value 622", align 1
  %21 = load ptr, ptr %"control value 623", align 1
  %22 = load ptr, ptr %"control value 624", align 1
  %23 = call zeroext i8 @guest_heap_init(ptr %20, ptr %21, ptr %22) #15
  store i8 %23, ptr %"control value 625", align 1
  %24 = load i8, ptr %"control value 625", align 1
  ret i8 %24
}

define ptr @guest_wasm_allocate(ptr %0, i32 %1, i32 %2) {
entry:
  %heap = alloca ptr, align 4
  %count = alloca i32, align 4
  %size = alloca i32, align 4
  %result = alloca ptr, align 4
  %allocated = alloca i8, align 1
  %bytes = alloca i32, align 4
  %overflow = alloca i8, align 1
  %end = alloca i64, align 8
  %pages = alloca i32, align 4
  %detached = alloca i8, align 1
  %needed = alloca i64, align 8
  %committed = alloca i32, align 4
  %delta = alloca i32, align 4
  %previous = alloca i32, align 4
  %failed = alloca i8, align 1
  %limit = alloca ptr, align 4
  %"control value 626" = alloca ptr, align 4
  %"control value 627" = alloca i32, align 4
  %"control value 628" = alloca i32, align 4
  %"control value 629" = alloca ptr, align 4
  %"control value 630" = alloca ptr, align 4
  %"control value 631" = alloca i8, align 1
  %"control value 632" = alloca i8, align 1
  %"control value 633" = alloca ptr, align 4
  %"control value 634" = alloca i32, align 4
  %"control value 635" = alloca i32, align 4
  %"control value 636" = alloca i32, align 4
  %"control value 637" = alloca i32, align 4
  %"control value 638" = alloca i8, align 1
  %"control value 639" = alloca i8, align 1
  %"control value 640" = alloca ptr, align 4
  %"control value 641" = alloca i32, align 4
  %"control value 642" = alloca i64, align 8
  %"control value 643" = alloca i32, align 4
  %"control value 644" = alloca i64, align 8
  %"control value 645" = alloca i64, align 8
  %"control value 646" = alloca ptr, align 4
  %"control value 647" = alloca i64, align 8
  %"control value 648" = alloca i32, align 4
  %"control value 649" = alloca i64, align 8
  %"control value 650" = alloca i64, align 8
  %"control value 651" = alloca ptr, align 4
  %"control value 652" = alloca i64, align 8
  %"control value 653" = alloca i8, align 1
  %"control value 654" = alloca i8, align 1
  %"control value 655" = alloca i32, align 4
  %"control value 656" = alloca ptr, align 4
  %"control value 657" = alloca i32, align 4
  %"control value 658" = alloca i32, align 4
  %"control value 659" = alloca i32, align 4
  %"control value 660" = alloca i8, align 1
  %"control value 661" = alloca i8, align 1
  %"control value 662" = alloca i64, align 8
  %"control value 663" = alloca i64, align 8
  %"control value 664" = alloca ptr, align 4
  %"control value 665" = alloca i64, align 8
  %"control value 666" = alloca i64, align 8
  %"control value 667" = alloca i64, align 8
  %"control value 668" = alloca i32, align 4
  %"control value 669" = alloca i32, align 4
  %"control value 670" = alloca i32, align 4
  %"control value 671" = alloca i32, align 4
  %"control value 672" = alloca i32, align 4
  %"control value 673" = alloca i32, align 4
  %"control value 674" = alloca i32, align 4
  %"control value 675" = alloca i32, align 4
  %"control value 676" = alloca i8, align 1
  %"control value 677" = alloca i8, align 1
  %"control value 678" = alloca i32, align 4
  %"control value 679" = alloca i32, align 4
  %"control value 680" = alloca ptr, align 4
  %"control value 681" = alloca ptr, align 4
  %"control value 682" = alloca ptr, align 4
  %"control value 683" = alloca i8, align 1
  %"control value 684" = alloca ptr, align 4
  %"control value 685" = alloca i32, align 4
  %"control value 686" = alloca i32, align 4
  %"control value 687" = alloca ptr, align 4
  store ptr %0, ptr %heap, align 1
  store i32 %1, ptr %count, align 1
  store i32 %2, ptr %size, align 1
  %3 = load ptr, ptr %heap, align 1
  store ptr %3, ptr %"control value 626", align 1
  %4 = load i32, ptr %count, align 1
  store i32 %4, ptr %"control value 627", align 1
  %5 = load i32, ptr %size, align 1
  store i32 %5, ptr %"control value 628", align 1
  %6 = load ptr, ptr %"control value 626", align 1
  %7 = load i32, ptr %"control value 627", align 1
  %8 = load i32, ptr %"control value 628", align 1
  %9 = call ptr @guest_heap_allocate(ptr %6, i32 %7, i32 %8) #12
  store ptr %9, ptr %"control value 629", align 1
  %10 = load ptr, ptr %"control value 629", align 1
  store ptr %10, ptr %result, align 1
  %11 = load ptr, ptr %result, align 1
  store ptr %11, ptr %"control value 630", align 1
  %12 = load ptr, ptr %"control value 630", align 1
  %13 = icmp ne ptr %12, null
  %14 = zext i1 %13 to i8
  store i8 %14, ptr %"control value 631", align 1
  %15 = load i8, ptr %"control value 631", align 1
  store i8 %15, ptr %allocated, align 1
  %16 = load i8, ptr %allocated, align 1
  store i8 %16, ptr %"control value 632", align 1
  %17 = load i8, ptr %"control value 632", align 1
  %18 = icmp ne i8 %17, 0
  br i1 %18, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  %19 = load ptr, ptr %result, align 1
  store ptr %19, ptr %"control value 633", align 1
  %20 = load ptr, ptr %"control value 633", align 1
  ret ptr %20

if.else:                                          ; preds = %entry
  br label %if.end

if.end:                                           ; preds = %if.else
  %21 = load i32, ptr %count, align 1
  store i32 %21, ptr %"control value 634", align 1
  %22 = load i32, ptr %size, align 1
  store i32 %22, ptr %"control value 635", align 1
  %23 = load i32, ptr %"control value 634", align 1
  %24 = load i32, ptr %"control value 635", align 1
  %25 = call i32 @tower.fn.guest_heap_request_size(i32 %23, i32 %24)
  store i32 %25, ptr %"control value 636", align 1
  %26 = load i32, ptr %"control value 636", align 1
  store i32 %26, ptr %bytes, align 1
  %27 = load i32, ptr %bytes, align 1
  store i32 %27, ptr %"control value 637", align 1
  %28 = load i32, ptr %"control value 637", align 1
  %29 = icmp eq i32 %28, 0
  %30 = zext i1 %29 to i8
  store i8 %30, ptr %"control value 638", align 1
  %31 = load i8, ptr %"control value 638", align 1
  store i8 %31, ptr %overflow, align 1
  %32 = load i8, ptr %overflow, align 1
  store i8 %32, ptr %"control value 639", align 1
  %33 = load i8, ptr %"control value 639", align 1
  %34 = icmp ne i8 %33, 0
  br i1 %34, label %if.body1, label %if.else2

if.body1:                                         ; preds = %if.end
  ret ptr null

if.else2:                                         ; preds = %if.end
  br label %if.end3

if.end3:                                          ; preds = %if.else2
  %35 = load ptr, ptr %heap, align 1
  store ptr %35, ptr %"control value 640", align 1
  %36 = load ptr, ptr %"control value 640", align 1
  %37 = getelementptr i8, ptr %36, i32 4
  %38 = load i32, ptr %37, align 1
  store i32 %38, ptr %"control value 641", align 1
  %39 = load i32, ptr %"control value 641", align 1
  %40 = zext i32 %39 to i64
  %41 = icmp ule i64 %40, -1
  %42 = and i1 true, %41
  br i1 %42, label %valid, label %error

valid:                                            ; preds = %if.end3
  %43 = zext i32 %39 to i64
  store i64 %43, ptr %"control value 642", align 1
  store i32 16, ptr %"control value 643", align 1
  %44 = load i32, ptr %"control value 643", align 1
  %45 = zext i32 %44 to i64
  %46 = icmp ule i64 %45, -1
  %47 = and i1 true, %46
  br i1 %47, label %valid4, label %error5

error:                                            ; preds = %if.end3
  call void @tower_trap(ptr @8, i32 22672)
  unreachable

valid4:                                           ; preds = %valid
  %48 = zext i32 %44 to i64
  store i64 %48, ptr %"control value 644", align 1
  %49 = load i64, ptr %"control value 642", align 1
  %50 = load i64, ptr %"control value 644", align 1
  %51 = add i64 %49, %50
  store i64 %51, ptr %"control value 645", align 1
  %52 = load i64, ptr %"control value 645", align 1
  store i64 %52, ptr %end, align 1
  store ptr %end, ptr %"control value 646", align 1
  %53 = load i64, ptr %end, align 1
  store i64 %53, ptr %"control value 647", align 1
  %54 = load i32, ptr %bytes, align 1
  store i32 %54, ptr %"control value 648", align 1
  %55 = load i32, ptr %"control value 648", align 1
  %56 = zext i32 %55 to i64
  %57 = icmp ule i64 %56, -1
  %58 = and i1 true, %57
  br i1 %58, label %valid6, label %error7

error5:                                           ; preds = %valid
  call void @tower_trap(ptr @9, i32 22672)
  unreachable

valid6:                                           ; preds = %valid4
  %59 = zext i32 %55 to i64
  store i64 %59, ptr %"control value 649", align 1
  %60 = load i64, ptr %"control value 647", align 1
  %61 = load i64, ptr %"control value 649", align 1
  %62 = add i64 %60, %61
  store i64 %62, ptr %"control value 650", align 1
  %63 = load ptr, ptr %"control value 646", align 1
  %64 = load i64, ptr %"control value 650", align 1
  store i64 %64, ptr %63, align 1
  store ptr %overflow, ptr %"control value 651", align 1
  %65 = load i64, ptr %end, align 1
  store i64 %65, ptr %"control value 652", align 1
  %66 = load i64, ptr %"control value 652", align 1
  %67 = icmp ugt i64 %66, 4294967295
  %68 = zext i1 %67 to i8
  store i8 %68, ptr %"control value 653", align 1
  %69 = load ptr, ptr %"control value 651", align 1
  %70 = load i8, ptr %"control value 653", align 1
  store i8 %70, ptr %69, align 1
  %71 = load i8, ptr %overflow, align 1
  store i8 %71, ptr %"control value 654", align 1
  %72 = load i8, ptr %"control value 654", align 1
  %73 = icmp ne i8 %72, 0
  br i1 %73, label %if.body8, label %if.else9

error7:                                           ; preds = %valid4
  call void @tower_trap(ptr @10, i32 22672)
  unreachable

if.body8:                                         ; preds = %valid6
  ret ptr null

if.else9:                                         ; preds = %valid6
  br label %if.end10

if.end10:                                         ; preds = %if.else9
  %74 = call i32 @tower.fn.guest_wasm_pages()
  store i32 %74, ptr %"control value 655", align 1
  %75 = load i32, ptr %"control value 655", align 1
  store i32 %75, ptr %pages, align 1
  %76 = load ptr, ptr %heap, align 1
  store ptr %76, ptr %"control value 656", align 1
  %77 = load ptr, ptr %"control value 656", align 1
  %78 = getelementptr i8, ptr %77, i32 8
  %79 = load i32, ptr %78, align 1
  store i32 %79, ptr %"control value 657", align 1
  %80 = load i32, ptr %pages, align 1
  store i32 %80, ptr %"control value 658", align 1
  %81 = load i32, ptr %"control value 658", align 1
  %82 = call i32 @tower.fn.guest_wasm_limit(i32 %81)
  store i32 %82, ptr %"control value 659", align 1
  %83 = load i32, ptr %"control value 657", align 1
  %84 = load i32, ptr %"control value 659", align 1
  %85 = icmp ne i32 %83, %84
  %86 = zext i1 %85 to i8
  store i8 %86, ptr %"control value 660", align 1
  %87 = load i8, ptr %"control value 660", align 1
  store i8 %87, ptr %detached, align 1
  %88 = load i8, ptr %detached, align 1
  store i8 %88, ptr %"control value 661", align 1
  %89 = load i8, ptr %"control value 661", align 1
  %90 = icmp ne i8 %89, 0
  br i1 %90, label %if.body11, label %if.else12

if.body11:                                        ; preds = %if.end10
  ret ptr null

if.else12:                                        ; preds = %if.end10
  br label %if.end13

if.end13:                                         ; preds = %if.else12
  %91 = load i64, ptr %end, align 1
  store i64 %91, ptr %"control value 662", align 1
  %92 = load i64, ptr %"control value 662", align 1
  %93 = add i64 %92, 65535
  store i64 %93, ptr %"control value 663", align 1
  %94 = load i64, ptr %"control value 663", align 1
  store i64 %94, ptr %needed, align 1
  store ptr %needed, ptr %"control value 664", align 1
  %95 = load i64, ptr %needed, align 1
  store i64 %95, ptr %"control value 665", align 1
  %96 = load i64, ptr %"control value 665", align 1
  br i1 true, label %valid14, label %error15

valid14:                                          ; preds = %if.end13
  %97 = udiv i64 %96, 65536
  store i64 %97, ptr %"control value 666", align 1
  %98 = load ptr, ptr %"control value 664", align 1
  %99 = load i64, ptr %"control value 666", align 1
  store i64 %99, ptr %98, align 1
  %100 = load i64, ptr %needed, align 1
  store i64 %100, ptr %"control value 667", align 1
  %101 = load i64, ptr %"control value 667", align 1
  %102 = icmp ule i64 %101, 4294967295
  %103 = and i1 true, %102
  br i1 %103, label %valid16, label %error17

error15:                                          ; preds = %if.end13
  call void @tower_trap(ptr @11, i32 22672)
  unreachable

valid16:                                          ; preds = %valid14
  %104 = trunc i64 %101 to i32
  store i32 %104, ptr %"control value 668", align 1
  %105 = load i32, ptr %"control value 668", align 1
  store i32 %105, ptr %committed, align 1
  %106 = load i32, ptr %committed, align 1
  store i32 %106, ptr %"control value 669", align 1
  %107 = load i32, ptr %pages, align 1
  store i32 %107, ptr %"control value 670", align 1
  %108 = load i32, ptr %"control value 669", align 1
  %109 = load i32, ptr %"control value 670", align 1
  %110 = sub i32 %108, %109
  store i32 %110, ptr %"control value 671", align 1
  %111 = load i32, ptr %"control value 671", align 1
  store i32 %111, ptr %delta, align 1
  %112 = load i32, ptr %delta, align 1
  store i32 %112, ptr %"control value 672", align 1
  %113 = load i32, ptr %"control value 672", align 1
  %114 = call i32 @llvm.wasm.memory.grow.i32(i32 0, i32 %113) #16
  store i32 %114, ptr %"control value 673", align 1
  %115 = load i32, ptr %"control value 673", align 1
  store i32 %115, ptr %previous, align 1
  %116 = load i32, ptr %previous, align 1
  store i32 %116, ptr %"control value 674", align 1
  %117 = load i32, ptr %pages, align 1
  store i32 %117, ptr %"control value 675", align 1
  %118 = load i32, ptr %"control value 674", align 1
  %119 = load i32, ptr %"control value 675", align 1
  %120 = icmp ne i32 %118, %119
  %121 = zext i1 %120 to i8
  store i8 %121, ptr %"control value 676", align 1
  %122 = load i8, ptr %"control value 676", align 1
  store i8 %122, ptr %failed, align 1
  %123 = load i8, ptr %failed, align 1
  store i8 %123, ptr %"control value 677", align 1
  %124 = load i8, ptr %"control value 677", align 1
  %125 = icmp ne i8 %124, 0
  br i1 %125, label %if.body18, label %if.else19

error17:                                          ; preds = %valid14
  call void @tower_trap(ptr @12, i32 22672)
  unreachable

if.body18:                                        ; preds = %valid16
  ret ptr null

if.else19:                                        ; preds = %valid16
  br label %if.end20

if.end20:                                         ; preds = %if.else19
  %126 = load i32, ptr %committed, align 1
  store i32 %126, ptr %"control value 678", align 1
  %127 = load i32, ptr %"control value 678", align 1
  %128 = call i32 @tower.fn.guest_wasm_limit(i32 %127)
  store i32 %128, ptr %"control value 679", align 1
  %129 = load i32, ptr %"control value 679", align 1
  %130 = inttoptr i32 %129 to ptr
  store ptr %130, ptr %"control value 680", align 1
  %131 = load ptr, ptr %"control value 680", align 1
  store ptr %131, ptr %limit, align 1
  %132 = load ptr, ptr %heap, align 1
  store ptr %132, ptr %"control value 681", align 1
  %133 = load ptr, ptr %limit, align 1
  store ptr %133, ptr %"control value 682", align 1
  %134 = load ptr, ptr %"control value 681", align 1
  %135 = load ptr, ptr %"control value 682", align 1
  %136 = call zeroext i8 @guest_heap_extend(ptr %134, ptr %135) #17
  store i8 %136, ptr %"control value 683", align 1
  %137 = load ptr, ptr %heap, align 1
  store ptr %137, ptr %"control value 684", align 1
  %138 = load i32, ptr %count, align 1
  store i32 %138, ptr %"control value 685", align 1
  %139 = load i32, ptr %size, align 1
  store i32 %139, ptr %"control value 686", align 1
  %140 = load ptr, ptr %"control value 684", align 1
  %141 = load i32, ptr %"control value 685", align 1
  %142 = load i32, ptr %"control value 686", align 1
  %143 = call ptr @guest_heap_allocate(ptr %140, i32 %141, i32 %142) #12
  store ptr %143, ptr %"control value 687", align 1
  %144 = load ptr, ptr %"control value 687", align 1
  ret ptr %144
}

define ptr @guest_wasm_reallocate(ptr %0, ptr %1, i32 %2, i32 %3) {
entry:
  %heap = alloca ptr, align 4
  %pointer = alloca ptr, align 4
  %count = alloca i32, align 4
  %size = alloca i32, align 4
  %requested = alloca i32, align 4
  %overflow = alloca i8, align 1
  %absent = alloca i8, align 1
  %bytes = alloca i32, align 4
  %empty = alloca i8, align 1
  %block = alloca ptr, align 4
  %enough = alloca i8, align 1
  %result = alloca ptr, align 4
  %allocated = alloca i8, align 1
  %"control value 688" = alloca i32, align 4
  %"control value 689" = alloca i32, align 4
  %"control value 690" = alloca i32, align 4
  %"control value 691" = alloca i32, align 4
  %"control value 692" = alloca i8, align 1
  %"control value 693" = alloca i8, align 1
  %"control value 694" = alloca ptr, align 4
  %"control value 695" = alloca i8, align 1
  %"control value 696" = alloca i8, align 1
  %"control value 697" = alloca ptr, align 4
  %"control value 698" = alloca i32, align 4
  %"control value 699" = alloca i32, align 4
  %"control value 700" = alloca ptr, align 4
  %"control value 701" = alloca i32, align 4
  %"control value 702" = alloca i32, align 4
  %"control value 703" = alloca i32, align 4
  %"control value 704" = alloca i32, align 4
  %"control value 705" = alloca i8, align 1
  %"control value 706" = alloca i8, align 1
  %"control value 707" = alloca ptr, align 4
  %"control value 708" = alloca ptr, align 4
  %"control value 709" = alloca ptr, align 4
  %"control value 710" = alloca ptr, align 4
  %"control value 711" = alloca ptr, align 4
  %"control value 712" = alloca ptr, align 4
  %"control value 713" = alloca ptr, align 4
  %"control value 714" = alloca ptr, align 4
  %"control value 715" = alloca i32, align 4
  %"control value 716" = alloca i32, align 4
  %"control value 717" = alloca i8, align 1
  %"control value 718" = alloca i8, align 1
  %"control value 719" = alloca ptr, align 4
  %"control value 720" = alloca ptr, align 4
  %"control value 721" = alloca i32, align 4
  %"control value 722" = alloca i32, align 4
  %"control value 723" = alloca ptr, align 4
  %"control value 724" = alloca ptr, align 4
  %"control value 725" = alloca i8, align 1
  %"control value 726" = alloca i8, align 1
  %"control value 727" = alloca ptr, align 4
  %"control value 728" = alloca ptr, align 4
  %"control value 729" = alloca ptr, align 4
  %"control value 730" = alloca i32, align 4
  %"control value 731" = alloca ptr, align 4
  %"control value 732" = alloca ptr, align 4
  %"control value 733" = alloca ptr, align 4
  store ptr %0, ptr %heap, align 1
  store ptr %1, ptr %pointer, align 1
  store i32 %2, ptr %count, align 1
  store i32 %3, ptr %size, align 1
  %4 = load i32, ptr %count, align 1
  store i32 %4, ptr %"control value 688", align 1
  %5 = load i32, ptr %size, align 1
  store i32 %5, ptr %"control value 689", align 1
  %6 = load i32, ptr %"control value 688", align 1
  %7 = load i32, ptr %"control value 689", align 1
  %8 = call i32 @tower.fn.guest_heap_request_size(i32 %6, i32 %7)
  store i32 %8, ptr %"control value 690", align 1
  %9 = load i32, ptr %"control value 690", align 1
  store i32 %9, ptr %requested, align 1
  %10 = load i32, ptr %requested, align 1
  store i32 %10, ptr %"control value 691", align 1
  %11 = load i32, ptr %"control value 691", align 1
  %12 = icmp eq i32 %11, 0
  %13 = zext i1 %12 to i8
  store i8 %13, ptr %"control value 692", align 1
  %14 = load i8, ptr %"control value 692", align 1
  store i8 %14, ptr %overflow, align 1
  %15 = load i8, ptr %overflow, align 1
  store i8 %15, ptr %"control value 693", align 1
  %16 = load i8, ptr %"control value 693", align 1
  %17 = icmp ne i8 %16, 0
  br i1 %17, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  ret ptr null

if.else:                                          ; preds = %entry
  br label %if.end

if.end:                                           ; preds = %if.else
  %18 = load ptr, ptr %pointer, align 1
  store ptr %18, ptr %"control value 694", align 1
  %19 = load ptr, ptr %"control value 694", align 1
  %20 = icmp eq ptr %19, null
  %21 = zext i1 %20 to i8
  store i8 %21, ptr %"control value 695", align 1
  %22 = load i8, ptr %"control value 695", align 1
  store i8 %22, ptr %absent, align 1
  %23 = load i8, ptr %absent, align 1
  store i8 %23, ptr %"control value 696", align 1
  %24 = load i8, ptr %"control value 696", align 1
  %25 = icmp ne i8 %24, 0
  br i1 %25, label %if.body1, label %if.else2

if.body1:                                         ; preds = %if.end
  %26 = load ptr, ptr %heap, align 1
  store ptr %26, ptr %"control value 697", align 1
  %27 = load i32, ptr %count, align 1
  store i32 %27, ptr %"control value 698", align 1
  %28 = load i32, ptr %size, align 1
  store i32 %28, ptr %"control value 699", align 1
  %29 = load ptr, ptr %"control value 697", align 1
  %30 = load i32, ptr %"control value 698", align 1
  %31 = load i32, ptr %"control value 699", align 1
  %32 = call ptr @guest_wasm_allocate(ptr %29, i32 %30, i32 %31) #18
  store ptr %32, ptr %"control value 700", align 1
  %33 = load ptr, ptr %"control value 700", align 1
  ret ptr %33

if.else2:                                         ; preds = %if.end
  br label %if.end3

if.end3:                                          ; preds = %if.else2
  %34 = load i32, ptr %count, align 1
  store i32 %34, ptr %"control value 701", align 1
  %35 = load i32, ptr %size, align 1
  store i32 %35, ptr %"control value 702", align 1
  %36 = load i32, ptr %"control value 701", align 1
  %37 = load i32, ptr %"control value 702", align 1
  %38 = mul i32 %36, %37
  store i32 %38, ptr %"control value 703", align 1
  %39 = load i32, ptr %"control value 703", align 1
  store i32 %39, ptr %bytes, align 1
  %40 = load i32, ptr %bytes, align 1
  store i32 %40, ptr %"control value 704", align 1
  %41 = load i32, ptr %"control value 704", align 1
  %42 = icmp eq i32 %41, 0
  %43 = zext i1 %42 to i8
  store i8 %43, ptr %"control value 705", align 1
  %44 = load i8, ptr %"control value 705", align 1
  store i8 %44, ptr %empty, align 1
  %45 = load i8, ptr %empty, align 1
  store i8 %45, ptr %"control value 706", align 1
  %46 = load i8, ptr %"control value 706", align 1
  %47 = icmp ne i8 %46, 0
  br i1 %47, label %if.body4, label %if.else5

if.body4:                                         ; preds = %if.end3
  %48 = load ptr, ptr %heap, align 1
  store ptr %48, ptr %"control value 707", align 1
  %49 = load ptr, ptr %pointer, align 1
  store ptr %49, ptr %"control value 708", align 1
  %50 = load ptr, ptr %"control value 707", align 1
  %51 = load ptr, ptr %"control value 708", align 1
  call void @guest_heap_free(ptr %50, ptr %51) #13
  ret ptr null

if.else5:                                         ; preds = %if.end3
  br label %if.end6

if.end6:                                          ; preds = %if.else5
  %52 = load ptr, ptr %pointer, align 1
  store ptr %52, ptr %"control value 709", align 1
  %53 = load ptr, ptr %"control value 709", align 1
  store ptr %53, ptr %"control value 710", align 1
  %54 = load ptr, ptr %"control value 710", align 1
  store ptr %54, ptr %block, align 1
  store ptr %block, ptr %"control value 711", align 1
  %55 = load ptr, ptr %"control value 711", align 1
  %56 = load ptr, ptr %55, align 1
  store ptr %56, ptr %"control value 712", align 1
  %57 = load ptr, ptr %"control value 712", align 1
  %58 = getelementptr i8, ptr %57, i32 -16
  store ptr %58, ptr %"control value 713", align 1
  %59 = load ptr, ptr %"control value 711", align 1
  %60 = load ptr, ptr %"control value 713", align 1
  store ptr %60, ptr %59, align 1
  %61 = load ptr, ptr %block, align 1
  store ptr %61, ptr %"control value 714", align 1
  %62 = load ptr, ptr %"control value 714", align 1
  %63 = getelementptr i8, ptr %62, i32 0
  %64 = load i32, ptr %63, align 1
  store i32 %64, ptr %"control value 715", align 1
  %65 = load i32, ptr %bytes, align 1
  store i32 %65, ptr %"control value 716", align 1
  %66 = load i32, ptr %"control value 715", align 1
  %67 = load i32, ptr %"control value 716", align 1
  %68 = icmp uge i32 %66, %67
  %69 = zext i1 %68 to i8
  store i8 %69, ptr %"control value 717", align 1
  %70 = load i8, ptr %"control value 717", align 1
  store i8 %70, ptr %enough, align 1
  %71 = load i8, ptr %enough, align 1
  store i8 %71, ptr %"control value 718", align 1
  %72 = load i8, ptr %"control value 718", align 1
  %73 = icmp ne i8 %72, 0
  br i1 %73, label %if.body7, label %if.else8

if.body7:                                         ; preds = %if.end6
  %74 = load ptr, ptr %pointer, align 1
  store ptr %74, ptr %"control value 719", align 1
  %75 = load ptr, ptr %"control value 719", align 1
  ret ptr %75

if.else8:                                         ; preds = %if.end6
  br label %if.end9

if.end9:                                          ; preds = %if.else8
  %76 = load ptr, ptr %heap, align 1
  store ptr %76, ptr %"control value 720", align 1
  %77 = load i32, ptr %count, align 1
  store i32 %77, ptr %"control value 721", align 1
  %78 = load i32, ptr %size, align 1
  store i32 %78, ptr %"control value 722", align 1
  %79 = load ptr, ptr %"control value 720", align 1
  %80 = load i32, ptr %"control value 721", align 1
  %81 = load i32, ptr %"control value 722", align 1
  %82 = call ptr @guest_wasm_allocate(ptr %79, i32 %80, i32 %81) #18
  store ptr %82, ptr %"control value 723", align 1
  %83 = load ptr, ptr %"control value 723", align 1
  store ptr %83, ptr %result, align 1
  %84 = load ptr, ptr %result, align 1
  store ptr %84, ptr %"control value 724", align 1
  %85 = load ptr, ptr %"control value 724", align 1
  %86 = icmp ne ptr %85, null
  %87 = zext i1 %86 to i8
  store i8 %87, ptr %"control value 725", align 1
  %88 = load i8, ptr %"control value 725", align 1
  store i8 %88, ptr %allocated, align 1
  %89 = load i8, ptr %allocated, align 1
  store i8 %89, ptr %"control value 726", align 1
  %90 = load i8, ptr %"control value 726", align 1
  %91 = icmp ne i8 %90, 0
  br i1 %91, label %if.body10, label %if.else11

if.body10:                                        ; preds = %if.end9
  %92 = load ptr, ptr %result, align 1
  store ptr %92, ptr %"control value 727", align 1
  %93 = load ptr, ptr %pointer, align 1
  store ptr %93, ptr %"control value 728", align 1
  %94 = load ptr, ptr %block, align 1
  store ptr %94, ptr %"control value 729", align 1
  %95 = load ptr, ptr %"control value 729", align 1
  %96 = getelementptr i8, ptr %95, i32 0
  %97 = load i32, ptr %96, align 1
  store i32 %97, ptr %"control value 730", align 1
  %98 = load ptr, ptr %"control value 727", align 1
  %99 = load ptr, ptr %"control value 728", align 1
  %100 = load i32, ptr %"control value 730", align 1
  call void @llvm.memmove.p0.p0.i32(ptr align 1 %98, ptr align 1 %99, i32 %100, i1 false)
  %101 = load ptr, ptr %heap, align 1
  store ptr %101, ptr %"control value 731", align 1
  %102 = load ptr, ptr %pointer, align 1
  store ptr %102, ptr %"control value 732", align 1
  %103 = load ptr, ptr %"control value 731", align 1
  %104 = load ptr, ptr %"control value 732", align 1
  call void @guest_heap_free(ptr %103, ptr %104) #13
  br label %if.end12

if.else11:                                        ; preds = %if.end9
  br label %if.end12

if.end12:                                         ; preds = %if.else11, %if.body10
  %105 = load ptr, ptr %result, align 1
  store ptr %105, ptr %"control value 733", align 1
  %106 = load ptr, ptr %"control value 733", align 1
  ret ptr %106
}

define ptr @guest_wasm_context() #4 {
entry:
  ret ptr @tower.runtime.wasm.heap
}

define ptr @guest_wasm_heap_base() #5 {
entry:
  ret ptr @__heap_base
}

define internal ptr @tower.fn.guest_wasm_runtime_heap() {
entry:
  %heap = alloca ptr, align 4
  %fresh = alloca i8, align 1
  %layout = alloca i8, align 1
  %limit = alloca ptr, align 4
  %"control value 734" = alloca ptr, align 4
  %"control value 735" = alloca ptr, align 4
  %"control value 736" = alloca i32, align 4
  %"control value 737" = alloca i8, align 1
  %"control value 738" = alloca i8, align 1
  %"control value 739" = alloca i32, align 4
  %"control value 740" = alloca i8, align 1
  %"control value 741" = alloca i8, align 1
  %"control value 742" = alloca i8, align 1
  %"control value 743" = alloca i32, align 4
  %"control value 744" = alloca i32, align 4
  %"control value 745" = alloca ptr, align 4
  %"control value 746" = alloca ptr, align 4
  %"control value 747" = alloca ptr, align 4
  %"control value 748" = alloca ptr, align 4
  %"control value 749" = alloca i8, align 1
  %"control value 750" = alloca i8, align 1
  %"control value 751" = alloca ptr, align 4
  %0 = call ptr @guest_wasm_context() #4
  store ptr %0, ptr %"control value 734", align 1
  %1 = load ptr, ptr %"control value 734", align 1
  store ptr %1, ptr %heap, align 1
  %2 = load ptr, ptr %heap, align 1
  store ptr %2, ptr %"control value 735", align 1
  %3 = load ptr, ptr %"control value 735", align 1
  %4 = getelementptr i8, ptr %3, i32 4
  %5 = load i32, ptr %4, align 1
  store i32 %5, ptr %"control value 736", align 1
  %6 = load i32, ptr %"control value 736", align 1
  %7 = icmp eq i32 %6, 0
  %8 = zext i1 %7 to i8
  store i8 %8, ptr %"control value 737", align 1
  %9 = load i8, ptr %"control value 737", align 1
  store i8 %9, ptr %fresh, align 1
  %10 = load i8, ptr %fresh, align 1
  store i8 %10, ptr %"control value 738", align 1
  %11 = load i8, ptr %"control value 738", align 1
  %12 = icmp ne i8 %11, 0
  br i1 %12, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  store i32 12, ptr %"control value 739", align 1
  %13 = load i32, ptr %"control value 739", align 1
  %14 = icmp eq i32 %13, 12
  %15 = zext i1 %14 to i8
  store i8 %15, ptr %"control value 740", align 1
  %16 = load i8, ptr %"control value 740", align 1
  store i8 %16, ptr %layout, align 1
  %17 = load i8, ptr %layout, align 1
  store i8 %17, ptr %"control value 741", align 1
  %18 = load i8, ptr %"control value 741", align 1
  %19 = icmp eq i8 0, %18
  %20 = zext i1 %19 to i8
  store i8 %20, ptr %"control value 742", align 1
  %21 = load i8, ptr %"control value 742", align 1
  %22 = icmp ne i8 %21, 0
  br i1 %22, label %if.body1, label %if.else2

if.else:                                          ; preds = %entry
  br label %if.end

if.end:                                           ; preds = %if.end6, %if.else
  %23 = load ptr, ptr %heap, align 1
  store ptr %23, ptr %"control value 751", align 1
  %24 = load ptr, ptr %"control value 751", align 1
  ret ptr %24

if.body1:                                         ; preds = %if.body
  ret ptr null

if.else2:                                         ; preds = %if.body
  br label %if.end3

if.end3:                                          ; preds = %if.else2
  %25 = call i32 @tower.fn.guest_wasm_pages()
  store i32 %25, ptr %"control value 743", align 1
  %26 = load i32, ptr %"control value 743", align 1
  %27 = call i32 @tower.fn.guest_wasm_limit(i32 %26)
  store i32 %27, ptr %"control value 744", align 1
  %28 = load i32, ptr %"control value 744", align 1
  %29 = inttoptr i32 %28 to ptr
  store ptr %29, ptr %"control value 745", align 1
  %30 = load ptr, ptr %"control value 745", align 1
  store ptr %30, ptr %limit, align 1
  %31 = load ptr, ptr %heap, align 1
  store ptr %31, ptr %"control value 746", align 1
  %32 = call ptr @guest_wasm_heap_base() #5
  store ptr %32, ptr %"control value 747", align 1
  %33 = load ptr, ptr %limit, align 1
  store ptr %33, ptr %"control value 748", align 1
  %34 = load ptr, ptr %"control value 746", align 1
  %35 = load ptr, ptr %"control value 747", align 1
  %36 = load ptr, ptr %"control value 748", align 1
  %37 = call zeroext i8 @guest_heap_init(ptr %34, ptr %35, ptr %36) #15
  store i8 %37, ptr %"control value 749", align 1
  %38 = load i8, ptr %"control value 749", align 1
  %39 = icmp eq i8 0, %38
  %40 = zext i1 %39 to i8
  store i8 %40, ptr %"control value 750", align 1
  %41 = load i8, ptr %"control value 750", align 1
  %42 = icmp ne i8 %41, 0
  br i1 %42, label %if.body4, label %if.else5

if.body4:                                         ; preds = %if.end3
  ret ptr null

if.else5:                                         ; preds = %if.end3
  br label %if.end6

if.end6:                                          ; preds = %if.else5
  br label %if.end
}

define ptr @malloc(i32 %0) {
entry:
  %bytes = alloca i32, align 4
  %heap = alloca ptr, align 4
  %missing = alloca i8, align 1
  %"control value 752" = alloca ptr, align 4
  %"control value 753" = alloca ptr, align 4
  %"control value 754" = alloca i8, align 1
  %"control value 755" = alloca i8, align 1
  %"control value 756" = alloca ptr, align 4
  %"control value 757" = alloca i32, align 4
  %"control value 758" = alloca ptr, align 4
  store i32 %0, ptr %bytes, align 1
  %1 = call ptr @tower.fn.guest_wasm_runtime_heap()
  store ptr %1, ptr %"control value 752", align 1
  %2 = load ptr, ptr %"control value 752", align 1
  store ptr %2, ptr %heap, align 1
  %3 = load ptr, ptr %heap, align 1
  store ptr %3, ptr %"control value 753", align 1
  %4 = load ptr, ptr %"control value 753", align 1
  %5 = icmp eq ptr %4, null
  %6 = zext i1 %5 to i8
  store i8 %6, ptr %"control value 754", align 1
  %7 = load i8, ptr %"control value 754", align 1
  store i8 %7, ptr %missing, align 1
  %8 = load i8, ptr %missing, align 1
  store i8 %8, ptr %"control value 755", align 1
  %9 = load i8, ptr %"control value 755", align 1
  %10 = icmp ne i8 %9, 0
  br i1 %10, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  ret ptr null

if.else:                                          ; preds = %entry
  br label %if.end

if.end:                                           ; preds = %if.else
  %11 = load ptr, ptr %heap, align 1
  store ptr %11, ptr %"control value 756", align 1
  %12 = load i32, ptr %bytes, align 1
  store i32 %12, ptr %"control value 757", align 1
  %13 = load ptr, ptr %"control value 756", align 1
  %14 = load i32, ptr %"control value 757", align 1
  %15 = call ptr @guest_wasm_allocate(ptr %13, i32 %14, i32 1) #18
  store ptr %15, ptr %"control value 758", align 1
  %16 = load ptr, ptr %"control value 758", align 1
  ret ptr %16
}

define ptr @realloc(ptr %0, i32 %1) {
entry:
  %pointer = alloca ptr, align 4
  %bytes = alloca i32, align 4
  %heap = alloca ptr, align 4
  %missing = alloca i8, align 1
  %"control value 759" = alloca ptr, align 4
  %"control value 760" = alloca ptr, align 4
  %"control value 761" = alloca i8, align 1
  %"control value 762" = alloca i8, align 1
  %"control value 763" = alloca ptr, align 4
  %"control value 764" = alloca ptr, align 4
  %"control value 765" = alloca i32, align 4
  %"control value 766" = alloca ptr, align 4
  store ptr %0, ptr %pointer, align 1
  store i32 %1, ptr %bytes, align 1
  %2 = call ptr @tower.fn.guest_wasm_runtime_heap()
  store ptr %2, ptr %"control value 759", align 1
  %3 = load ptr, ptr %"control value 759", align 1
  store ptr %3, ptr %heap, align 1
  %4 = load ptr, ptr %heap, align 1
  store ptr %4, ptr %"control value 760", align 1
  %5 = load ptr, ptr %"control value 760", align 1
  %6 = icmp eq ptr %5, null
  %7 = zext i1 %6 to i8
  store i8 %7, ptr %"control value 761", align 1
  %8 = load i8, ptr %"control value 761", align 1
  store i8 %8, ptr %missing, align 1
  %9 = load i8, ptr %missing, align 1
  store i8 %9, ptr %"control value 762", align 1
  %10 = load i8, ptr %"control value 762", align 1
  %11 = icmp ne i8 %10, 0
  br i1 %11, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  ret ptr null

if.else:                                          ; preds = %entry
  br label %if.end

if.end:                                           ; preds = %if.else
  %12 = load ptr, ptr %heap, align 1
  store ptr %12, ptr %"control value 763", align 1
  %13 = load ptr, ptr %pointer, align 1
  store ptr %13, ptr %"control value 764", align 1
  %14 = load i32, ptr %bytes, align 1
  store i32 %14, ptr %"control value 765", align 1
  %15 = load ptr, ptr %"control value 763", align 1
  %16 = load ptr, ptr %"control value 764", align 1
  %17 = load i32, ptr %"control value 765", align 1
  %18 = call ptr @guest_wasm_reallocate(ptr %15, ptr %16, i32 %17, i32 1) #19
  store ptr %18, ptr %"control value 766", align 1
  %19 = load ptr, ptr %"control value 766", align 1
  ret ptr %19
}

define void @free(ptr %0) {
entry:
  %pointer = alloca ptr, align 4
  %absent = alloca i8, align 1
  %"control value 767" = alloca ptr, align 4
  %"control value 768" = alloca i8, align 1
  %"control value 769" = alloca i8, align 1
  %"control value 770" = alloca ptr, align 4
  %"control value 771" = alloca ptr, align 4
  store ptr %0, ptr %pointer, align 1
  %1 = load ptr, ptr %pointer, align 1
  store ptr %1, ptr %"control value 767", align 1
  %2 = load ptr, ptr %"control value 767", align 1
  %3 = icmp eq ptr %2, null
  %4 = zext i1 %3 to i8
  store i8 %4, ptr %"control value 768", align 1
  %5 = load i8, ptr %"control value 768", align 1
  store i8 %5, ptr %absent, align 1
  %6 = load i8, ptr %absent, align 1
  store i8 %6, ptr %"control value 769", align 1
  %7 = load i8, ptr %"control value 769", align 1
  %8 = icmp ne i8 %7, 0
  br i1 %8, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  ret void

if.else:                                          ; preds = %entry
  br label %if.end

if.end:                                           ; preds = %if.else
  %9 = call ptr @guest_wasm_context() #4
  store ptr %9, ptr %"control value 770", align 1
  %10 = load ptr, ptr %pointer, align 1
  store ptr %10, ptr %"control value 771", align 1
  %11 = load ptr, ptr %"control value 770", align 1
  %12 = load ptr, ptr %"control value 771", align 1
  call void @guest_heap_free(ptr %11, ptr %12) #13
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i32(ptr nocapture writeonly, i8, i32, i1 immarg) #6

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memmove.p0.p0.i32(ptr nocapture writeonly, ptr nocapture readonly, i32, i1 immarg) #7

attributes #0 = { "wasm-import-module"="tower" "wasm-import-name"="print" }
attributes #1 = { "wasm-import-module"="tower" "wasm-import-name"="trap" }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #3 = { nocallback nofree nosync nounwind willreturn }
attributes #4 = { "wasm-import-module"="env" "wasm-import-name"="guest_wasm_context" }
attributes #5 = { "wasm-import-module"="env" "wasm-import-name"="guest_wasm_heap_base" }
attributes #6 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #7 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #8 = { "wasm-export-name"="guest_host_allocate" }
attributes #9 = { "wasm-export-name"="guest_host_reallocate" }
attributes #10 = { "wasm-export-name"="guest_host_free" }
attributes #11 = { "wasm-export-name"="guest_runtime_copy" }
attributes #12 = { "wasm-export-name"="guest_heap_allocate" }
attributes #13 = { "wasm-export-name"="guest_heap_free" }
attributes #14 = { nocallback nofree nosync nounwind willreturn memory(read) "wasm-import-module"="env" "wasm-import-name"="llvm.wasm.memory.size.i32" }
attributes #15 = { "wasm-export-name"="guest_heap_init" }
attributes #16 = { nocallback nofree nosync nounwind willreturn "wasm-import-module"="env" "wasm-import-name"="llvm.wasm.memory.grow.i32" }
attributes #17 = { "wasm-export-name"="guest_heap_extend" }
attributes #18 = { "wasm-export-name"="guest_wasm_allocate" }
attributes #19 = { "wasm-export-name"="guest_wasm_reallocate" }
