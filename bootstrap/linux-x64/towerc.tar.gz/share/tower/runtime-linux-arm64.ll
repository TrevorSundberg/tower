; ModuleID = '/cache/iteration-stage1/guest-linux-arm64-unbound.ll'
source_filename = "Tower"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-unknown-linux-gnu"

@0 = private unnamed_addr constant [17 x i8] c"Division by zero\00", align 1
@1 = private unnamed_addr constant [67 x i8] c"Numeric conversion out of range; use bits for bit reinterpretation\00", align 1
@2 = private unnamed_addr constant [67 x i8] c"Numeric conversion out of range; use bits for bit reinterpretation\00", align 1
@3 = private unnamed_addr constant [67 x i8] c"Numeric conversion out of range; use bits for bit reinterpretation\00", align 1
@tower.string = private global [6 x i8] c"true\0A\00", align 1
@tower.string.1 = private global [7 x i8] c"false\0A\00", align 1
@4 = private unnamed_addr constant [67 x i8] c"Numeric conversion out of range; use bits for bit reinterpretation\00", align 1
@tower.string.2 = private global [17 x i8] c"0123456789abcdef\00", align 1
@5 = private unnamed_addr constant [17 x i8] c"Division by zero\00", align 1
@6 = private unnamed_addr constant [17 x i8] c"Division by zero\00", align 1
@7 = private unnamed_addr constant [17 x i8] c"Division by zero\00", align 1
@8 = private unnamed_addr constant [67 x i8] c"Numeric conversion out of range; use bits for bit reinterpretation\00", align 1
@9 = private unnamed_addr constant [17 x i8] c"Division by zero\00", align 1
@10 = private unnamed_addr constant [67 x i8] c"Numeric conversion out of range; use bits for bit reinterpretation\00", align 1
@11 = private unnamed_addr constant [67 x i8] c"Numeric conversion out of range; use bits for bit reinterpretation\00", align 1
@12 = private unnamed_addr constant [67 x i8] c"Numeric conversion out of range; use bits for bit reinterpretation\00", align 1
@tower.string.3 = private global [2 x i8] c"\0A\00", align 1

define internal i8 @tower.fn.guest_runtime_product(i64 %0, i64 %1) {
entry:
  %count = alloca i64, align 8
  %size = alloca i64, align 8
  %maximum = alloca i64, align 8
  %limit = alloca i64, align 8
  %"control value 163" = alloca ptr, align 8
  %"control value 164" = alloca i64, align 8
  %"control value 165" = alloca i64, align 8
  %"control value 166" = alloca i64, align 8
  %"control value 167" = alloca i8, align 1
  %"control value 168" = alloca i64, align 8
  %"control value 169" = alloca i64, align 8
  %"control value 170" = alloca i64, align 8
  %"control value 171" = alloca i64, align 8
  %"control value 172" = alloca i64, align 8
  %"control value 173" = alloca i8, align 1
  store i64 %0, ptr %count, align 1
  store i64 %1, ptr %size, align 1
  store i64 0, ptr %maximum, align 1
  store ptr %maximum, ptr %"control value 163", align 1
  %2 = load ptr, ptr %"control value 163", align 1
  %3 = load i64, ptr %2, align 1
  store i64 %3, ptr %"control value 164", align 1
  %4 = load i64, ptr %"control value 164", align 1
  %5 = sub i64 %4, 1
  store i64 %5, ptr %"control value 165", align 1
  %6 = load ptr, ptr %"control value 163", align 1
  %7 = load i64, ptr %"control value 165", align 1
  store i64 %7, ptr %6, align 1
  %8 = load i64, ptr %size, align 1
  store i64 %8, ptr %"control value 166", align 1
  %9 = load i64, ptr %"control value 166", align 1
  %10 = icmp ne i64 %9, 0
  %11 = zext i1 %10 to i8
  store i8 %11, ptr %"control value 167", align 1
  %12 = load i8, ptr %"control value 167", align 1
  %13 = icmp ne i8 %12, 0
  br i1 %13, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  %14 = load i64, ptr %maximum, align 1
  store i64 %14, ptr %"control value 168", align 1
  %15 = load i64, ptr %size, align 1
  store i64 %15, ptr %"control value 169", align 1
  %16 = load i64, ptr %"control value 168", align 1
  %17 = load i64, ptr %"control value 169", align 1
  %18 = icmp ne i64 %17, 0
  br i1 %18, label %valid, label %error

if.else:                                          ; preds = %entry
  br label %if.end

if.end:                                           ; preds = %if.end3, %if.else
  ret i8 1

valid:                                            ; preds = %if.body
  %19 = udiv i64 %16, %17
  store i64 %19, ptr %"control value 170", align 1
  %20 = load i64, ptr %"control value 170", align 1
  store i64 %20, ptr %limit, align 1
  %21 = load i64, ptr %count, align 1
  store i64 %21, ptr %"control value 171", align 1
  %22 = load i64, ptr %limit, align 1
  store i64 %22, ptr %"control value 172", align 1
  %23 = load i64, ptr %"control value 171", align 1
  %24 = load i64, ptr %"control value 172", align 1
  %25 = icmp ugt i64 %23, %24
  %26 = zext i1 %25 to i8
  store i8 %26, ptr %"control value 173", align 1
  %27 = load i8, ptr %"control value 173", align 1
  %28 = icmp ne i8 %27, 0
  br i1 %28, label %if.body1, label %if.else2

error:                                            ; preds = %if.body
  call void @tower_trap(ptr @0, i64 14199)
  unreachable

if.body1:                                         ; preds = %valid
  ret i8 0

if.else2:                                         ; preds = %valid
  br label %if.end3

if.end3:                                          ; preds = %if.else2
  br label %if.end
}

define ptr @tower_allocate(i64 %0, i64 %1) {
entry:
  %count = alloca i64, align 8
  %size = alloca i64, align 8
  %bytes = alloca i64, align 8
  %"control value 174" = alloca i64, align 8
  %"control value 175" = alloca i64, align 8
  %"control value 176" = alloca i8, align 1
  %"control value 177" = alloca i8, align 1
  %"control value 178" = alloca i64, align 8
  %"control value 179" = alloca i64, align 8
  %"control value 180" = alloca i64, align 8
  %"control value 181" = alloca i64, align 8
  %"control value 182" = alloca ptr, align 8
  store i64 %0, ptr %count, align 1
  store i64 %1, ptr %size, align 1
  %2 = load i64, ptr %count, align 1
  store i64 %2, ptr %"control value 174", align 1
  %3 = load i64, ptr %size, align 1
  store i64 %3, ptr %"control value 175", align 1
  %4 = load i64, ptr %"control value 174", align 1
  %5 = load i64, ptr %"control value 175", align 1
  %6 = call i8 @tower.fn.guest_runtime_product(i64 %4, i64 %5)
  store i8 %6, ptr %"control value 176", align 1
  %7 = load i8, ptr %"control value 176", align 1
  %8 = icmp eq i8 0, %7
  %9 = zext i1 %8 to i8
  store i8 %9, ptr %"control value 177", align 1
  %10 = load i8, ptr %"control value 177", align 1
  %11 = icmp ne i8 %10, 0
  br i1 %11, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  ret ptr null

if.else:                                          ; preds = %entry
  br label %if.end

if.end:                                           ; preds = %if.else
  %12 = load i64, ptr %count, align 1
  store i64 %12, ptr %"control value 178", align 1
  %13 = load i64, ptr %size, align 1
  store i64 %13, ptr %"control value 179", align 1
  %14 = load i64, ptr %"control value 178", align 1
  %15 = load i64, ptr %"control value 179", align 1
  %16 = mul i64 %14, %15
  store i64 %16, ptr %"control value 180", align 1
  %17 = load i64, ptr %"control value 180", align 1
  store i64 %17, ptr %bytes, align 1
  %18 = load i64, ptr %bytes, align 1
  store i64 %18, ptr %"control value 181", align 1
  %19 = load i64, ptr %"control value 181", align 1
  %20 = call ptr @guest_host_allocate(i64 %19)
  store ptr %20, ptr %"control value 182", align 1
  %21 = load ptr, ptr %"control value 182", align 1
  ret ptr %21
}

define ptr @tower_reallocate(ptr %0, i64 %1, i64 %2) {
entry:
  %pointer = alloca ptr, align 8
  %count = alloca i64, align 8
  %size = alloca i64, align 8
  %bytes = alloca i64, align 8
  %"control value 183" = alloca i64, align 8
  %"control value 184" = alloca i64, align 8
  %"control value 185" = alloca i8, align 1
  %"control value 186" = alloca i8, align 1
  %"control value 187" = alloca i64, align 8
  %"control value 188" = alloca i64, align 8
  %"control value 189" = alloca i64, align 8
  %"control value 190" = alloca ptr, align 8
  %"control value 191" = alloca i64, align 8
  %"control value 192" = alloca ptr, align 8
  store ptr %0, ptr %pointer, align 1
  store i64 %1, ptr %count, align 1
  store i64 %2, ptr %size, align 1
  %3 = load i64, ptr %count, align 1
  store i64 %3, ptr %"control value 183", align 1
  %4 = load i64, ptr %size, align 1
  store i64 %4, ptr %"control value 184", align 1
  %5 = load i64, ptr %"control value 183", align 1
  %6 = load i64, ptr %"control value 184", align 1
  %7 = call i8 @tower.fn.guest_runtime_product(i64 %5, i64 %6)
  store i8 %7, ptr %"control value 185", align 1
  %8 = load i8, ptr %"control value 185", align 1
  %9 = icmp eq i8 0, %8
  %10 = zext i1 %9 to i8
  store i8 %10, ptr %"control value 186", align 1
  %11 = load i8, ptr %"control value 186", align 1
  %12 = icmp ne i8 %11, 0
  br i1 %12, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  ret ptr null

if.else:                                          ; preds = %entry
  br label %if.end

if.end:                                           ; preds = %if.else
  %13 = load i64, ptr %count, align 1
  store i64 %13, ptr %"control value 187", align 1
  %14 = load i64, ptr %size, align 1
  store i64 %14, ptr %"control value 188", align 1
  %15 = load i64, ptr %"control value 187", align 1
  %16 = load i64, ptr %"control value 188", align 1
  %17 = mul i64 %15, %16
  store i64 %17, ptr %"control value 189", align 1
  %18 = load i64, ptr %"control value 189", align 1
  store i64 %18, ptr %bytes, align 1
  %19 = load ptr, ptr %pointer, align 1
  store ptr %19, ptr %"control value 190", align 1
  %20 = load i64, ptr %bytes, align 1
  store i64 %20, ptr %"control value 191", align 1
  %21 = load ptr, ptr %"control value 190", align 1
  %22 = load i64, ptr %"control value 191", align 1
  %23 = call ptr @guest_host_reallocate(ptr %21, i64 %22)
  store ptr %23, ptr %"control value 192", align 1
  %24 = load ptr, ptr %"control value 192", align 1
  ret ptr %24
}

define void @tower_deallocate(ptr %0) {
entry:
  %pointer = alloca ptr, align 8
  %"control value 193" = alloca ptr, align 8
  store ptr %0, ptr %pointer, align 1
  %1 = load ptr, ptr %pointer, align 1
  store ptr %1, ptr %"control value 193", align 1
  %2 = load ptr, ptr %"control value 193", align 1
  call void @guest_host_free(ptr %2)
  ret void
}

define i64 @system_call(i64 %0, i64 %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6) {
entry:
  %result = call i64 asm sideeffect "svc 0", "={x0},{x8},{x0},{x1},{x2},{x3},{x4},{x5},~{memory}"(i64 %0, i64 %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6)
  ret i64 %result
}

define internal i64 @tower.fn.GuestLinuxReadWrite() {
entry:
  %result = alloca i64, align 8
  %"control value 194" = alloca i64, align 8
  store i64 3, ptr %result, align 1
  %0 = load i64, ptr %result, align 1
  store i64 %0, ptr %"control value 194", align 1
  %1 = load i64, ptr %"control value 194", align 1
  ret i64 %1
}

define internal i64 @tower.fn.GuestLinuxPrivateAnonymous() {
entry:
  %result = alloca i64, align 8
  %"control value 195" = alloca i64, align 8
  store i64 34, ptr %result, align 1
  %0 = load i64, ptr %result, align 1
  store i64 %0, ptr %"control value 195", align 1
  %1 = load i64, ptr %"control value 195", align 1
  ret i64 %1
}

define internal i64 @tower.fn.GuestLinuxHeaderBytes() {
entry:
  %result = alloca i64, align 8
  %"control value 196" = alloca i64, align 8
  store i64 16, ptr %result, align 1
  %0 = load i64, ptr %result, align 1
  store i64 %0, ptr %"control value 196", align 1
  %1 = load i64, ptr %"control value 196", align 1
  ret i64 %1
}

define ptr @guest_host_allocate(i64 %0) {
entry:
  %bytes = alloca i64, align 8
  %maximum = alloca i64, align 8
  %limit = alloca i64, align 8
  %total = alloca i64, align 8
  %result = alloca i64, align 8
  %address = alloca i64, align 8
  %header = alloca ptr, align 8
  %data = alloca ptr, align 8
  %"control value 197" = alloca ptr, align 8
  %"control value 198" = alloca i64, align 8
  %"control value 199" = alloca i64, align 8
  %"control value 200" = alloca i64, align 8
  %"control value 201" = alloca i64, align 8
  %"control value 202" = alloca i64, align 8
  %"control value 203" = alloca i64, align 8
  %"control value 204" = alloca i64, align 8
  %"control value 205" = alloca i8, align 1
  %"control value 206" = alloca i64, align 8
  %"control value 207" = alloca i64, align 8
  %"control value 208" = alloca i64, align 8
  %"control value 209" = alloca i64, align 8
  %"control value 210" = alloca i64, align 8
  %"control value 211" = alloca i64, align 8
  %"control value 212" = alloca i64, align 8
  %"control value 213" = alloca i64, align 8
  %"control value 214" = alloca i64, align 8
  %"control value 215" = alloca i64, align 8
  %"control value 216" = alloca i64, align 8
  %"control value 217" = alloca i64, align 8
  %"control value 218" = alloca i8, align 1
  %"control value 219" = alloca i64, align 8
  %"control value 220" = alloca ptr, align 8
  %"control value 221" = alloca ptr, align 8
  %"control value 222" = alloca ptr, align 8
  %"control value 223" = alloca i64, align 8
  %"control value 224" = alloca ptr, align 8
  %"control value 225" = alloca ptr, align 8
  %"control value 226" = alloca ptr, align 8
  %"control value 227" = alloca ptr, align 8
  %"control value 228" = alloca i64, align 8
  %"control value 229" = alloca ptr, align 8
  %"control value 230" = alloca ptr, align 8
  %"control value 231" = alloca ptr, align 8
  store i64 %0, ptr %bytes, align 1
  store i64 0, ptr %maximum, align 1
  store ptr %maximum, ptr %"control value 197", align 1
  %1 = load ptr, ptr %"control value 197", align 1
  %2 = load i64, ptr %1, align 1
  store i64 %2, ptr %"control value 198", align 1
  %3 = load i64, ptr %"control value 198", align 1
  %4 = sub i64 %3, 1
  store i64 %4, ptr %"control value 199", align 1
  %5 = load ptr, ptr %"control value 197", align 1
  %6 = load i64, ptr %"control value 199", align 1
  store i64 %6, ptr %5, align 1
  %7 = load i64, ptr %maximum, align 1
  store i64 %7, ptr %"control value 200", align 1
  %8 = call i64 @tower.fn.GuestLinuxHeaderBytes()
  store i64 %8, ptr %"control value 201", align 1
  %9 = load i64, ptr %"control value 200", align 1
  %10 = load i64, ptr %"control value 201", align 1
  %11 = sub i64 %9, %10
  store i64 %11, ptr %"control value 202", align 1
  %12 = load i64, ptr %"control value 202", align 1
  store i64 %12, ptr %limit, align 1
  %13 = load i64, ptr %bytes, align 1
  store i64 %13, ptr %"control value 203", align 1
  %14 = load i64, ptr %limit, align 1
  store i64 %14, ptr %"control value 204", align 1
  %15 = load i64, ptr %"control value 203", align 1
  %16 = load i64, ptr %"control value 204", align 1
  %17 = icmp ugt i64 %15, %16
  %18 = zext i1 %17 to i8
  store i8 %18, ptr %"control value 205", align 1
  %19 = load i8, ptr %"control value 205", align 1
  %20 = icmp ne i8 %19, 0
  br i1 %20, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  ret ptr null

if.else:                                          ; preds = %entry
  br label %if.end

if.end:                                           ; preds = %if.else
  %21 = load i64, ptr %bytes, align 1
  store i64 %21, ptr %"control value 206", align 1
  %22 = call i64 @tower.fn.GuestLinuxHeaderBytes()
  store i64 %22, ptr %"control value 207", align 1
  %23 = load i64, ptr %"control value 206", align 1
  %24 = load i64, ptr %"control value 207", align 1
  %25 = add i64 %23, %24
  store i64 %25, ptr %"control value 208", align 1
  %26 = load i64, ptr %"control value 208", align 1
  store i64 %26, ptr %total, align 1
  %27 = call i64 @guest_linux_map_number()
  store i64 %27, ptr %"control value 209", align 1
  %28 = load i64, ptr %total, align 1
  store i64 %28, ptr %"control value 210", align 1
  %29 = load i64, ptr %"control value 210", align 1
  store i64 %29, ptr %"control value 211", align 1
  %30 = call i64 @tower.fn.GuestLinuxReadWrite()
  store i64 %30, ptr %"control value 212", align 1
  %31 = call i64 @tower.fn.GuestLinuxPrivateAnonymous()
  store i64 %31, ptr %"control value 213", align 1
  %32 = load i64, ptr %"control value 209", align 1
  %33 = load i64, ptr %"control value 211", align 1
  %34 = load i64, ptr %"control value 212", align 1
  %35 = load i64, ptr %"control value 213", align 1
  %36 = call i64 @system_call(i64 %32, i64 0, i64 %33, i64 %34, i64 %35, i64 -1, i64 0)
  store i64 %36, ptr %"control value 214", align 1
  %37 = load i64, ptr %"control value 214", align 1
  store i64 %37, ptr %result, align 1
  %38 = load i64, ptr %result, align 1
  store i64 %38, ptr %"control value 215", align 1
  %39 = load i64, ptr %"control value 215", align 1
  store i64 %39, ptr %"control value 216", align 1
  %40 = load i64, ptr %"control value 216", align 1
  store i64 %40, ptr %address, align 1
  %41 = load i64, ptr %address, align 1
  store i64 %41, ptr %"control value 217", align 1
  %42 = load i64, ptr %"control value 217", align 1
  %43 = icmp uge i64 %42, -4095
  %44 = zext i1 %43 to i8
  store i8 %44, ptr %"control value 218", align 1
  %45 = load i8, ptr %"control value 218", align 1
  %46 = icmp ne i8 %45, 0
  br i1 %46, label %if.body1, label %if.else2

if.body1:                                         ; preds = %if.end
  ret ptr null

if.else2:                                         ; preds = %if.end
  br label %if.end3

if.end3:                                          ; preds = %if.else2
  %47 = load i64, ptr %result, align 1
  store i64 %47, ptr %"control value 219", align 1
  %48 = load i64, ptr %"control value 219", align 1
  %49 = inttoptr i64 %48 to ptr
  store ptr %49, ptr %"control value 220", align 1
  %50 = load ptr, ptr %"control value 220", align 1
  store ptr %50, ptr %header, align 1
  %51 = load ptr, ptr %header, align 1
  store ptr %51, ptr %"control value 221", align 1
  %52 = load ptr, ptr %"control value 221", align 1
  %53 = getelementptr i8, ptr %52, i64 0
  store ptr %53, ptr %"control value 222", align 1
  %54 = load i64, ptr %total, align 1
  store i64 %54, ptr %"control value 223", align 1
  %55 = load ptr, ptr %"control value 222", align 1
  %56 = load i64, ptr %"control value 223", align 1
  store i64 %56, ptr %55, align 1
  %57 = load ptr, ptr %header, align 1
  store ptr %57, ptr %"control value 224", align 1
  %58 = load ptr, ptr %"control value 224", align 1
  store ptr %58, ptr %"control value 225", align 1
  %59 = load ptr, ptr %"control value 225", align 1
  store ptr %59, ptr %data, align 1
  store ptr %data, ptr %"control value 226", align 1
  %60 = load ptr, ptr %data, align 1
  store ptr %60, ptr %"control value 227", align 1
  %61 = call i64 @tower.fn.GuestLinuxHeaderBytes()
  store i64 %61, ptr %"control value 228", align 1
  %62 = load ptr, ptr %"control value 227", align 1
  %63 = load i64, ptr %"control value 228", align 1
  %64 = mul i64 %63, 1
  %65 = getelementptr i8, ptr %62, i64 %64
  store ptr %65, ptr %"control value 229", align 1
  %66 = load ptr, ptr %"control value 226", align 1
  %67 = load ptr, ptr %"control value 229", align 1
  store ptr %67, ptr %66, align 1
  %68 = load ptr, ptr %data, align 1
  store ptr %68, ptr %"control value 230", align 1
  %69 = load ptr, ptr %"control value 230", align 1
  store ptr %69, ptr %"control value 231", align 1
  %70 = load ptr, ptr %"control value 231", align 1
  ret ptr %70
}

define void @guest_host_free(ptr %0) {
entry:
  %pointer = alloca ptr, align 8
  %base = alloca ptr, align 8
  %header = alloca ptr, align 8
  %"control value 232" = alloca ptr, align 8
  %"control value 233" = alloca i8, align 1
  %"control value 234" = alloca ptr, align 8
  %"control value 235" = alloca ptr, align 8
  %"control value 236" = alloca ptr, align 8
  %"control value 237" = alloca ptr, align 8
  %"control value 238" = alloca i64, align 8
  %"control value 239" = alloca ptr, align 8
  %"control value 240" = alloca ptr, align 8
  %"control value 241" = alloca ptr, align 8
  %"control value 242" = alloca i64, align 8
  %"control value 243" = alloca ptr, align 8
  %"control value 244" = alloca i64, align 8
  %"control value 245" = alloca ptr, align 8
  %"control value 246" = alloca i64, align 8
  %"control value 247" = alloca i64, align 8
  %"control value 248" = alloca i64, align 8
  store ptr %0, ptr %pointer, align 1
  %1 = load ptr, ptr %pointer, align 1
  store ptr %1, ptr %"control value 232", align 1
  %2 = load ptr, ptr %"control value 232", align 1
  %3 = icmp eq ptr %2, null
  %4 = zext i1 %3 to i8
  store i8 %4, ptr %"control value 233", align 1
  %5 = load i8, ptr %"control value 233", align 1
  %6 = icmp ne i8 %5, 0
  br i1 %6, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  ret void

if.else:                                          ; preds = %entry
  br label %if.end

if.end:                                           ; preds = %if.else
  %7 = load ptr, ptr %pointer, align 1
  store ptr %7, ptr %"control value 234", align 1
  %8 = load ptr, ptr %"control value 234", align 1
  store ptr %8, ptr %"control value 235", align 1
  %9 = load ptr, ptr %"control value 235", align 1
  store ptr %9, ptr %base, align 1
  store ptr %base, ptr %"control value 236", align 1
  %10 = load ptr, ptr %base, align 1
  store ptr %10, ptr %"control value 237", align 1
  %11 = call i64 @tower.fn.GuestLinuxHeaderBytes()
  store i64 %11, ptr %"control value 238", align 1
  %12 = load ptr, ptr %"control value 237", align 1
  %13 = load i64, ptr %"control value 238", align 1
  %14 = mul i64 %13, 1
  %15 = sub i64 0, %14
  %16 = getelementptr i8, ptr %12, i64 %15
  store ptr %16, ptr %"control value 239", align 1
  %17 = load ptr, ptr %"control value 236", align 1
  %18 = load ptr, ptr %"control value 239", align 1
  store ptr %18, ptr %17, align 1
  %19 = load ptr, ptr %base, align 1
  store ptr %19, ptr %"control value 240", align 1
  %20 = load ptr, ptr %"control value 240", align 1
  store ptr %20, ptr %"control value 241", align 1
  %21 = load ptr, ptr %"control value 241", align 1
  store ptr %21, ptr %header, align 1
  %22 = call i64 @guest_linux_unmap_number()
  store i64 %22, ptr %"control value 242", align 1
  %23 = load ptr, ptr %base, align 1
  store ptr %23, ptr %"control value 243", align 1
  %24 = load ptr, ptr %"control value 243", align 1
  %25 = ptrtoint ptr %24 to i64
  store i64 %25, ptr %"control value 244", align 1
  %26 = load ptr, ptr %header, align 1
  store ptr %26, ptr %"control value 245", align 1
  %27 = load ptr, ptr %"control value 245", align 1
  %28 = getelementptr i8, ptr %27, i64 0
  %29 = load i64, ptr %28, align 1
  store i64 %29, ptr %"control value 246", align 1
  %30 = load i64, ptr %"control value 246", align 1
  store i64 %30, ptr %"control value 247", align 1
  %31 = load i64, ptr %"control value 242", align 1
  %32 = load i64, ptr %"control value 244", align 1
  %33 = load i64, ptr %"control value 247", align 1
  %34 = call i64 @system_call(i64 %31, i64 %32, i64 %33, i64 0, i64 0, i64 0, i64 0)
  store i64 %34, ptr %"control value 248", align 1
  ret void
}

define ptr @guest_host_reallocate(ptr %0, i64 %1) {
entry:
  %pointer = alloca ptr, align 8
  %bytes = alloca i64, align 8
  %base = alloca ptr, align 8
  %header = alloca ptr, align 8
  %old = alloca i64, align 8
  %result = alloca ptr, align 8
  %"control value 249" = alloca ptr, align 8
  %"control value 250" = alloca i8, align 1
  %"control value 251" = alloca i64, align 8
  %"control value 252" = alloca ptr, align 8
  %"control value 253" = alloca i64, align 8
  %"control value 254" = alloca i8, align 1
  %"control value 255" = alloca ptr, align 8
  %"control value 256" = alloca ptr, align 8
  %"control value 257" = alloca ptr, align 8
  %"control value 258" = alloca ptr, align 8
  %"control value 259" = alloca ptr, align 8
  %"control value 260" = alloca i64, align 8
  %"control value 261" = alloca ptr, align 8
  %"control value 262" = alloca ptr, align 8
  %"control value 263" = alloca ptr, align 8
  %"control value 264" = alloca ptr, align 8
  %"control value 265" = alloca i64, align 8
  %"control value 266" = alloca i64, align 8
  %"control value 267" = alloca i64, align 8
  %"control value 268" = alloca i64, align 8
  %"control value 269" = alloca ptr, align 8
  %"control value 270" = alloca ptr, align 8
  %"control value 271" = alloca i8, align 1
  %"control value 272" = alloca i64, align 8
  %"control value 273" = alloca i64, align 8
  %"control value 274" = alloca i8, align 1
  %"control value 275" = alloca ptr, align 8
  %"control value 276" = alloca i64, align 8
  %"control value 277" = alloca ptr, align 8
  %"control value 278" = alloca ptr, align 8
  %"control value 279" = alloca i64, align 8
  %"control value 280" = alloca ptr, align 8
  %"control value 281" = alloca ptr, align 8
  store ptr %0, ptr %pointer, align 1
  store i64 %1, ptr %bytes, align 1
  %2 = load ptr, ptr %pointer, align 1
  store ptr %2, ptr %"control value 249", align 1
  %3 = load ptr, ptr %"control value 249", align 1
  %4 = icmp eq ptr %3, null
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %"control value 250", align 1
  %6 = load i8, ptr %"control value 250", align 1
  %7 = icmp ne i8 %6, 0
  br i1 %7, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  %8 = load i64, ptr %bytes, align 1
  store i64 %8, ptr %"control value 251", align 1
  %9 = load i64, ptr %"control value 251", align 1
  %10 = call ptr @guest_host_allocate(i64 %9)
  store ptr %10, ptr %"control value 252", align 1
  %11 = load ptr, ptr %"control value 252", align 1
  ret ptr %11

if.else:                                          ; preds = %entry
  br label %if.end

if.end:                                           ; preds = %if.else
  %12 = load i64, ptr %bytes, align 1
  store i64 %12, ptr %"control value 253", align 1
  %13 = load i64, ptr %"control value 253", align 1
  %14 = icmp eq i64 %13, 0
  %15 = zext i1 %14 to i8
  store i8 %15, ptr %"control value 254", align 1
  %16 = load i8, ptr %"control value 254", align 1
  %17 = icmp ne i8 %16, 0
  br i1 %17, label %if.body1, label %if.else2

if.body1:                                         ; preds = %if.end
  %18 = load ptr, ptr %pointer, align 1
  store ptr %18, ptr %"control value 255", align 1
  %19 = load ptr, ptr %"control value 255", align 1
  call void @guest_host_free(ptr %19)
  ret ptr null

if.else2:                                         ; preds = %if.end
  br label %if.end3

if.end3:                                          ; preds = %if.else2
  %20 = load ptr, ptr %pointer, align 1
  store ptr %20, ptr %"control value 256", align 1
  %21 = load ptr, ptr %"control value 256", align 1
  store ptr %21, ptr %"control value 257", align 1
  %22 = load ptr, ptr %"control value 257", align 1
  store ptr %22, ptr %base, align 1
  store ptr %base, ptr %"control value 258", align 1
  %23 = load ptr, ptr %base, align 1
  store ptr %23, ptr %"control value 259", align 1
  %24 = call i64 @tower.fn.GuestLinuxHeaderBytes()
  store i64 %24, ptr %"control value 260", align 1
  %25 = load ptr, ptr %"control value 259", align 1
  %26 = load i64, ptr %"control value 260", align 1
  %27 = mul i64 %26, 1
  %28 = sub i64 0, %27
  %29 = getelementptr i8, ptr %25, i64 %28
  store ptr %29, ptr %"control value 261", align 1
  %30 = load ptr, ptr %"control value 258", align 1
  %31 = load ptr, ptr %"control value 261", align 1
  store ptr %31, ptr %30, align 1
  %32 = load ptr, ptr %base, align 1
  store ptr %32, ptr %"control value 262", align 1
  %33 = load ptr, ptr %"control value 262", align 1
  store ptr %33, ptr %"control value 263", align 1
  %34 = load ptr, ptr %"control value 263", align 1
  store ptr %34, ptr %header, align 1
  %35 = load ptr, ptr %header, align 1
  store ptr %35, ptr %"control value 264", align 1
  %36 = load ptr, ptr %"control value 264", align 1
  %37 = getelementptr i8, ptr %36, i64 0
  %38 = load i64, ptr %37, align 1
  store i64 %38, ptr %"control value 265", align 1
  %39 = call i64 @tower.fn.GuestLinuxHeaderBytes()
  store i64 %39, ptr %"control value 266", align 1
  %40 = load i64, ptr %"control value 265", align 1
  %41 = load i64, ptr %"control value 266", align 1
  %42 = sub i64 %40, %41
  store i64 %42, ptr %"control value 267", align 1
  %43 = load i64, ptr %"control value 267", align 1
  store i64 %43, ptr %old, align 1
  %44 = load i64, ptr %bytes, align 1
  store i64 %44, ptr %"control value 268", align 1
  %45 = load i64, ptr %"control value 268", align 1
  %46 = call ptr @guest_host_allocate(i64 %45)
  store ptr %46, ptr %"control value 269", align 1
  %47 = load ptr, ptr %"control value 269", align 1
  store ptr %47, ptr %result, align 1
  %48 = load ptr, ptr %result, align 1
  store ptr %48, ptr %"control value 270", align 1
  %49 = load ptr, ptr %"control value 270", align 1
  %50 = icmp ne ptr %49, null
  %51 = zext i1 %50 to i8
  store i8 %51, ptr %"control value 271", align 1
  %52 = load i8, ptr %"control value 271", align 1
  %53 = icmp ne i8 %52, 0
  br i1 %53, label %if.body4, label %if.else5

if.body4:                                         ; preds = %if.end3
  %54 = load i64, ptr %bytes, align 1
  store i64 %54, ptr %"control value 272", align 1
  %55 = load i64, ptr %old, align 1
  store i64 %55, ptr %"control value 273", align 1
  %56 = load i64, ptr %"control value 272", align 1
  %57 = load i64, ptr %"control value 273", align 1
  %58 = icmp ult i64 %56, %57
  %59 = zext i1 %58 to i8
  store i8 %59, ptr %"control value 274", align 1
  %60 = load i8, ptr %"control value 274", align 1
  %61 = icmp ne i8 %60, 0
  br i1 %61, label %if.body7, label %if.else8

if.else5:                                         ; preds = %if.end3
  br label %if.end6

if.end6:                                          ; preds = %if.end9, %if.else5
  %62 = load ptr, ptr %result, align 1
  store ptr %62, ptr %"control value 281", align 1
  %63 = load ptr, ptr %"control value 281", align 1
  ret ptr %63

if.body7:                                         ; preds = %if.body4
  store ptr %old, ptr %"control value 275", align 1
  %64 = load i64, ptr %bytes, align 1
  store i64 %64, ptr %"control value 276", align 1
  %65 = load ptr, ptr %"control value 275", align 1
  %66 = load i64, ptr %"control value 276", align 1
  store i64 %66, ptr %65, align 1
  br label %if.end9

if.else8:                                         ; preds = %if.body4
  br label %if.end9

if.end9:                                          ; preds = %if.else8, %if.body7
  %67 = load ptr, ptr %result, align 1
  store ptr %67, ptr %"control value 277", align 1
  %68 = load ptr, ptr %pointer, align 1
  store ptr %68, ptr %"control value 278", align 1
  %69 = load i64, ptr %old, align 1
  store i64 %69, ptr %"control value 279", align 1
  %70 = load ptr, ptr %"control value 277", align 1
  %71 = load ptr, ptr %"control value 278", align 1
  %72 = load i64, ptr %"control value 279", align 1
  call void @llvm.memmove.p0.p0.i64(ptr align 1 %70, ptr align 1 %71, i64 %72, i1 false)
  %73 = load ptr, ptr %pointer, align 1
  store ptr %73, ptr %"control value 280", align 1
  %74 = load ptr, ptr %"control value 280", align 1
  call void @guest_host_free(ptr %74)
  br label %if.end6
}

define i64 @platform_write(i32 %0, ptr %1, i64 %2) {
entry:
  %stream = alloca i32, align 4
  %bytes = alloca ptr, align 8
  %count = alloca i64, align 8
  %valid = alloca i8, align 1
  %result = alloca i64, align 8
  %"control value 282" = alloca i32, align 4
  %"control value 283" = alloca i8, align 1
  %"control value 284" = alloca ptr, align 8
  %"control value 285" = alloca i8, align 1
  %"control value 286" = alloca i8, align 1
  %"control value 287" = alloca i8, align 1
  %"control value 288" = alloca i32, align 4
  %"control value 289" = alloca i8, align 1
  %"control value 290" = alloca i8, align 1
  %"control value 291" = alloca i8, align 1
  %"control value 292" = alloca i64, align 8
  %"control value 293" = alloca i32, align 4
  %"control value 294" = alloca i64, align 8
  %"control value 295" = alloca ptr, align 8
  %"control value 296" = alloca i64, align 8
  %"control value 297" = alloca i64, align 8
  %"control value 298" = alloca i64, align 8
  %"control value 299" = alloca i64, align 8
  %"control value 300" = alloca i64, align 8
  %"control value 301" = alloca i8, align 1
  %"control value 302" = alloca i64, align 8
  store i32 %0, ptr %stream, align 1
  store ptr %1, ptr %bytes, align 1
  store i64 %2, ptr %count, align 1
  %3 = load i32, ptr %stream, align 1
  store i32 %3, ptr %"control value 282", align 1
  %4 = load i32, ptr %"control value 282", align 1
  %5 = icmp eq i32 %4, 1
  %6 = zext i1 %5 to i8
  store i8 %6, ptr %"control value 283", align 1
  %7 = load i8, ptr %"control value 283", align 1
  store i8 %7, ptr %valid, align 1
  store ptr %valid, ptr %"control value 284", align 1
  %8 = load ptr, ptr %"control value 284", align 1
  %9 = load i8, ptr %8, align 1
  store i8 %9, ptr %"control value 285", align 1
  %10 = load i8, ptr %"control value 285", align 1
  store i8 %10, ptr %"control value 286", align 1
  %11 = load i8, ptr %"control value 286", align 1
  store i8 %11, ptr %"control value 287", align 1
  %12 = load i8, ptr %"control value 286", align 1
  %13 = icmp ne i8 %12, 0
  br i1 %13, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  br label %if.end

if.else:                                          ; preds = %entry
  %14 = load i32, ptr %stream, align 1
  store i32 %14, ptr %"control value 288", align 1
  %15 = load i32, ptr %"control value 288", align 1
  %16 = icmp eq i32 %15, 2
  %17 = zext i1 %16 to i8
  store i8 %17, ptr %"control value 289", align 1
  %18 = load i8, ptr %"control value 289", align 1
  store i8 %18, ptr %"control value 287", align 1
  %19 = load ptr, ptr %"control value 284", align 1
  %20 = load i8, ptr %"control value 289", align 1
  store i8 %20, ptr %19, align 1
  br label %if.end

if.end:                                           ; preds = %if.else, %if.body
  %21 = load i8, ptr %valid, align 1
  store i8 %21, ptr %"control value 290", align 1
  %22 = load i8, ptr %"control value 290", align 1
  %23 = icmp eq i8 0, %22
  %24 = zext i1 %23 to i8
  store i8 %24, ptr %"control value 291", align 1
  %25 = load i8, ptr %"control value 291", align 1
  %26 = icmp ne i8 %25, 0
  br i1 %26, label %if.body1, label %if.else2

if.body1:                                         ; preds = %if.end
  ret i64 -1

if.else2:                                         ; preds = %if.end
  br label %if.end3

if.end3:                                          ; preds = %if.else2
  %27 = call i64 @guest_linux_write_number()
  store i64 %27, ptr %"control value 292", align 1
  %28 = load i32, ptr %stream, align 1
  store i32 %28, ptr %"control value 293", align 1
  %29 = load i32, ptr %"control value 293", align 1
  %30 = zext i32 %29 to i64
  %31 = icmp ule i64 %30, 9223372036854775807
  %32 = and i1 true, %31
  br i1 %32, label %valid4, label %error

valid4:                                           ; preds = %if.end3
  %33 = zext i32 %29 to i64
  store i64 %33, ptr %"control value 294", align 1
  %34 = load ptr, ptr %bytes, align 1
  store ptr %34, ptr %"control value 295", align 1
  %35 = load ptr, ptr %"control value 295", align 1
  %36 = ptrtoint ptr %35 to i64
  store i64 %36, ptr %"control value 296", align 1
  %37 = load i64, ptr %count, align 1
  store i64 %37, ptr %"control value 297", align 1
  %38 = load i64, ptr %"control value 297", align 1
  store i64 %38, ptr %"control value 298", align 1
  %39 = load i64, ptr %"control value 292", align 1
  %40 = load i64, ptr %"control value 294", align 1
  %41 = load i64, ptr %"control value 296", align 1
  %42 = load i64, ptr %"control value 298", align 1
  %43 = call i64 @system_call(i64 %39, i64 %40, i64 %41, i64 %42, i64 0, i64 0, i64 0)
  store i64 %43, ptr %"control value 299", align 1
  %44 = load i64, ptr %"control value 299", align 1
  store i64 %44, ptr %result, align 1
  %45 = load i64, ptr %result, align 1
  store i64 %45, ptr %"control value 300", align 1
  %46 = load i64, ptr %"control value 300", align 1
  %47 = icmp slt i64 %46, 0
  %48 = zext i1 %47 to i8
  store i8 %48, ptr %"control value 301", align 1
  %49 = load i8, ptr %"control value 301", align 1
  %50 = icmp ne i8 %49, 0
  br i1 %50, label %if.body5, label %if.else6

error:                                            ; preds = %if.end3
  call void @tower_trap(ptr @1, i64 15341)
  unreachable

if.body5:                                         ; preds = %valid4
  ret i64 -1

if.else6:                                         ; preds = %valid4
  br label %if.end7

if.end7:                                          ; preds = %if.else6
  %51 = load i64, ptr %result, align 1
  store i64 %51, ptr %"control value 302", align 1
  %52 = load i64, ptr %"control value 302", align 1
  ret i64 %52
}

define void @guest_exit(i32 %0) {
entry:
  %status = alloca i32, align 4
  %"control value 303" = alloca i64, align 8
  %"control value 304" = alloca i32, align 4
  %"control value 305" = alloca i64, align 8
  %"control value 306" = alloca i64, align 8
  store i32 %0, ptr %status, align 1
  %1 = call i64 @guest_linux_exit_number()
  store i64 %1, ptr %"control value 303", align 1
  %2 = load i32, ptr %status, align 1
  store i32 %2, ptr %"control value 304", align 1
  %3 = load i32, ptr %"control value 304", align 1
  %4 = sext i32 %3 to i64
  %5 = icmp sge i64 %4, -9223372036854775808
  %6 = icmp sle i64 %4, 9223372036854775807
  %7 = and i1 %5, %6
  br i1 %7, label %valid, label %error

valid:                                            ; preds = %entry
  %8 = sext i32 %3 to i64
  store i64 %8, ptr %"control value 305", align 1
  %9 = load i64, ptr %"control value 303", align 1
  %10 = load i64, ptr %"control value 305", align 1
  %11 = call i64 @system_call(i64 %9, i64 %10, i64 0, i64 0, i64 0, i64 0, i64 0)
  store i64 %11, ptr %"control value 306", align 1
  ret void

error:                                            ; preds = %entry
  call void @tower_trap(ptr @2, i64 15341)
  unreachable
}

define i64 @guest_linux_write_number() {
entry:
  ret i64 64
}

define i64 @guest_linux_exit_number() {
entry:
  ret i64 93
}

define i64 @guest_linux_map_number() {
entry:
  ret i64 222
}

define i64 @guest_linux_unmap_number() {
entry:
  ret i64 215
}

define ptr @memcpy(ptr %0, ptr %1, i64 %2) {
entry:
  %destination = alloca ptr, align 8
  %source = alloca ptr, align 8
  %count = alloca i64, align 8
  %out = alloca ptr, align 8
  %input = alloca ptr, align 8
  %i = alloca i64, align 8
  %"control value 158" = alloca i8, align 1
  %"control value 307" = alloca ptr, align 8
  %"control value 308" = alloca ptr, align 8
  %"control value 309" = alloca ptr, align 8
  %"control value 310" = alloca ptr, align 8
  %"control value 311" = alloca i64, align 8
  %"control value 312" = alloca i64, align 8
  %"control value 313" = alloca i8, align 1
  %"control value 314" = alloca i8, align 1
  %"control value 315" = alloca ptr, align 8
  %"control value 316" = alloca i64, align 8
  %"control value 317" = alloca ptr, align 8
  %"control value 318" = alloca ptr, align 8
  %"control value 319" = alloca i64, align 8
  %"control value 320" = alloca i8, align 1
  %"control value 321" = alloca ptr, align 8
  %"control value 322" = alloca i64, align 8
  %"control value 323" = alloca i64, align 8
  %"control value 324" = alloca ptr, align 8
  store ptr %0, ptr %destination, align 1
  store ptr %1, ptr %source, align 1
  store i64 %2, ptr %count, align 1
  %3 = load ptr, ptr %destination, align 1
  store ptr %3, ptr %"control value 307", align 1
  %4 = load ptr, ptr %"control value 307", align 1
  store ptr %4, ptr %"control value 308", align 1
  %5 = load ptr, ptr %"control value 308", align 1
  store ptr %5, ptr %out, align 1
  %6 = load ptr, ptr %source, align 1
  store ptr %6, ptr %"control value 309", align 1
  %7 = load ptr, ptr %"control value 309", align 1
  store ptr %7, ptr %"control value 310", align 1
  %8 = load ptr, ptr %"control value 310", align 1
  store ptr %8, ptr %input, align 1
  store i64 0, ptr %i, align 1
  br label %loop

loop:                                             ; preds = %if.end, %entry
  %9 = load i64, ptr %i, align 1
  store i64 %9, ptr %"control value 311", align 1
  %10 = load i64, ptr %count, align 1
  store i64 %10, ptr %"control value 312", align 1
  %11 = load i64, ptr %"control value 311", align 1
  %12 = load i64, ptr %"control value 312", align 1
  %13 = icmp ult i64 %11, %12
  %14 = zext i1 %13 to i8
  store i8 %14, ptr %"control value 313", align 1
  %15 = load i8, ptr %"control value 313", align 1
  store i8 %15, ptr %"control value 158", align 1
  %16 = load i8, ptr %"control value 158", align 1
  store i8 %16, ptr %"control value 314", align 1
  %17 = load i8, ptr %"control value 314", align 1
  %18 = icmp ne i8 %17, 0
  br i1 %18, label %if.body, label %if.else

loop.end:                                         ; preds = %if.else
  %19 = load ptr, ptr %destination, align 1
  store ptr %19, ptr %"control value 324", align 1
  %20 = load ptr, ptr %"control value 324", align 1
  ret ptr %20

if.body:                                          ; preds = %loop
  %21 = load ptr, ptr %out, align 1
  store ptr %21, ptr %"control value 315", align 1
  %22 = load i64, ptr %i, align 1
  store i64 %22, ptr %"control value 316", align 1
  %23 = load ptr, ptr %"control value 315", align 1
  %24 = load i64, ptr %"control value 316", align 1
  %25 = mul i64 %24, 1
  %26 = getelementptr i8, ptr %23, i64 %25
  store ptr %26, ptr %"control value 317", align 1
  %27 = load ptr, ptr %input, align 1
  store ptr %27, ptr %"control value 318", align 1
  %28 = load i64, ptr %i, align 1
  store i64 %28, ptr %"control value 319", align 1
  %29 = load ptr, ptr %"control value 318", align 1
  %30 = load i64, ptr %"control value 319", align 1
  %31 = mul i64 %30, 1
  %32 = getelementptr i8, ptr %29, i64 %31
  %33 = load i8, ptr %32, align 1
  store i8 %33, ptr %"control value 320", align 1
  %34 = load ptr, ptr %"control value 317", align 1
  %35 = load i8, ptr %"control value 320", align 1
  store i8 %35, ptr %34, align 1
  store ptr %i, ptr %"control value 321", align 1
  %36 = load ptr, ptr %"control value 321", align 1
  %37 = load i64, ptr %36, align 1
  store i64 %37, ptr %"control value 322", align 1
  %38 = load i64, ptr %"control value 322", align 1
  %39 = add i64 %38, 1
  store i64 %39, ptr %"control value 323", align 1
  %40 = load ptr, ptr %"control value 321", align 1
  %41 = load i64, ptr %"control value 323", align 1
  store i64 %41, ptr %40, align 1
  br label %if.end

if.else:                                          ; preds = %loop
  br label %loop.end

if.end:                                           ; preds = %if.body
  br label %loop
}

define ptr @memmove(ptr %0, ptr %1, i64 %2) {
entry:
  %destination = alloca ptr, align 8
  %source = alloca ptr, align 8
  %count = alloca i64, align 8
  %out = alloca ptr, align 8
  %input = alloca ptr, align 8
  %i = alloca i64, align 8
  %"control value 159" = alloca i8, align 1
  %"control value 325" = alloca ptr, align 8
  %"control value 326" = alloca ptr, align 8
  %"control value 327" = alloca ptr, align 8
  %"control value 328" = alloca ptr, align 8
  %"control value 329" = alloca ptr, align 8
  %"control value 330" = alloca i64, align 8
  %"control value 331" = alloca ptr, align 8
  %"control value 332" = alloca i64, align 8
  %"control value 333" = alloca i8, align 1
  %"control value 334" = alloca ptr, align 8
  %"control value 335" = alloca ptr, align 8
  %"control value 336" = alloca i64, align 8
  %"control value 337" = alloca ptr, align 8
  %"control value 338" = alloca i64, align 8
  %"control value 339" = alloca i64, align 8
  %"control value 340" = alloca i8, align 1
  %"control value 341" = alloca i8, align 1
  %"control value 342" = alloca ptr, align 8
  %"control value 343" = alloca i64, align 8
  %"control value 344" = alloca i64, align 8
  %"control value 345" = alloca ptr, align 8
  %"control value 346" = alloca i64, align 8
  %"control value 347" = alloca ptr, align 8
  %"control value 348" = alloca ptr, align 8
  %"control value 349" = alloca i64, align 8
  %"control value 350" = alloca i8, align 1
  %"control value 351" = alloca ptr, align 8
  store ptr %0, ptr %destination, align 1
  store ptr %1, ptr %source, align 1
  store i64 %2, ptr %count, align 1
  %3 = load ptr, ptr %destination, align 1
  store ptr %3, ptr %"control value 325", align 1
  %4 = load ptr, ptr %"control value 325", align 1
  store ptr %4, ptr %"control value 326", align 1
  %5 = load ptr, ptr %"control value 326", align 1
  store ptr %5, ptr %out, align 1
  %6 = load ptr, ptr %source, align 1
  store ptr %6, ptr %"control value 327", align 1
  %7 = load ptr, ptr %"control value 327", align 1
  store ptr %7, ptr %"control value 328", align 1
  %8 = load ptr, ptr %"control value 328", align 1
  store ptr %8, ptr %input, align 1
  %9 = load ptr, ptr %out, align 1
  store ptr %9, ptr %"control value 329", align 1
  %10 = load ptr, ptr %"control value 329", align 1
  %11 = ptrtoint ptr %10 to i64
  store i64 %11, ptr %"control value 330", align 1
  %12 = load ptr, ptr %input, align 1
  store ptr %12, ptr %"control value 331", align 1
  %13 = load ptr, ptr %"control value 331", align 1
  %14 = ptrtoint ptr %13 to i64
  store i64 %14, ptr %"control value 332", align 1
  %15 = load i64, ptr %"control value 330", align 1
  %16 = load i64, ptr %"control value 332", align 1
  %17 = icmp ult i64 %15, %16
  %18 = zext i1 %17 to i8
  store i8 %18, ptr %"control value 333", align 1
  %19 = load i8, ptr %"control value 333", align 1
  %20 = icmp ne i8 %19, 0
  br i1 %20, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  %21 = load ptr, ptr %destination, align 1
  store ptr %21, ptr %"control value 334", align 1
  %22 = load ptr, ptr %source, align 1
  store ptr %22, ptr %"control value 335", align 1
  %23 = load i64, ptr %count, align 1
  store i64 %23, ptr %"control value 336", align 1
  %24 = load ptr, ptr %"control value 334", align 1
  %25 = load ptr, ptr %"control value 335", align 1
  %26 = load i64, ptr %"control value 336", align 1
  %27 = call ptr @memcpy(ptr %24, ptr %25, i64 %26)
  store ptr %27, ptr %"control value 337", align 1
  %28 = load ptr, ptr %"control value 337", align 1
  ret ptr %28

if.else:                                          ; preds = %entry
  br label %if.end

if.end:                                           ; preds = %if.else
  %29 = load i64, ptr %count, align 1
  store i64 %29, ptr %"control value 338", align 1
  %30 = load i64, ptr %"control value 338", align 1
  store i64 %30, ptr %i, align 1
  br label %loop

loop:                                             ; preds = %if.end3, %if.end
  %31 = load i64, ptr %i, align 1
  store i64 %31, ptr %"control value 339", align 1
  %32 = load i64, ptr %"control value 339", align 1
  %33 = icmp ne i64 %32, 0
  %34 = zext i1 %33 to i8
  store i8 %34, ptr %"control value 340", align 1
  %35 = load i8, ptr %"control value 340", align 1
  store i8 %35, ptr %"control value 159", align 1
  %36 = load i8, ptr %"control value 159", align 1
  store i8 %36, ptr %"control value 341", align 1
  %37 = load i8, ptr %"control value 341", align 1
  %38 = icmp ne i8 %37, 0
  br i1 %38, label %if.body1, label %if.else2

loop.end:                                         ; preds = %if.else2
  %39 = load ptr, ptr %destination, align 1
  store ptr %39, ptr %"control value 351", align 1
  %40 = load ptr, ptr %"control value 351", align 1
  ret ptr %40

if.body1:                                         ; preds = %loop
  store ptr %i, ptr %"control value 342", align 1
  %41 = load ptr, ptr %"control value 342", align 1
  %42 = load i64, ptr %41, align 1
  store i64 %42, ptr %"control value 343", align 1
  %43 = load i64, ptr %"control value 343", align 1
  %44 = sub i64 %43, 1
  store i64 %44, ptr %"control value 344", align 1
  %45 = load ptr, ptr %"control value 342", align 1
  %46 = load i64, ptr %"control value 344", align 1
  store i64 %46, ptr %45, align 1
  %47 = load ptr, ptr %out, align 1
  store ptr %47, ptr %"control value 345", align 1
  %48 = load i64, ptr %i, align 1
  store i64 %48, ptr %"control value 346", align 1
  %49 = load ptr, ptr %"control value 345", align 1
  %50 = load i64, ptr %"control value 346", align 1
  %51 = mul i64 %50, 1
  %52 = getelementptr i8, ptr %49, i64 %51
  store ptr %52, ptr %"control value 347", align 1
  %53 = load ptr, ptr %input, align 1
  store ptr %53, ptr %"control value 348", align 1
  %54 = load i64, ptr %i, align 1
  store i64 %54, ptr %"control value 349", align 1
  %55 = load ptr, ptr %"control value 348", align 1
  %56 = load i64, ptr %"control value 349", align 1
  %57 = mul i64 %56, 1
  %58 = getelementptr i8, ptr %55, i64 %57
  %59 = load i8, ptr %58, align 1
  store i8 %59, ptr %"control value 350", align 1
  %60 = load ptr, ptr %"control value 347", align 1
  %61 = load i8, ptr %"control value 350", align 1
  store i8 %61, ptr %60, align 1
  br label %if.end3

if.else2:                                         ; preds = %loop
  br label %loop.end

if.end3:                                          ; preds = %if.body1
  br label %loop
}

define ptr @memset(ptr %0, i32 %1, i64 %2) {
entry:
  %destination = alloca ptr, align 8
  %value = alloca i32, align 4
  %count = alloca i64, align 8
  %out = alloca ptr, align 8
  %low = alloca i32, align 4
  %byte = alloca i8, align 1
  %i = alloca i64, align 8
  %"control value 160" = alloca i8, align 1
  %"control value 352" = alloca ptr, align 8
  %"control value 353" = alloca ptr, align 8
  %"control value 354" = alloca i32, align 4
  %"control value 355" = alloca i32, align 4
  %"control value 356" = alloca i32, align 4
  %"control value 357" = alloca i32, align 4
  %"control value 358" = alloca i8, align 1
  %"control value 359" = alloca i64, align 8
  %"control value 360" = alloca i64, align 8
  %"control value 361" = alloca i8, align 1
  %"control value 362" = alloca i8, align 1
  %"control value 363" = alloca ptr, align 8
  %"control value 364" = alloca i64, align 8
  %"control value 365" = alloca ptr, align 8
  %"control value 366" = alloca i8, align 1
  %"control value 367" = alloca ptr, align 8
  %"control value 368" = alloca i64, align 8
  %"control value 369" = alloca i64, align 8
  %"control value 370" = alloca ptr, align 8
  store ptr %0, ptr %destination, align 1
  store i32 %1, ptr %value, align 1
  store i64 %2, ptr %count, align 1
  %3 = load ptr, ptr %destination, align 1
  store ptr %3, ptr %"control value 352", align 1
  %4 = load ptr, ptr %"control value 352", align 1
  store ptr %4, ptr %"control value 353", align 1
  %5 = load ptr, ptr %"control value 353", align 1
  store ptr %5, ptr %out, align 1
  %6 = load i32, ptr %value, align 1
  store i32 %6, ptr %"control value 354", align 1
  %7 = load i32, ptr %"control value 354", align 1
  store i32 %7, ptr %"control value 355", align 1
  %8 = load i32, ptr %"control value 355", align 1
  %9 = and i32 %8, 255
  store i32 %9, ptr %"control value 356", align 1
  %10 = load i32, ptr %"control value 356", align 1
  store i32 %10, ptr %low, align 1
  %11 = load i32, ptr %low, align 1
  store i32 %11, ptr %"control value 357", align 1
  %12 = load i32, ptr %"control value 357", align 1
  %13 = zext i32 %12 to i64
  %14 = icmp ule i64 %13, 255
  %15 = and i1 true, %14
  br i1 %15, label %valid, label %error

valid:                                            ; preds = %entry
  %16 = trunc i32 %12 to i8
  store i8 %16, ptr %"control value 358", align 1
  %17 = load i8, ptr %"control value 358", align 1
  store i8 %17, ptr %byte, align 1
  store i64 0, ptr %i, align 1
  br label %loop

error:                                            ; preds = %entry
  call void @tower_trap(ptr @3, i64 18389)
  unreachable

loop:                                             ; preds = %if.end, %valid
  %18 = load i64, ptr %i, align 1
  store i64 %18, ptr %"control value 359", align 1
  %19 = load i64, ptr %count, align 1
  store i64 %19, ptr %"control value 360", align 1
  %20 = load i64, ptr %"control value 359", align 1
  %21 = load i64, ptr %"control value 360", align 1
  %22 = icmp ult i64 %20, %21
  %23 = zext i1 %22 to i8
  store i8 %23, ptr %"control value 361", align 1
  %24 = load i8, ptr %"control value 361", align 1
  store i8 %24, ptr %"control value 160", align 1
  %25 = load i8, ptr %"control value 160", align 1
  store i8 %25, ptr %"control value 362", align 1
  %26 = load i8, ptr %"control value 362", align 1
  %27 = icmp ne i8 %26, 0
  br i1 %27, label %if.body, label %if.else

loop.end:                                         ; preds = %if.else
  %28 = load ptr, ptr %destination, align 1
  store ptr %28, ptr %"control value 370", align 1
  %29 = load ptr, ptr %"control value 370", align 1
  ret ptr %29

if.body:                                          ; preds = %loop
  %30 = load ptr, ptr %out, align 1
  store ptr %30, ptr %"control value 363", align 1
  %31 = load i64, ptr %i, align 1
  store i64 %31, ptr %"control value 364", align 1
  %32 = load ptr, ptr %"control value 363", align 1
  %33 = load i64, ptr %"control value 364", align 1
  %34 = mul i64 %33, 1
  %35 = getelementptr i8, ptr %32, i64 %34
  store ptr %35, ptr %"control value 365", align 1
  %36 = load i8, ptr %byte, align 1
  store i8 %36, ptr %"control value 366", align 1
  %37 = load ptr, ptr %"control value 365", align 1
  %38 = load i8, ptr %"control value 366", align 1
  store i8 %38, ptr %37, align 1
  store ptr %i, ptr %"control value 367", align 1
  %39 = load ptr, ptr %"control value 367", align 1
  %40 = load i64, ptr %39, align 1
  store i64 %40, ptr %"control value 368", align 1
  %41 = load i64, ptr %"control value 368", align 1
  %42 = add i64 %41, 1
  store i64 %42, ptr %"control value 369", align 1
  %43 = load ptr, ptr %"control value 367", align 1
  %44 = load i64, ptr %"control value 369", align 1
  store i64 %44, ptr %43, align 1
  br label %if.end

if.else:                                          ; preds = %loop
  br label %loop.end

if.end:                                           ; preds = %if.body
  br label %loop
}

define i64 @runtime_format_value(ptr %0, i64 %1, i32 %2, i64 %3, i32 %4) {
entry:
  %output = alloca ptr, align 8
  %capacity = alloca i64, align 8
  %kind = alloca i32, align 4
  %value = alloca i64, align 8
  %pointer_bytes = alloca i32, align 4
  %buffer = alloca [80 x i8], align 1
  %length = alloca i64, align 8
  %valid = alloca i8, align 1
  %digits = alloca i64, align 8
  %at = alloca i64, align 8
  %hex = alloca ptr, align 8
  %done = alloca i8, align 1
  %index = alloca i64, align 8
  %narrow = alloca i8, align 1
  %negative = alloca i8, align 1
  %zero = alloca i64, align 8
  %digits1 = alloca [24 x i8], align 1
  %count = alloca i64, align 8
  %digit = alloca i64, align 8
  %done2 = alloca i8, align 1
  %"control value 161" = alloca i8, align 1
  %"control value 371" = alloca i32, align 4
  %"control value 372" = alloca i8, align 1
  %"control value 373" = alloca i64, align 8
  %"control value 374" = alloca i8, align 1
  %"control value 375" = alloca ptr, align 8
  %"control value 376" = alloca ptr, align 8
  %"control value 377" = alloca ptr, align 8
  %"control value 378" = alloca ptr, align 8
  %"control value 379" = alloca i32, align 4
  %"control value 380" = alloca i8, align 1
  %"control value 381" = alloca i32, align 4
  %"control value 382" = alloca i8, align 1
  %"control value 383" = alloca ptr, align 8
  %"control value 384" = alloca i8, align 1
  %"control value 385" = alloca i8, align 1
  %"control value 386" = alloca i8, align 1
  %"control value 387" = alloca i32, align 4
  %"control value 388" = alloca i8, align 1
  %"control value 389" = alloca i8, align 1
  %"control value 390" = alloca i8, align 1
  %"control value 391" = alloca ptr, align 8
  %"control value 392" = alloca ptr, align 8
  %"control value 393" = alloca i32, align 4
  %"control value 394" = alloca i64, align 8
  %"control value 395" = alloca i64, align 8
  %"control value 396" = alloca ptr, align 8
  %"control value 397" = alloca i64, align 8
  %"control value 398" = alloca i64, align 8
  %"control value 399" = alloca i64, align 8
  %"control value 400" = alloca i64, align 8
  %"control value 401" = alloca i8, align 1
  %"control value 402" = alloca i8, align 1
  %"control value 403" = alloca ptr, align 8
  %"control value 404" = alloca i64, align 8
  %"control value 405" = alloca i64, align 8
  %"control value 406" = alloca i64, align 8
  %"control value 407" = alloca i64, align 8
  %"control value 408" = alloca i64, align 8
  %"control value 409" = alloca ptr, align 8
  %"control value 410" = alloca ptr, align 8
  %"control value 411" = alloca i64, align 8
  %"control value 412" = alloca i8, align 1
  %"control value 413" = alloca ptr, align 8
  %"control value 414" = alloca i64, align 8
  %"control value 415" = alloca i64, align 8
  %"control value 416" = alloca i32, align 4
  %"control value 417" = alloca i8, align 1
  %"control value 418" = alloca i8, align 1
  %"control value 419" = alloca ptr, align 8
  %"control value 420" = alloca i64, align 8
  %"control value 421" = alloca i64, align 8
  %"control value 422" = alloca ptr, align 8
  %"control value 423" = alloca i64, align 8
  %"control value 424" = alloca i8, align 1
  %"control value 425" = alloca i32, align 4
  %"control value 426" = alloca i8, align 1
  %"control value 427" = alloca ptr, align 8
  %"control value 428" = alloca i64, align 8
  %"control value 429" = alloca i8, align 1
  %"control value 430" = alloca i8, align 1
  %"control value 431" = alloca ptr, align 8
  %"control value 432" = alloca ptr, align 8
  %"control value 433" = alloca ptr, align 8
  %"control value 434" = alloca i64, align 8
  %"control value 435" = alloca i64, align 8
  %"control value 436" = alloca i64, align 8
  %"control value 437" = alloca i8, align 1
  %"control value 438" = alloca ptr, align 8
  %"control value 439" = alloca i64, align 8
  %"control value 440" = alloca i64, align 8
  %"control value 441" = alloca i64, align 8
  %"control value 442" = alloca i64, align 8
  %"control value 443" = alloca ptr, align 8
  %"control value 444" = alloca i64, align 8
  %"control value 445" = alloca i64, align 8
  %"control value 446" = alloca i64, align 8
  %"control value 447" = alloca ptr, align 8
  %"control value 448" = alloca i64, align 8
  %"control value 449" = alloca i8, align 1
  %"control value 450" = alloca ptr, align 8
  %"control value 451" = alloca i64, align 8
  %"control value 452" = alloca i64, align 8
  %"control value 453" = alloca ptr, align 8
  %"control value 454" = alloca i64, align 8
  %"control value 455" = alloca i64, align 8
  %"control value 456" = alloca i64, align 8
  %"control value 457" = alloca i8, align 1
  %"control value 458" = alloca i8, align 1
  %"control value 459" = alloca i64, align 8
  %"control value 460" = alloca i8, align 1
  %"control value 461" = alloca i8, align 1
  %"control value 462" = alloca ptr, align 8
  %"control value 463" = alloca i64, align 8
  %"control value 464" = alloca i64, align 8
  %"control value 465" = alloca i64, align 8
  %"control value 466" = alloca ptr, align 8
  %"control value 467" = alloca i64, align 8
  %"control value 468" = alloca i8, align 1
  %"control value 469" = alloca ptr, align 8
  %"control value 470" = alloca i64, align 8
  %"control value 471" = alloca i64, align 8
  %"control value 472" = alloca i64, align 8
  %"control value 473" = alloca ptr, align 8
  %"control value 474" = alloca ptr, align 8
  %"control value 475" = alloca i64, align 8
  %"control value 476" = alloca i64, align 8
  %"control value 477" = alloca i64, align 8
  %"control value 478" = alloca i64, align 8
  %"control value 479" = alloca i8, align 1
  %"control value 480" = alloca ptr, align 8
  %"control value 481" = alloca ptr, align 8
  %"control value 482" = alloca i64, align 8
  %"control value 483" = alloca i64, align 8
  store ptr %0, ptr %output, align 1
  store i64 %1, ptr %capacity, align 1
  store i32 %2, ptr %kind, align 1
  store i64 %3, ptr %value, align 1
  store i32 %4, ptr %pointer_bytes, align 1
  store i64 0, ptr %length, align 1
  %5 = load i32, ptr %kind, align 1
  store i32 %5, ptr %"control value 371", align 1
  %6 = load i32, ptr %"control value 371", align 1
  %7 = icmp eq i32 %6, 2
  %8 = zext i1 %7 to i8
  store i8 %8, ptr %"control value 372", align 1
  %9 = load i8, ptr %"control value 372", align 1
  %10 = icmp ne i8 %9, 0
  br i1 %10, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  %11 = load i64, ptr %value, align 1
  store i64 %11, ptr %"control value 373", align 1
  %12 = load i64, ptr %"control value 373", align 1
  %13 = icmp ne i64 %12, 0
  %14 = zext i1 %13 to i8
  store i8 %14, ptr %"control value 374", align 1
  %15 = load i8, ptr %"control value 374", align 1
  %16 = icmp ne i8 %15, 0
  br i1 %16, label %if.body3, label %if.else4

if.else:                                          ; preds = %entry
  %17 = load i32, ptr %kind, align 1
  store i32 %17, ptr %"control value 379", align 1
  %18 = load i32, ptr %"control value 379", align 1
  %19 = icmp eq i32 %18, 3
  %20 = zext i1 %19 to i8
  store i8 %20, ptr %"control value 380", align 1
  %21 = load i8, ptr %"control value 380", align 1
  %22 = icmp ne i8 %21, 0
  br i1 %22, label %if.body6, label %if.else7

if.end:                                           ; preds = %if.end8, %if.end5
  %23 = load i64, ptr %capacity, align 1
  store i64 %23, ptr %"control value 477", align 1
  %24 = load i64, ptr %length, align 1
  store i64 %24, ptr %"control value 478", align 1
  %25 = load i64, ptr %"control value 477", align 1
  %26 = load i64, ptr %"control value 478", align 1
  %27 = icmp uge i64 %25, %26
  %28 = zext i1 %27 to i8
  store i8 %28, ptr %"control value 479", align 1
  %29 = load i8, ptr %"control value 479", align 1
  %30 = icmp ne i8 %29, 0
  br i1 %30, label %if.body51, label %if.else52

if.body3:                                         ; preds = %if.body
  %31 = getelementptr i8, ptr %buffer, i64 0
  store ptr %31, ptr %"control value 375", align 1
  %32 = load ptr, ptr %"control value 375", align 1
  call void @llvm.memmove.p0.p0.i64(ptr align 1 %32, ptr align 1 @tower.string, i64 5, i1 false)
  store ptr %length, ptr %"control value 376", align 1
  %33 = load ptr, ptr %"control value 376", align 1
  store i64 5, ptr %33, align 1
  br label %if.end5

if.else4:                                         ; preds = %if.body
  %34 = getelementptr i8, ptr %buffer, i64 0
  store ptr %34, ptr %"control value 377", align 1
  %35 = load ptr, ptr %"control value 377", align 1
  call void @llvm.memmove.p0.p0.i64(ptr align 1 %35, ptr align 1 @tower.string.1, i64 6, i1 false)
  store ptr %length, ptr %"control value 378", align 1
  %36 = load ptr, ptr %"control value 378", align 1
  store i64 6, ptr %36, align 1
  br label %if.end5

if.end5:                                          ; preds = %if.else4, %if.body3
  br label %if.end

if.body6:                                         ; preds = %if.else
  %37 = load i32, ptr %pointer_bytes, align 1
  store i32 %37, ptr %"control value 381", align 1
  %38 = load i32, ptr %"control value 381", align 1
  %39 = icmp eq i32 %38, 4
  %40 = zext i1 %39 to i8
  store i8 %40, ptr %"control value 382", align 1
  %41 = load i8, ptr %"control value 382", align 1
  store i8 %41, ptr %valid, align 1
  store ptr %valid, ptr %"control value 383", align 1
  %42 = load ptr, ptr %"control value 383", align 1
  %43 = load i8, ptr %42, align 1
  store i8 %43, ptr %"control value 384", align 1
  %44 = load i8, ptr %"control value 384", align 1
  store i8 %44, ptr %"control value 385", align 1
  %45 = load i8, ptr %"control value 385", align 1
  store i8 %45, ptr %"control value 386", align 1
  %46 = load i8, ptr %"control value 385", align 1
  %47 = icmp ne i8 %46, 0
  br i1 %47, label %if.body9, label %if.else10

if.else7:                                         ; preds = %if.else
  %48 = load i32, ptr %kind, align 1
  store i32 %48, ptr %"control value 416", align 1
  %49 = load i32, ptr %"control value 416", align 1
  %50 = icmp eq i32 %49, 0
  %51 = zext i1 %50 to i8
  store i8 %51, ptr %"control value 417", align 1
  %52 = load i8, ptr %"control value 417", align 1
  store i8 %52, ptr %narrow, align 1
  store i8 0, ptr %negative, align 1
  %53 = load i8, ptr %narrow, align 1
  store i8 %53, ptr %"control value 418", align 1
  %54 = load i8, ptr %"control value 418", align 1
  %55 = icmp ne i8 %54, 0
  br i1 %55, label %if.body23, label %if.else24

if.end8:                                          ; preds = %loop.end47, %loop.end
  %56 = load i64, ptr %length, align 1
  store i64 %56, ptr %"control value 472", align 1
  %57 = load i64, ptr %"control value 472", align 1
  %58 = mul i64 %57, 1
  %59 = getelementptr i8, ptr %buffer, i64 %58
  store ptr %59, ptr %"control value 473", align 1
  %60 = load ptr, ptr %"control value 473", align 1
  store i8 10, ptr %60, align 1
  store ptr %length, ptr %"control value 474", align 1
  %61 = load ptr, ptr %"control value 474", align 1
  %62 = load i64, ptr %61, align 1
  store i64 %62, ptr %"control value 475", align 1
  %63 = load i64, ptr %"control value 475", align 1
  %64 = add i64 %63, 1
  store i64 %64, ptr %"control value 476", align 1
  %65 = load ptr, ptr %"control value 474", align 1
  %66 = load i64, ptr %"control value 476", align 1
  store i64 %66, ptr %65, align 1
  br label %if.end

if.body9:                                         ; preds = %if.body6
  br label %if.end11

if.else10:                                        ; preds = %if.body6
  %67 = load i32, ptr %pointer_bytes, align 1
  store i32 %67, ptr %"control value 387", align 1
  %68 = load i32, ptr %"control value 387", align 1
  %69 = icmp eq i32 %68, 8
  %70 = zext i1 %69 to i8
  store i8 %70, ptr %"control value 388", align 1
  %71 = load i8, ptr %"control value 388", align 1
  store i8 %71, ptr %"control value 386", align 1
  %72 = load ptr, ptr %"control value 383", align 1
  %73 = load i8, ptr %"control value 388", align 1
  store i8 %73, ptr %72, align 1
  br label %if.end11

if.end11:                                         ; preds = %if.else10, %if.body9
  %74 = load i8, ptr %valid, align 1
  store i8 %74, ptr %"control value 389", align 1
  %75 = load i8, ptr %"control value 389", align 1
  %76 = icmp eq i8 0, %75
  %77 = zext i1 %76 to i8
  store i8 %77, ptr %"control value 390", align 1
  %78 = load i8, ptr %"control value 390", align 1
  %79 = icmp ne i8 %78, 0
  br i1 %79, label %if.body12, label %if.else13

if.body12:                                        ; preds = %if.end11
  ret i64 0

if.else13:                                        ; preds = %if.end11
  br label %if.end14

if.end14:                                         ; preds = %if.else13
  %80 = getelementptr i8, ptr %buffer, i64 0
  store ptr %80, ptr %"control value 391", align 1
  %81 = load ptr, ptr %"control value 391", align 1
  store i8 48, ptr %81, align 1
  %82 = getelementptr i8, ptr %buffer, i64 1
  store ptr %82, ptr %"control value 392", align 1
  %83 = load ptr, ptr %"control value 392", align 1
  store i8 120, ptr %83, align 1
  %84 = load i32, ptr %pointer_bytes, align 1
  store i32 %84, ptr %"control value 393", align 1
  %85 = load i32, ptr %"control value 393", align 1
  %86 = zext i32 %85 to i64
  %87 = icmp ule i64 %86, -1
  %88 = and i1 true, %87
  br i1 %88, label %valid15, label %error

valid15:                                          ; preds = %if.end14
  %89 = zext i32 %85 to i64
  store i64 %89, ptr %"control value 394", align 1
  %90 = load i64, ptr %"control value 394", align 1
  %91 = mul i64 %90, 2
  store i64 %91, ptr %"control value 395", align 1
  %92 = load i64, ptr %"control value 395", align 1
  store i64 %92, ptr %digits, align 1
  store ptr %length, ptr %"control value 396", align 1
  %93 = load i64, ptr %digits, align 1
  store i64 %93, ptr %"control value 397", align 1
  %94 = load i64, ptr %"control value 397", align 1
  %95 = add i64 %94, 2
  store i64 %95, ptr %"control value 398", align 1
  %96 = load ptr, ptr %"control value 396", align 1
  %97 = load i64, ptr %"control value 398", align 1
  store i64 %97, ptr %96, align 1
  %98 = load i64, ptr %length, align 1
  store i64 %98, ptr %"control value 399", align 1
  %99 = load i64, ptr %"control value 399", align 1
  store i64 %99, ptr %at, align 1
  store ptr @tower.string.2, ptr %hex, align 1
  br label %loop

error:                                            ; preds = %if.end14
  call void @tower_trap(ptr @4, i64 19528)
  unreachable

loop:                                             ; preds = %valid21, %valid15
  %100 = load i64, ptr %at, align 1
  store i64 %100, ptr %"control value 400", align 1
  %101 = load i64, ptr %"control value 400", align 1
  %102 = icmp eq i64 %101, 2
  %103 = zext i1 %102 to i8
  store i8 %103, ptr %"control value 401", align 1
  %104 = load i8, ptr %"control value 401", align 1
  store i8 %104, ptr %done, align 1
  %105 = load i8, ptr %done, align 1
  store i8 %105, ptr %"control value 402", align 1
  %106 = load i8, ptr %"control value 402", align 1
  %107 = icmp ne i8 %106, 0
  br i1 %107, label %if.body16, label %if.else17

loop.end:                                         ; preds = %if.body16
  br label %if.end8

if.body16:                                        ; preds = %loop
  br label %loop.end

if.else17:                                        ; preds = %loop
  br label %if.end18

if.end18:                                         ; preds = %if.else17
  store ptr %at, ptr %"control value 403", align 1
  %108 = load ptr, ptr %"control value 403", align 1
  %109 = load i64, ptr %108, align 1
  store i64 %109, ptr %"control value 404", align 1
  %110 = load i64, ptr %"control value 404", align 1
  %111 = sub i64 %110, 1
  store i64 %111, ptr %"control value 405", align 1
  %112 = load ptr, ptr %"control value 403", align 1
  %113 = load i64, ptr %"control value 405", align 1
  store i64 %113, ptr %112, align 1
  %114 = load i64, ptr %value, align 1
  store i64 %114, ptr %"control value 406", align 1
  %115 = load i64, ptr %"control value 406", align 1
  br i1 true, label %valid19, label %error20

valid19:                                          ; preds = %if.end18
  %116 = urem i64 %115, 16
  store i64 %116, ptr %"control value 407", align 1
  %117 = load i64, ptr %"control value 407", align 1
  store i64 %117, ptr %index, align 1
  %118 = load i64, ptr %at, align 1
  store i64 %118, ptr %"control value 408", align 1
  %119 = load i64, ptr %"control value 408", align 1
  %120 = mul i64 %119, 1
  %121 = getelementptr i8, ptr %buffer, i64 %120
  store ptr %121, ptr %"control value 409", align 1
  %122 = load ptr, ptr %hex, align 1
  store ptr %122, ptr %"control value 410", align 1
  %123 = load i64, ptr %index, align 1
  store i64 %123, ptr %"control value 411", align 1
  %124 = load ptr, ptr %"control value 410", align 1
  %125 = load i64, ptr %"control value 411", align 1
  %126 = mul i64 %125, 1
  %127 = getelementptr i8, ptr %124, i64 %126
  %128 = load i8, ptr %127, align 1
  store i8 %128, ptr %"control value 412", align 1
  %129 = load ptr, ptr %"control value 409", align 1
  %130 = load i8, ptr %"control value 412", align 1
  store i8 %130, ptr %129, align 1
  store ptr %value, ptr %"control value 413", align 1
  %131 = load i64, ptr %value, align 1
  store i64 %131, ptr %"control value 414", align 1
  %132 = load i64, ptr %"control value 414", align 1
  br i1 true, label %valid21, label %error22

error20:                                          ; preds = %if.end18
  call void @tower_trap(ptr @5, i64 19528)
  unreachable

valid21:                                          ; preds = %valid19
  %133 = udiv i64 %132, 16
  store i64 %133, ptr %"control value 415", align 1
  %134 = load ptr, ptr %"control value 413", align 1
  %135 = load i64, ptr %"control value 415", align 1
  store i64 %135, ptr %134, align 1
  br label %loop

error22:                                          ; preds = %valid19
  call void @tower_trap(ptr @6, i64 19528)
  unreachable

if.body23:                                        ; preds = %if.else7
  store ptr %value, ptr %"control value 419", align 1
  %136 = load i64, ptr %value, align 1
  store i64 %136, ptr %"control value 420", align 1
  %137 = load i64, ptr %"control value 420", align 1
  %138 = and i64 %137, 4294967295
  store i64 %138, ptr %"control value 421", align 1
  %139 = load ptr, ptr %"control value 419", align 1
  %140 = load i64, ptr %"control value 421", align 1
  store i64 %140, ptr %139, align 1
  store ptr %negative, ptr %"control value 422", align 1
  %141 = load i64, ptr %value, align 1
  store i64 %141, ptr %"control value 423", align 1
  %142 = load i64, ptr %"control value 423", align 1
  %143 = icmp uge i64 %142, 2147483648
  %144 = zext i1 %143 to i8
  store i8 %144, ptr %"control value 424", align 1
  %145 = load ptr, ptr %"control value 422", align 1
  %146 = load i8, ptr %"control value 424", align 1
  store i8 %146, ptr %145, align 1
  br label %if.end25

if.else24:                                        ; preds = %if.else7
  %147 = load i32, ptr %kind, align 1
  store i32 %147, ptr %"control value 425", align 1
  %148 = load i32, ptr %"control value 425", align 1
  %149 = icmp eq i32 %148, 6
  %150 = zext i1 %149 to i8
  store i8 %150, ptr %"control value 426", align 1
  %151 = load i8, ptr %"control value 426", align 1
  %152 = icmp ne i8 %151, 0
  br i1 %152, label %if.body26, label %if.else27

if.end25:                                         ; preds = %if.end28, %if.body23
  %153 = load i8, ptr %negative, align 1
  store i8 %153, ptr %"control value 430", align 1
  %154 = load i8, ptr %"control value 430", align 1
  %155 = icmp ne i8 %154, 0
  br i1 %155, label %if.body29, label %if.else30

if.body26:                                        ; preds = %if.else24
  store ptr %negative, ptr %"control value 427", align 1
  %156 = load i64, ptr %value, align 1
  store i64 %156, ptr %"control value 428", align 1
  %157 = load i64, ptr %"control value 428", align 1
  %158 = icmp uge i64 %157, -9223372036854775808
  %159 = zext i1 %158 to i8
  store i8 %159, ptr %"control value 429", align 1
  %160 = load ptr, ptr %"control value 427", align 1
  %161 = load i8, ptr %"control value 429", align 1
  store i8 %161, ptr %160, align 1
  br label %if.end28

if.else27:                                        ; preds = %if.else24
  br label %if.end28

if.end28:                                         ; preds = %if.else27, %if.body26
  br label %if.end25

if.body29:                                        ; preds = %if.end25
  %162 = getelementptr i8, ptr %buffer, i64 0
  store ptr %162, ptr %"control value 431", align 1
  %163 = load ptr, ptr %"control value 431", align 1
  store i8 45, ptr %163, align 1
  store ptr %length, ptr %"control value 432", align 1
  %164 = load ptr, ptr %"control value 432", align 1
  store i64 1, ptr %164, align 1
  store i64 0, ptr %zero, align 1
  store ptr %value, ptr %"control value 433", align 1
  %165 = load i64, ptr %zero, align 1
  store i64 %165, ptr %"control value 434", align 1
  %166 = load i64, ptr %value, align 1
  store i64 %166, ptr %"control value 435", align 1
  %167 = load i64, ptr %"control value 434", align 1
  %168 = load i64, ptr %"control value 435", align 1
  %169 = sub i64 %167, %168
  store i64 %169, ptr %"control value 436", align 1
  %170 = load ptr, ptr %"control value 433", align 1
  %171 = load i64, ptr %"control value 436", align 1
  store i64 %171, ptr %170, align 1
  %172 = load i8, ptr %narrow, align 1
  store i8 %172, ptr %"control value 437", align 1
  %173 = load i8, ptr %"control value 437", align 1
  %174 = icmp ne i8 %173, 0
  br i1 %174, label %if.body32, label %if.else33

if.else30:                                        ; preds = %if.end25
  br label %if.end31

if.end31:                                         ; preds = %if.end34, %if.else30
  store i64 0, ptr %count, align 1
  br label %loop35

if.body32:                                        ; preds = %if.body29
  store ptr %value, ptr %"control value 438", align 1
  %175 = load i64, ptr %value, align 1
  store i64 %175, ptr %"control value 439", align 1
  %176 = load i64, ptr %"control value 439", align 1
  %177 = and i64 %176, 4294967295
  store i64 %177, ptr %"control value 440", align 1
  %178 = load ptr, ptr %"control value 438", align 1
  %179 = load i64, ptr %"control value 440", align 1
  store i64 %179, ptr %178, align 1
  br label %if.end34

if.else33:                                        ; preds = %if.body29
  br label %if.end34

if.end34:                                         ; preds = %if.else33, %if.body32
  br label %if.end31

loop35:                                           ; preds = %if.end45, %if.end31
  %180 = load i64, ptr %value, align 1
  store i64 %180, ptr %"control value 441", align 1
  %181 = load i64, ptr %"control value 441", align 1
  br i1 true, label %valid37, label %error38

loop.end36:                                       ; preds = %if.body43
  br label %loop46

valid37:                                          ; preds = %loop35
  %182 = urem i64 %181, 10
  store i64 %182, ptr %"control value 442", align 1
  %183 = load i64, ptr %"control value 442", align 1
  store i64 %183, ptr %digit, align 1
  store ptr %digit, ptr %"control value 443", align 1
  %184 = load i64, ptr %digit, align 1
  store i64 %184, ptr %"control value 444", align 1
  %185 = load i64, ptr %"control value 444", align 1
  %186 = add i64 %185, 48
  store i64 %186, ptr %"control value 445", align 1
  %187 = load ptr, ptr %"control value 443", align 1
  %188 = load i64, ptr %"control value 445", align 1
  store i64 %188, ptr %187, align 1
  %189 = load i64, ptr %count, align 1
  store i64 %189, ptr %"control value 446", align 1
  %190 = load i64, ptr %"control value 446", align 1
  %191 = mul i64 %190, 1
  %192 = getelementptr i8, ptr %digits1, i64 %191
  store ptr %192, ptr %"control value 447", align 1
  %193 = load i64, ptr %digit, align 1
  store i64 %193, ptr %"control value 448", align 1
  %194 = load i64, ptr %"control value 448", align 1
  %195 = icmp ule i64 %194, 255
  %196 = and i1 true, %195
  br i1 %196, label %valid39, label %error40

error38:                                          ; preds = %loop35
  call void @tower_trap(ptr @7, i64 19528)
  unreachable

valid39:                                          ; preds = %valid37
  %197 = trunc i64 %194 to i8
  store i8 %197, ptr %"control value 449", align 1
  %198 = load ptr, ptr %"control value 447", align 1
  %199 = load i8, ptr %"control value 449", align 1
  store i8 %199, ptr %198, align 1
  store ptr %count, ptr %"control value 450", align 1
  %200 = load ptr, ptr %"control value 450", align 1
  %201 = load i64, ptr %200, align 1
  store i64 %201, ptr %"control value 451", align 1
  %202 = load i64, ptr %"control value 451", align 1
  %203 = add i64 %202, 1
  store i64 %203, ptr %"control value 452", align 1
  %204 = load ptr, ptr %"control value 450", align 1
  %205 = load i64, ptr %"control value 452", align 1
  store i64 %205, ptr %204, align 1
  store ptr %value, ptr %"control value 453", align 1
  %206 = load i64, ptr %value, align 1
  store i64 %206, ptr %"control value 454", align 1
  %207 = load i64, ptr %"control value 454", align 1
  br i1 true, label %valid41, label %error42

error40:                                          ; preds = %valid37
  call void @tower_trap(ptr @8, i64 19528)
  unreachable

valid41:                                          ; preds = %valid39
  %208 = udiv i64 %207, 10
  store i64 %208, ptr %"control value 455", align 1
  %209 = load ptr, ptr %"control value 453", align 1
  %210 = load i64, ptr %"control value 455", align 1
  store i64 %210, ptr %209, align 1
  %211 = load i64, ptr %value, align 1
  store i64 %211, ptr %"control value 456", align 1
  %212 = load i64, ptr %"control value 456", align 1
  %213 = icmp eq i64 %212, 0
  %214 = zext i1 %213 to i8
  store i8 %214, ptr %"control value 457", align 1
  %215 = load i8, ptr %"control value 457", align 1
  store i8 %215, ptr %done2, align 1
  %216 = load i8, ptr %done2, align 1
  store i8 %216, ptr %"control value 458", align 1
  %217 = load i8, ptr %"control value 458", align 1
  %218 = icmp ne i8 %217, 0
  br i1 %218, label %if.body43, label %if.else44

error42:                                          ; preds = %valid39
  call void @tower_trap(ptr @9, i64 19528)
  unreachable

if.body43:                                        ; preds = %valid41
  br label %loop.end36

if.else44:                                        ; preds = %valid41
  br label %if.end45

if.end45:                                         ; preds = %if.else44
  br label %loop35

loop46:                                           ; preds = %if.end50, %loop.end36
  %219 = load i64, ptr %count, align 1
  store i64 %219, ptr %"control value 459", align 1
  %220 = load i64, ptr %"control value 459", align 1
  %221 = icmp ne i64 %220, 0
  %222 = zext i1 %221 to i8
  store i8 %222, ptr %"control value 460", align 1
  %223 = load i8, ptr %"control value 460", align 1
  store i8 %223, ptr %"control value 161", align 1
  %224 = load i8, ptr %"control value 161", align 1
  store i8 %224, ptr %"control value 461", align 1
  %225 = load i8, ptr %"control value 461", align 1
  %226 = icmp ne i8 %225, 0
  br i1 %226, label %if.body48, label %if.else49

loop.end47:                                       ; preds = %if.else49
  br label %if.end8

if.body48:                                        ; preds = %loop46
  store ptr %count, ptr %"control value 462", align 1
  %227 = load ptr, ptr %"control value 462", align 1
  %228 = load i64, ptr %227, align 1
  store i64 %228, ptr %"control value 463", align 1
  %229 = load i64, ptr %"control value 463", align 1
  %230 = sub i64 %229, 1
  store i64 %230, ptr %"control value 464", align 1
  %231 = load ptr, ptr %"control value 462", align 1
  %232 = load i64, ptr %"control value 464", align 1
  store i64 %232, ptr %231, align 1
  %233 = load i64, ptr %length, align 1
  store i64 %233, ptr %"control value 465", align 1
  %234 = load i64, ptr %"control value 465", align 1
  %235 = mul i64 %234, 1
  %236 = getelementptr i8, ptr %buffer, i64 %235
  store ptr %236, ptr %"control value 466", align 1
  %237 = load i64, ptr %count, align 1
  store i64 %237, ptr %"control value 467", align 1
  %238 = load i64, ptr %"control value 467", align 1
  %239 = mul i64 %238, 1
  %240 = getelementptr i8, ptr %digits1, i64 %239
  %241 = load i8, ptr %240, align 1
  store i8 %241, ptr %"control value 468", align 1
  %242 = load ptr, ptr %"control value 466", align 1
  %243 = load i8, ptr %"control value 468", align 1
  store i8 %243, ptr %242, align 1
  br label %if.end50

if.else49:                                        ; preds = %loop46
  br label %loop.end47

if.end50:                                         ; preds = %if.body48
  store ptr %length, ptr %"control value 469", align 1
  %244 = load ptr, ptr %"control value 469", align 1
  %245 = load i64, ptr %244, align 1
  store i64 %245, ptr %"control value 470", align 1
  %246 = load i64, ptr %"control value 470", align 1
  %247 = add i64 %246, 1
  store i64 %247, ptr %"control value 471", align 1
  %248 = load ptr, ptr %"control value 469", align 1
  %249 = load i64, ptr %"control value 471", align 1
  store i64 %249, ptr %248, align 1
  br label %loop46

if.body51:                                        ; preds = %if.end
  %250 = load ptr, ptr %output, align 1
  store ptr %250, ptr %"control value 480", align 1
  %251 = getelementptr i8, ptr %buffer, i64 0
  store ptr %251, ptr %"control value 481", align 1
  %252 = load i64, ptr %length, align 1
  store i64 %252, ptr %"control value 482", align 1
  %253 = load ptr, ptr %"control value 480", align 1
  %254 = load ptr, ptr %"control value 481", align 1
  %255 = load i64, ptr %"control value 482", align 1
  call void @llvm.memmove.p0.p0.i64(ptr align 1 %253, ptr align 1 %254, i64 %255, i1 false)
  %256 = load i64, ptr %length, align 1
  store i64 %256, ptr %"control value 483", align 1
  %257 = load i64, ptr %"control value 483", align 1
  ret i64 %257

if.else52:                                        ; preds = %if.end
  br label %if.end53

if.end53:                                         ; preds = %if.else52
  ret i64 0
}

define zeroext i8 @runtime_write_all(i32 %0, ptr %1, i64 %2) {
entry:
  %stream = alloca i32, align 4
  %data = alloca ptr, align 8
  %length = alloca i64, align 8
  %valid = alloca i8, align 1
  %at = alloca i64, align 8
  %remaining = alloca i64, align 8
  %written = alloca i64, align 8
  %count = alloca i64, align 8
  %"control value 484" = alloca i32, align 4
  %"control value 485" = alloca i8, align 1
  %"control value 486" = alloca ptr, align 8
  %"control value 487" = alloca i8, align 1
  %"control value 488" = alloca i8, align 1
  %"control value 489" = alloca i8, align 1
  %"control value 490" = alloca i32, align 4
  %"control value 491" = alloca i8, align 1
  %"control value 492" = alloca i8, align 1
  %"control value 493" = alloca i8, align 1
  %"control value 494" = alloca i64, align 8
  %"control value 495" = alloca i64, align 8
  %"control value 496" = alloca i8, align 1
  %"control value 497" = alloca i64, align 8
  %"control value 498" = alloca i64, align 8
  %"control value 499" = alloca i64, align 8
  %"control value 500" = alloca i32, align 4
  %"control value 501" = alloca ptr, align 8
  %"control value 502" = alloca i64, align 8
  %"control value 503" = alloca ptr, align 8
  %"control value 504" = alloca i64, align 8
  %"control value 505" = alloca i64, align 8
  %"control value 506" = alloca i64, align 8
  %"control value 507" = alloca i8, align 1
  %"control value 508" = alloca i64, align 8
  %"control value 509" = alloca i64, align 8
  %"control value 510" = alloca i64, align 8
  %"control value 511" = alloca i64, align 8
  %"control value 512" = alloca i64, align 8
  %"control value 513" = alloca i8, align 1
  %"control value 514" = alloca ptr, align 8
  %"control value 515" = alloca i64, align 8
  %"control value 516" = alloca i64, align 8
  %"control value 517" = alloca i64, align 8
  %"control value 518" = alloca i64, align 8
  store i32 %0, ptr %stream, align 1
  store ptr %1, ptr %data, align 1
  store i64 %2, ptr %length, align 1
  %3 = load i32, ptr %stream, align 1
  store i32 %3, ptr %"control value 484", align 1
  %4 = load i32, ptr %"control value 484", align 1
  %5 = icmp eq i32 %4, 1
  %6 = zext i1 %5 to i8
  store i8 %6, ptr %"control value 485", align 1
  %7 = load i8, ptr %"control value 485", align 1
  store i8 %7, ptr %valid, align 1
  store ptr %valid, ptr %"control value 486", align 1
  %8 = load ptr, ptr %"control value 486", align 1
  %9 = load i8, ptr %8, align 1
  store i8 %9, ptr %"control value 487", align 1
  %10 = load i8, ptr %"control value 487", align 1
  store i8 %10, ptr %"control value 488", align 1
  %11 = load i8, ptr %"control value 488", align 1
  store i8 %11, ptr %"control value 489", align 1
  %12 = load i8, ptr %"control value 488", align 1
  %13 = icmp ne i8 %12, 0
  br i1 %13, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  br label %if.end

if.else:                                          ; preds = %entry
  %14 = load i32, ptr %stream, align 1
  store i32 %14, ptr %"control value 490", align 1
  %15 = load i32, ptr %"control value 490", align 1
  %16 = icmp eq i32 %15, 2
  %17 = zext i1 %16 to i8
  store i8 %17, ptr %"control value 491", align 1
  %18 = load i8, ptr %"control value 491", align 1
  store i8 %18, ptr %"control value 489", align 1
  %19 = load ptr, ptr %"control value 486", align 1
  %20 = load i8, ptr %"control value 491", align 1
  store i8 %20, ptr %19, align 1
  br label %if.end

if.end:                                           ; preds = %if.else, %if.body
  %21 = load i8, ptr %valid, align 1
  store i8 %21, ptr %"control value 492", align 1
  %22 = load i8, ptr %"control value 492", align 1
  %23 = icmp eq i8 0, %22
  %24 = zext i1 %23 to i8
  store i8 %24, ptr %"control value 493", align 1
  %25 = load i8, ptr %"control value 493", align 1
  %26 = icmp ne i8 %25, 0
  br i1 %26, label %if.body1, label %if.else2

if.body1:                                         ; preds = %if.end
  ret i8 0

if.else2:                                         ; preds = %if.end
  br label %if.end3

if.end3:                                          ; preds = %if.else2
  store i64 0, ptr %at, align 1
  br label %loop

loop:                                             ; preds = %valid16, %if.end3
  %27 = load i64, ptr %at, align 1
  store i64 %27, ptr %"control value 494", align 1
  %28 = load i64, ptr %length, align 1
  store i64 %28, ptr %"control value 495", align 1
  %29 = load i64, ptr %"control value 494", align 1
  %30 = load i64, ptr %"control value 495", align 1
  %31 = icmp eq i64 %29, %30
  %32 = zext i1 %31 to i8
  store i8 %32, ptr %"control value 496", align 1
  %33 = load i8, ptr %"control value 496", align 1
  %34 = icmp ne i8 %33, 0
  br i1 %34, label %if.body4, label %if.else5

loop.end:                                         ; No predecessors!
  unreachable

if.body4:                                         ; preds = %loop
  ret i8 1

if.else5:                                         ; preds = %loop
  br label %if.end6

if.end6:                                          ; preds = %if.else5
  %35 = load i64, ptr %length, align 1
  store i64 %35, ptr %"control value 497", align 1
  %36 = load i64, ptr %at, align 1
  store i64 %36, ptr %"control value 498", align 1
  %37 = load i64, ptr %"control value 497", align 1
  %38 = load i64, ptr %"control value 498", align 1
  %39 = sub i64 %37, %38
  store i64 %39, ptr %"control value 499", align 1
  %40 = load i64, ptr %"control value 499", align 1
  store i64 %40, ptr %remaining, align 1
  %41 = load i32, ptr %stream, align 1
  store i32 %41, ptr %"control value 500", align 1
  %42 = load ptr, ptr %data, align 1
  store ptr %42, ptr %"control value 501", align 1
  %43 = load i64, ptr %at, align 1
  store i64 %43, ptr %"control value 502", align 1
  %44 = load ptr, ptr %"control value 501", align 1
  %45 = load i64, ptr %"control value 502", align 1
  %46 = mul i64 %45, 1
  %47 = getelementptr i8, ptr %44, i64 %46
  store ptr %47, ptr %"control value 503", align 1
  %48 = load i64, ptr %remaining, align 1
  store i64 %48, ptr %"control value 504", align 1
  %49 = load i32, ptr %"control value 500", align 1
  %50 = load ptr, ptr %"control value 503", align 1
  %51 = load i64, ptr %"control value 504", align 1
  %52 = call i64 @platform_write(i32 %49, ptr %50, i64 %51)
  store i64 %52, ptr %"control value 505", align 1
  %53 = load i64, ptr %"control value 505", align 1
  store i64 %53, ptr %written, align 1
  %54 = load i64, ptr %written, align 1
  store i64 %54, ptr %"control value 506", align 1
  %55 = load i64, ptr %"control value 506", align 1
  %56 = icmp sle i64 %55, 0
  %57 = zext i1 %56 to i8
  store i8 %57, ptr %"control value 507", align 1
  %58 = load i8, ptr %"control value 507", align 1
  %59 = icmp ne i8 %58, 0
  br i1 %59, label %if.body7, label %if.else8

if.body7:                                         ; preds = %if.end6
  ret i8 0

if.else8:                                         ; preds = %if.end6
  br label %if.end9

if.end9:                                          ; preds = %if.else8
  %60 = load i64, ptr %written, align 1
  store i64 %60, ptr %"control value 508", align 1
  %61 = load i64, ptr %"control value 508", align 1
  %62 = icmp sge i64 %61, 0
  %63 = icmp ule i64 %61, -1
  %64 = and i1 %62, %63
  br i1 %64, label %valid10, label %error

valid10:                                          ; preds = %if.end9
  store i64 %61, ptr %"control value 509", align 1
  %65 = load i64, ptr %"control value 509", align 1
  store i64 %65, ptr %count, align 1
  %66 = load i64, ptr %count, align 1
  store i64 %66, ptr %"control value 510", align 1
  %67 = load i64, ptr %remaining, align 1
  store i64 %67, ptr %"control value 511", align 1
  %68 = load i64, ptr %"control value 511", align 1
  %69 = icmp ule i64 %68, -1
  %70 = and i1 true, %69
  br i1 %70, label %valid11, label %error12

error:                                            ; preds = %if.end9
  call void @tower_trap(ptr @10, i64 19528)
  unreachable

valid11:                                          ; preds = %valid10
  store i64 %68, ptr %"control value 512", align 1
  %71 = load i64, ptr %"control value 510", align 1
  %72 = load i64, ptr %"control value 512", align 1
  %73 = icmp ugt i64 %71, %72
  %74 = zext i1 %73 to i8
  store i8 %74, ptr %"control value 513", align 1
  %75 = load i8, ptr %"control value 513", align 1
  %76 = icmp ne i8 %75, 0
  br i1 %76, label %if.body13, label %if.else14

error12:                                          ; preds = %valid10
  call void @tower_trap(ptr @11, i64 19528)
  unreachable

if.body13:                                        ; preds = %valid11
  ret i8 0

if.else14:                                        ; preds = %valid11
  br label %if.end15

if.end15:                                         ; preds = %if.else14
  store ptr %at, ptr %"control value 514", align 1
  %77 = load i64, ptr %at, align 1
  store i64 %77, ptr %"control value 515", align 1
  %78 = load i64, ptr %count, align 1
  store i64 %78, ptr %"control value 516", align 1
  %79 = load i64, ptr %"control value 516", align 1
  %80 = icmp ule i64 %79, -1
  %81 = and i1 true, %80
  br i1 %81, label %valid16, label %error17

valid16:                                          ; preds = %if.end15
  store i64 %79, ptr %"control value 517", align 1
  %82 = load i64, ptr %"control value 515", align 1
  %83 = load i64, ptr %"control value 517", align 1
  %84 = add i64 %82, %83
  store i64 %84, ptr %"control value 518", align 1
  %85 = load ptr, ptr %"control value 514", align 1
  %86 = load i64, ptr %"control value 518", align 1
  store i64 %86, ptr %85, align 1
  br label %loop

error17:                                          ; preds = %if.end15
  call void @tower_trap(ptr @12, i64 19528)
  unreachable
}

define zeroext i8 @runtime_print_value(i32 %0, i64 %1, i32 %2) {
entry:
  %kind = alloca i32, align 4
  %value = alloca i64, align 8
  %pointer_bytes = alloca i32, align 4
  %buffer = alloca [80 x i8], align 1
  %length = alloca i64, align 8
  %"control value 519" = alloca ptr, align 8
  %"control value 520" = alloca i32, align 4
  %"control value 521" = alloca i64, align 8
  %"control value 522" = alloca i32, align 4
  %"control value 523" = alloca i64, align 8
  %"control value 524" = alloca i64, align 8
  %"control value 525" = alloca i8, align 1
  %"control value 526" = alloca ptr, align 8
  %"control value 527" = alloca i64, align 8
  %"control value 528" = alloca i8, align 1
  store i32 %0, ptr %kind, align 1
  store i64 %1, ptr %value, align 1
  store i32 %2, ptr %pointer_bytes, align 1
  %3 = getelementptr i8, ptr %buffer, i64 0
  store ptr %3, ptr %"control value 519", align 1
  %4 = load i32, ptr %kind, align 1
  store i32 %4, ptr %"control value 520", align 1
  %5 = load i64, ptr %value, align 1
  store i64 %5, ptr %"control value 521", align 1
  %6 = load i32, ptr %pointer_bytes, align 1
  store i32 %6, ptr %"control value 522", align 1
  %7 = load ptr, ptr %"control value 519", align 1
  %8 = load i32, ptr %"control value 520", align 1
  %9 = load i64, ptr %"control value 521", align 1
  %10 = load i32, ptr %"control value 522", align 1
  %11 = call i64 @runtime_format_value(ptr %7, i64 80, i32 %8, i64 %9, i32 %10)
  store i64 %11, ptr %"control value 523", align 1
  %12 = load i64, ptr %"control value 523", align 1
  store i64 %12, ptr %length, align 1
  %13 = load i64, ptr %length, align 1
  store i64 %13, ptr %"control value 524", align 1
  %14 = load i64, ptr %"control value 524", align 1
  %15 = icmp eq i64 %14, 0
  %16 = zext i1 %15 to i8
  store i8 %16, ptr %"control value 525", align 1
  %17 = load i8, ptr %"control value 525", align 1
  %18 = icmp ne i8 %17, 0
  br i1 %18, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  ret i8 0

if.else:                                          ; preds = %entry
  br label %if.end

if.end:                                           ; preds = %if.else
  %19 = getelementptr i8, ptr %buffer, i64 0
  store ptr %19, ptr %"control value 526", align 1
  %20 = load i64, ptr %length, align 1
  store i64 %20, ptr %"control value 527", align 1
  %21 = load ptr, ptr %"control value 526", align 1
  %22 = load i64, ptr %"control value 527", align 1
  %23 = call zeroext i8 @runtime_write_all(i32 1, ptr %21, i64 %22)
  store i8 %23, ptr %"control value 528", align 1
  %24 = load i8, ptr %"control value 528", align 1
  ret i8 %24
}

define void @tower_print(i32 %0, i64 %1, i32 %2) {
entry:
  %kind = alloca i32, align 4
  %value = alloca i64, align 8
  %pointer_bytes = alloca i32, align 4
  %"control value 529" = alloca i32, align 4
  %"control value 530" = alloca i64, align 8
  %"control value 531" = alloca i32, align 4
  %"control value 532" = alloca i8, align 1
  store i32 %0, ptr %kind, align 1
  store i64 %1, ptr %value, align 1
  store i32 %2, ptr %pointer_bytes, align 1
  %3 = load i32, ptr %kind, align 1
  store i32 %3, ptr %"control value 529", align 1
  %4 = load i64, ptr %value, align 1
  store i64 %4, ptr %"control value 530", align 1
  %5 = load i32, ptr %pointer_bytes, align 1
  store i32 %5, ptr %"control value 531", align 1
  %6 = load i32, ptr %"control value 529", align 1
  %7 = load i64, ptr %"control value 530", align 1
  %8 = load i32, ptr %"control value 531", align 1
  %9 = call zeroext i8 @runtime_print_value(i32 %6, i64 %7, i32 %8)
  store i8 %9, ptr %"control value 532", align 1
  ret void
}

define void @tower_trap(ptr %0, i64 %1) {
entry:
  %message = alloca ptr, align 8
  %offset = alloca i64, align 8
  %length = alloca i64, align 8
  %"control value 162" = alloca i8, align 1
  %"control value 533" = alloca ptr, align 8
  %"control value 534" = alloca i64, align 8
  %"control value 535" = alloca i8, align 1
  %"control value 536" = alloca i8, align 1
  %"control value 537" = alloca i8, align 1
  %"control value 538" = alloca ptr, align 8
  %"control value 539" = alloca i64, align 8
  %"control value 540" = alloca i64, align 8
  %"control value 541" = alloca ptr, align 8
  %"control value 542" = alloca i64, align 8
  %"control value 543" = alloca i8, align 1
  %"control value 544" = alloca i8, align 1
  store ptr %0, ptr %message, align 1
  store i64 %1, ptr %offset, align 1
  store i64 0, ptr %length, align 1
  br label %loop

loop:                                             ; preds = %if.end, %entry
  %2 = load ptr, ptr %message, align 1
  store ptr %2, ptr %"control value 533", align 1
  %3 = load i64, ptr %length, align 1
  store i64 %3, ptr %"control value 534", align 1
  %4 = load ptr, ptr %"control value 533", align 1
  %5 = load i64, ptr %"control value 534", align 1
  %6 = mul i64 %5, 1
  %7 = getelementptr i8, ptr %4, i64 %6
  %8 = load i8, ptr %7, align 1
  store i8 %8, ptr %"control value 535", align 1
  %9 = load i8, ptr %"control value 535", align 1
  %10 = icmp ne i8 %9, 0
  %11 = zext i1 %10 to i8
  store i8 %11, ptr %"control value 536", align 1
  %12 = load i8, ptr %"control value 536", align 1
  store i8 %12, ptr %"control value 162", align 1
  %13 = load i8, ptr %"control value 162", align 1
  store i8 %13, ptr %"control value 537", align 1
  %14 = load i8, ptr %"control value 537", align 1
  %15 = icmp ne i8 %14, 0
  br i1 %15, label %if.body, label %if.else

loop.end:                                         ; preds = %if.else
  %16 = load ptr, ptr %message, align 1
  store ptr %16, ptr %"control value 541", align 1
  %17 = load i64, ptr %length, align 1
  store i64 %17, ptr %"control value 542", align 1
  %18 = load ptr, ptr %"control value 541", align 1
  %19 = load i64, ptr %"control value 542", align 1
  %20 = call zeroext i8 @runtime_write_all(i32 2, ptr %18, i64 %19)
  store i8 %20, ptr %"control value 543", align 1
  %21 = call zeroext i8 @runtime_write_all(i32 2, ptr @tower.string.3, i64 1)
  store i8 %21, ptr %"control value 544", align 1
  call void @guest_exit(i32 1)
  ret void

if.body:                                          ; preds = %loop
  store ptr %length, ptr %"control value 538", align 1
  %22 = load ptr, ptr %"control value 538", align 1
  %23 = load i64, ptr %22, align 1
  store i64 %23, ptr %"control value 539", align 1
  %24 = load i64, ptr %"control value 539", align 1
  %25 = add i64 %24, 1
  store i64 %25, ptr %"control value 540", align 1
  %26 = load ptr, ptr %"control value 538", align 1
  %27 = load i64, ptr %"control value 540", align 1
  store i64 %27, ptr %26, align 1
  br label %if.end

if.else:                                          ; preds = %loop
  br label %loop.end

if.end:                                           ; preds = %if.body
  br label %loop
}

declare void @tower_main()

define void @tower_start() {
entry:
  call void @tower_main()
  call void @guest_exit(i32 0)
  ret void
}

define i32 @guest_runtime_main() {
entry:
  call void @tower_main()
  ret i32 0
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memmove.p0.p0.i64(ptr nocapture writeonly, ptr nocapture readonly, i64, i1 immarg) #0

; Function Attrs: naked
define void @_start() #1 {
entry:
  call void asm sideeffect "bl tower_start", ""()
  unreachable
}

attributes #0 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #1 = { naked }
