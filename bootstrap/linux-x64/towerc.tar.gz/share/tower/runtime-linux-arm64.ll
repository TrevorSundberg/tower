; ModuleID = '/cache/operator-published-clean/guest-linux-arm64-unbound.ll'
source_filename = "Tower"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-unknown-linux-gnu"

@0 = private unnamed_addr constant [17 x i8] c"Division by zero\00", align 1
@1 = private unnamed_addr constant [67 x i8] c"Numeric conversion out of range; use bits for bit reinterpretation\00", align 1
@2 = private unnamed_addr constant [67 x i8] c"Numeric conversion out of range; use bits for bit reinterpretation\00", align 1
@3 = private unnamed_addr constant [67 x i8] c"Numeric conversion out of range; use bits for bit reinterpretation\00", align 1
@tower.string = private global [6 x i8] c"true\0A\00", align 1
@tower.string.1 = private global [7 x i8] c"false\0A\00", align 1
@4 = private unnamed_addr constant [67 x i8] c"Numeric conversion out of range; use bits for bit reinterpretation\00", align 1
@tower.string.2 = private global [17 x i8] c"0123456789abcdef\00", align 1
@5 = private unnamed_addr constant [17 x i8] c"Division by zero\00", align 1
@6 = private unnamed_addr constant [17 x i8] c"Division by zero\00", align 1
@7 = private unnamed_addr constant [17 x i8] c"Division by zero\00", align 1
@8 = private unnamed_addr constant [67 x i8] c"Numeric conversion out of range; use bits for bit reinterpretation\00", align 1
@9 = private unnamed_addr constant [17 x i8] c"Division by zero\00", align 1
@10 = private unnamed_addr constant [67 x i8] c"Numeric conversion out of range; use bits for bit reinterpretation\00", align 1
@11 = private unnamed_addr constant [67 x i8] c"Numeric conversion out of range; use bits for bit reinterpretation\00", align 1
@12 = private unnamed_addr constant [67 x i8] c"Numeric conversion out of range; use bits for bit reinterpretation\00", align 1
@tower.string.3 = private global [2 x i8] c"\0A\00", align 1

define internal i8 @tower.fn.guest_runtime_product(i64 %0, i64 %1) {
entry:
  %count = alloca i64, align 8
  %size = alloca i64, align 8
  %maximum = alloca i64, align 8
  %sized = alloca i8, align 1
  %limit = alloca i64, align 8
  %overflow = alloca i8, align 1
  %"control value 174" = alloca ptr, align 8
  %"control value 175" = alloca i64, align 8
  %"control value 176" = alloca i64, align 8
  %"control value 177" = alloca i64, align 8
  %"control value 178" = alloca i8, align 1
  %"control value 179" = alloca i8, align 1
  %"control value 180" = alloca i64, align 8
  %"control value 181" = alloca i64, align 8
  %"control value 182" = alloca i64, align 8
  %"control value 183" = alloca i64, align 8
  %"control value 184" = alloca i64, align 8
  %"control value 185" = alloca i8, align 1
  %"control value 186" = alloca i8, align 1
  store i64 %0, ptr %count, align 1
  store i64 %1, ptr %size, align 1
  store i64 0, ptr %maximum, align 1
  store ptr %maximum, ptr %"control value 174", align 1
  %2 = load ptr, ptr %"control value 174", align 1
  %3 = load i64, ptr %2, align 1
  store i64 %3, ptr %"control value 175", align 1
  %4 = load i64, ptr %"control value 175", align 1
  %5 = sub i64 %4, 1
  store i64 %5, ptr %"control value 176", align 1
  %6 = load ptr, ptr %"control value 174", align 1
  %7 = load i64, ptr %"control value 176", align 1
  store i64 %7, ptr %6, align 1
  %8 = load i64, ptr %size, align 1
  store i64 %8, ptr %"control value 177", align 1
  %9 = load i64, ptr %"control value 177", align 1
  %10 = icmp ne i64 %9, 0
  %11 = zext i1 %10 to i8
  store i8 %11, ptr %"control value 178", align 1
  %12 = load i8, ptr %"control value 178", align 1
  store i8 %12, ptr %sized, align 1
  %13 = load i8, ptr %sized, align 1
  store i8 %13, ptr %"control value 179", align 1
  %14 = load i8, ptr %"control value 179", align 1
  %15 = icmp ne i8 %14, 0
  br i1 %15, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  %16 = load i64, ptr %maximum, align 1
  store i64 %16, ptr %"control value 180", align 1
  %17 = load i64, ptr %size, align 1
  store i64 %17, ptr %"control value 181", align 1
  %18 = load i64, ptr %"control value 180", align 1
  %19 = load i64, ptr %"control value 181", align 1
  %20 = icmp ne i64 %19, 0
  br i1 %20, label %valid, label %error

if.else:                                          ; preds = %entry
  br label %if.end

if.end:                                           ; preds = %if.end3, %if.else
  ret i8 1

valid:                                            ; preds = %if.body
  %21 = udiv i64 %18, %19
  store i64 %21, ptr %"control value 182", align 1
  %22 = load i64, ptr %"control value 182", align 1
  store i64 %22, ptr %limit, align 1
  %23 = load i64, ptr %count, align 1
  store i64 %23, ptr %"control value 183", align 1
  %24 = load i64, ptr %limit, align 1
  store i64 %24, ptr %"control value 184", align 1
  %25 = load i64, ptr %"control value 183", align 1
  %26 = load i64, ptr %"control value 184", align 1
  %27 = icmp ugt i64 %25, %26
  %28 = zext i1 %27 to i8
  store i8 %28, ptr %"control value 185", align 1
  %29 = load i8, ptr %"control value 185", align 1
  store i8 %29, ptr %overflow, align 1
  %30 = load i8, ptr %overflow, align 1
  store i8 %30, ptr %"control value 186", align 1
  %31 = load i8, ptr %"control value 186", align 1
  %32 = icmp ne i8 %31, 0
  br i1 %32, label %if.body1, label %if.else2

error:                                            ; preds = %if.body
  call void @tower_trap(ptr @0, i64 13639)
  unreachable

if.body1:                                         ; preds = %valid
  ret i8 0

if.else2:                                         ; preds = %valid
  br label %if.end3

if.end3:                                          ; preds = %if.else2
  br label %if.end
}

define ptr @tower_allocate(i64 %0, i64 %1) {
entry:
  %count = alloca i64, align 8
  %size = alloca i64, align 8
  %bytes = alloca i64, align 8
  %"control value 187" = alloca i64, align 8
  %"control value 188" = alloca i64, align 8
  %"control value 189" = alloca i8, align 1
  %"control value 190" = alloca i8, align 1
  %"control value 191" = alloca i64, align 8
  %"control value 192" = alloca i64, align 8
  %"control value 193" = alloca i64, align 8
  %"control value 194" = alloca i64, align 8
  %"control value 195" = alloca ptr, align 8
  store i64 %0, ptr %count, align 1
  store i64 %1, ptr %size, align 1
  %2 = load i64, ptr %count, align 1
  store i64 %2, ptr %"control value 187", align 1
  %3 = load i64, ptr %size, align 1
  store i64 %3, ptr %"control value 188", align 1
  %4 = load i64, ptr %"control value 187", align 1
  %5 = load i64, ptr %"control value 188", align 1
  %6 = call i8 @tower.fn.guest_runtime_product(i64 %4, i64 %5)
  store i8 %6, ptr %"control value 189", align 1
  %7 = load i8, ptr %"control value 189", align 1
  %8 = icmp eq i8 0, %7
  %9 = zext i1 %8 to i8
  store i8 %9, ptr %"control value 190", align 1
  %10 = load i8, ptr %"control value 190", align 1
  %11 = icmp ne i8 %10, 0
  br i1 %11, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  ret ptr null

if.else:                                          ; preds = %entry
  br label %if.end

if.end:                                           ; preds = %if.else
  %12 = load i64, ptr %count, align 1
  store i64 %12, ptr %"control value 191", align 1
  %13 = load i64, ptr %size, align 1
  store i64 %13, ptr %"control value 192", align 1
  %14 = load i64, ptr %"control value 191", align 1
  %15 = load i64, ptr %"control value 192", align 1
  %16 = mul i64 %14, %15
  store i64 %16, ptr %"control value 193", align 1
  %17 = load i64, ptr %"control value 193", align 1
  store i64 %17, ptr %bytes, align 1
  %18 = load i64, ptr %bytes, align 1
  store i64 %18, ptr %"control value 194", align 1
  %19 = load i64, ptr %"control value 194", align 1
  %20 = call ptr @guest_host_allocate(i64 %19)
  store ptr %20, ptr %"control value 195", align 1
  %21 = load ptr, ptr %"control value 195", align 1
  ret ptr %21
}

define ptr @tower_reallocate(ptr %0, i64 %1, i64 %2) {
entry:
  %pointer = alloca ptr, align 8
  %count = alloca i64, align 8
  %size = alloca i64, align 8
  %bytes = alloca i64, align 8
  %"control value 196" = alloca i64, align 8
  %"control value 197" = alloca i64, align 8
  %"control value 198" = alloca i8, align 1
  %"control value 199" = alloca i8, align 1
  %"control value 200" = alloca i64, align 8
  %"control value 201" = alloca i64, align 8
  %"control value 202" = alloca i64, align 8
  %"control value 203" = alloca ptr, align 8
  %"control value 204" = alloca i64, align 8
  %"control value 205" = alloca ptr, align 8
  store ptr %0, ptr %pointer, align 1
  store i64 %1, ptr %count, align 1
  store i64 %2, ptr %size, align 1
  %3 = load i64, ptr %count, align 1
  store i64 %3, ptr %"control value 196", align 1
  %4 = load i64, ptr %size, align 1
  store i64 %4, ptr %"control value 197", align 1
  %5 = load i64, ptr %"control value 196", align 1
  %6 = load i64, ptr %"control value 197", align 1
  %7 = call i8 @tower.fn.guest_runtime_product(i64 %5, i64 %6)
  store i8 %7, ptr %"control value 198", align 1
  %8 = load i8, ptr %"control value 198", align 1
  %9 = icmp eq i8 0, %8
  %10 = zext i1 %9 to i8
  store i8 %10, ptr %"control value 199", align 1
  %11 = load i8, ptr %"control value 199", align 1
  %12 = icmp ne i8 %11, 0
  br i1 %12, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  ret ptr null

if.else:                                          ; preds = %entry
  br label %if.end

if.end:                                           ; preds = %if.else
  %13 = load i64, ptr %count, align 1
  store i64 %13, ptr %"control value 200", align 1
  %14 = load i64, ptr %size, align 1
  store i64 %14, ptr %"control value 201", align 1
  %15 = load i64, ptr %"control value 200", align 1
  %16 = load i64, ptr %"control value 201", align 1
  %17 = mul i64 %15, %16
  store i64 %17, ptr %"control value 202", align 1
  %18 = load i64, ptr %"control value 202", align 1
  store i64 %18, ptr %bytes, align 1
  %19 = load ptr, ptr %pointer, align 1
  store ptr %19, ptr %"control value 203", align 1
  %20 = load i64, ptr %bytes, align 1
  store i64 %20, ptr %"control value 204", align 1
  %21 = load ptr, ptr %"control value 203", align 1
  %22 = load i64, ptr %"control value 204", align 1
  %23 = call ptr @guest_host_reallocate(ptr %21, i64 %22)
  store ptr %23, ptr %"control value 205", align 1
  %24 = load ptr, ptr %"control value 205", align 1
  ret ptr %24
}

define void @tower_deallocate(ptr %0) {
entry:
  %pointer = alloca ptr, align 8
  %"control value 206" = alloca ptr, align 8
  store ptr %0, ptr %pointer, align 1
  %1 = load ptr, ptr %pointer, align 1
  store ptr %1, ptr %"control value 206", align 1
  %2 = load ptr, ptr %"control value 206", align 1
  call void @guest_host_free(ptr %2)
  ret void
}

define i64 @system_call(i64 %0, i64 %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6) {
entry:
  %result = call i64 asm sideeffect "svc 0", "={x0},{x8},{x0},{x1},{x2},{x3},{x4},{x5},~{memory}"(i64 %0, i64 %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6)
  ret i64 %result
}

define internal i64 @tower.fn.GuestLinuxReadWrite() {
entry:
  %result = alloca i64, align 8
  %"control value 207" = alloca i64, align 8
  store i64 3, ptr %result, align 1
  %0 = load i64, ptr %result, align 1
  store i64 %0, ptr %"control value 207", align 1
  %1 = load i64, ptr %"control value 207", align 1
  ret i64 %1
}

define internal i64 @tower.fn.GuestLinuxPrivateAnonymous() {
entry:
  %result = alloca i64, align 8
  %"control value 208" = alloca i64, align 8
  store i64 34, ptr %result, align 1
  %0 = load i64, ptr %result, align 1
  store i64 %0, ptr %"control value 208", align 1
  %1 = load i64, ptr %"control value 208", align 1
  ret i64 %1
}

define internal i64 @tower.fn.GuestLinuxHeaderBytes() {
entry:
  %result = alloca i64, align 8
  %"control value 209" = alloca i64, align 8
  store i64 16, ptr %result, align 1
  %0 = load i64, ptr %result, align 1
  store i64 %0, ptr %"control value 209", align 1
  %1 = load i64, ptr %"control value 209", align 1
  ret i64 %1
}

define ptr @guest_host_allocate(i64 %0) {
entry:
  %bytes = alloca i64, align 8
  %maximum = alloca i64, align 8
  %limit = alloca i64, align 8
  %overflow = alloca i8, align 1
  %total = alloca i64, align 8
  %result = alloca i64, align 8
  %address = alloca i64, align 8
  %failed = alloca i8, align 1
  %header = alloca ptr, align 8
  %data = alloca ptr, align 8
  %"control value 210" = alloca ptr, align 8
  %"control value 211" = alloca i64, align 8
  %"control value 212" = alloca i64, align 8
  %"control value 213" = alloca i64, align 8
  %"control value 214" = alloca i64, align 8
  %"control value 215" = alloca i64, align 8
  %"control value 216" = alloca i64, align 8
  %"control value 217" = alloca i64, align 8
  %"control value 218" = alloca i8, align 1
  %"control value 219" = alloca i8, align 1
  %"control value 220" = alloca i64, align 8
  %"control value 221" = alloca i64, align 8
  %"control value 222" = alloca i64, align 8
  %"control value 223" = alloca i64, align 8
  %"control value 224" = alloca i64, align 8
  %"control value 225" = alloca i64, align 8
  %"control value 226" = alloca i64, align 8
  %"control value 227" = alloca i64, align 8
  %"control value 228" = alloca i64, align 8
  %"control value 229" = alloca i64, align 8
  %"control value 230" = alloca i64, align 8
  %"control value 231" = alloca i64, align 8
  %"control value 232" = alloca i8, align 1
  %"control value 233" = alloca i8, align 1
  %"control value 234" = alloca i64, align 8
  %"control value 235" = alloca ptr, align 8
  %"control value 236" = alloca ptr, align 8
  %"control value 237" = alloca ptr, align 8
  %"control value 238" = alloca i64, align 8
  %"control value 239" = alloca ptr, align 8
  %"control value 240" = alloca ptr, align 8
  %"control value 241" = alloca ptr, align 8
  %"control value 242" = alloca ptr, align 8
  %"control value 243" = alloca i64, align 8
  %"control value 244" = alloca ptr, align 8
  %"control value 245" = alloca ptr, align 8
  %"control value 246" = alloca ptr, align 8
  store i64 %0, ptr %bytes, align 1
  store i64 0, ptr %maximum, align 1
  store ptr %maximum, ptr %"control value 210", align 1
  %1 = load ptr, ptr %"control value 210", align 1
  %2 = load i64, ptr %1, align 1
  store i64 %2, ptr %"control value 211", align 1
  %3 = load i64, ptr %"control value 211", align 1
  %4 = sub i64 %3, 1
  store i64 %4, ptr %"control value 212", align 1
  %5 = load ptr, ptr %"control value 210", align 1
  %6 = load i64, ptr %"control value 212", align 1
  store i64 %6, ptr %5, align 1
  %7 = load i64, ptr %maximum, align 1
  store i64 %7, ptr %"control value 213", align 1
  %8 = call i64 @tower.fn.GuestLinuxHeaderBytes()
  store i64 %8, ptr %"control value 214", align 1
  %9 = load i64, ptr %"control value 213", align 1
  %10 = load i64, ptr %"control value 214", align 1
  %11 = sub i64 %9, %10
  store i64 %11, ptr %"control value 215", align 1
  %12 = load i64, ptr %"control value 215", align 1
  store i64 %12, ptr %limit, align 1
  %13 = load i64, ptr %bytes, align 1
  store i64 %13, ptr %"control value 216", align 1
  %14 = load i64, ptr %limit, align 1
  store i64 %14, ptr %"control value 217", align 1
  %15 = load i64, ptr %"control value 216", align 1
  %16 = load i64, ptr %"control value 217", align 1
  %17 = icmp ugt i64 %15, %16
  %18 = zext i1 %17 to i8
  store i8 %18, ptr %"control value 218", align 1
  %19 = load i8, ptr %"control value 218", align 1
  store i8 %19, ptr %overflow, align 1
  %20 = load i8, ptr %overflow, align 1
  store i8 %20, ptr %"control value 219", align 1
  %21 = load i8, ptr %"control value 219", align 1
  %22 = icmp ne i8 %21, 0
  br i1 %22, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  ret ptr null

if.else:                                          ; preds = %entry
  br label %if.end

if.end:                                           ; preds = %if.else
  %23 = load i64, ptr %bytes, align 1
  store i64 %23, ptr %"control value 220", align 1
  %24 = call i64 @tower.fn.GuestLinuxHeaderBytes()
  store i64 %24, ptr %"control value 221", align 1
  %25 = load i64, ptr %"control value 220", align 1
  %26 = load i64, ptr %"control value 221", align 1
  %27 = add i64 %25, %26
  store i64 %27, ptr %"control value 222", align 1
  %28 = load i64, ptr %"control value 222", align 1
  store i64 %28, ptr %total, align 1
  %29 = call i64 @guest_linux_map_number()
  store i64 %29, ptr %"control value 223", align 1
  %30 = load i64, ptr %total, align 1
  store i64 %30, ptr %"control value 224", align 1
  %31 = load i64, ptr %"control value 224", align 1
  store i64 %31, ptr %"control value 225", align 1
  %32 = call i64 @tower.fn.GuestLinuxReadWrite()
  store i64 %32, ptr %"control value 226", align 1
  %33 = call i64 @tower.fn.GuestLinuxPrivateAnonymous()
  store i64 %33, ptr %"control value 227", align 1
  %34 = load i64, ptr %"control value 223", align 1
  %35 = load i64, ptr %"control value 225", align 1
  %36 = load i64, ptr %"control value 226", align 1
  %37 = load i64, ptr %"control value 227", align 1
  %38 = call i64 @system_call(i64 %34, i64 0, i64 %35, i64 %36, i64 %37, i64 -1, i64 0)
  store i64 %38, ptr %"control value 228", align 1
  %39 = load i64, ptr %"control value 228", align 1
  store i64 %39, ptr %result, align 1
  %40 = load i64, ptr %result, align 1
  store i64 %40, ptr %"control value 229", align 1
  %41 = load i64, ptr %"control value 229", align 1
  store i64 %41, ptr %"control value 230", align 1
  %42 = load i64, ptr %"control value 230", align 1
  store i64 %42, ptr %address, align 1
  %43 = load i64, ptr %address, align 1
  store i64 %43, ptr %"control value 231", align 1
  %44 = load i64, ptr %"control value 231", align 1
  %45 = icmp uge i64 %44, -4095
  %46 = zext i1 %45 to i8
  store i8 %46, ptr %"control value 232", align 1
  %47 = load i8, ptr %"control value 232", align 1
  store i8 %47, ptr %failed, align 1
  %48 = load i8, ptr %failed, align 1
  store i8 %48, ptr %"control value 233", align 1
  %49 = load i8, ptr %"control value 233", align 1
  %50 = icmp ne i8 %49, 0
  br i1 %50, label %if.body1, label %if.else2

if.body1:                                         ; preds = %if.end
  ret ptr null

if.else2:                                         ; preds = %if.end
  br label %if.end3

if.end3:                                          ; preds = %if.else2
  %51 = load i64, ptr %result, align 1
  store i64 %51, ptr %"control value 234", align 1
  %52 = load i64, ptr %"control value 234", align 1
  %53 = inttoptr i64 %52 to ptr
  store ptr %53, ptr %"control value 235", align 1
  %54 = load ptr, ptr %"control value 235", align 1
  store ptr %54, ptr %header, align 1
  %55 = load ptr, ptr %header, align 1
  store ptr %55, ptr %"control value 236", align 1
  %56 = load ptr, ptr %"control value 236", align 1
  %57 = getelementptr i8, ptr %56, i64 0
  store ptr %57, ptr %"control value 237", align 1
  %58 = load i64, ptr %total, align 1
  store i64 %58, ptr %"control value 238", align 1
  %59 = load ptr, ptr %"control value 237", align 1
  %60 = load i64, ptr %"control value 238", align 1
  store i64 %60, ptr %59, align 1
  %61 = load ptr, ptr %header, align 1
  store ptr %61, ptr %"control value 239", align 1
  %62 = load ptr, ptr %"control value 239", align 1
  store ptr %62, ptr %"control value 240", align 1
  %63 = load ptr, ptr %"control value 240", align 1
  store ptr %63, ptr %data, align 1
  store ptr %data, ptr %"control value 241", align 1
  %64 = load ptr, ptr %data, align 1
  store ptr %64, ptr %"control value 242", align 1
  %65 = call i64 @tower.fn.GuestLinuxHeaderBytes()
  store i64 %65, ptr %"control value 243", align 1
  %66 = load ptr, ptr %"control value 242", align 1
  %67 = load i64, ptr %"control value 243", align 1
  %68 = mul i64 %67, 1
  %69 = getelementptr i8, ptr %66, i64 %68
  store ptr %69, ptr %"control value 244", align 1
  %70 = load ptr, ptr %"control value 241", align 1
  %71 = load ptr, ptr %"control value 244", align 1
  store ptr %71, ptr %70, align 1
  %72 = load ptr, ptr %data, align 1
  store ptr %72, ptr %"control value 245", align 1
  %73 = load ptr, ptr %"control value 245", align 1
  store ptr %73, ptr %"control value 246", align 1
  %74 = load ptr, ptr %"control value 246", align 1
  ret ptr %74
}

define void @guest_host_free(ptr %0) {
entry:
  %pointer = alloca ptr, align 8
  %absent = alloca i8, align 1
  %base = alloca ptr, align 8
  %header = alloca ptr, align 8
  %"control value 247" = alloca ptr, align 8
  %"control value 248" = alloca i8, align 1
  %"control value 249" = alloca i8, align 1
  %"control value 250" = alloca ptr, align 8
  %"control value 251" = alloca ptr, align 8
  %"control value 252" = alloca ptr, align 8
  %"control value 253" = alloca ptr, align 8
  %"control value 254" = alloca i64, align 8
  %"control value 255" = alloca ptr, align 8
  %"control value 256" = alloca ptr, align 8
  %"control value 257" = alloca ptr, align 8
  %"control value 258" = alloca i64, align 8
  %"control value 259" = alloca ptr, align 8
  %"control value 260" = alloca i64, align 8
  %"control value 261" = alloca ptr, align 8
  %"control value 262" = alloca i64, align 8
  %"control value 263" = alloca i64, align 8
  %"control value 264" = alloca i64, align 8
  store ptr %0, ptr %pointer, align 1
  %1 = load ptr, ptr %pointer, align 1
  store ptr %1, ptr %"control value 247", align 1
  %2 = load ptr, ptr %"control value 247", align 1
  %3 = icmp eq ptr %2, null
  %4 = zext i1 %3 to i8
  store i8 %4, ptr %"control value 248", align 1
  %5 = load i8, ptr %"control value 248", align 1
  store i8 %5, ptr %absent, align 1
  %6 = load i8, ptr %absent, align 1
  store i8 %6, ptr %"control value 249", align 1
  %7 = load i8, ptr %"control value 249", align 1
  %8 = icmp ne i8 %7, 0
  br i1 %8, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  ret void

if.else:                                          ; preds = %entry
  br label %if.end

if.end:                                           ; preds = %if.else
  %9 = load ptr, ptr %pointer, align 1
  store ptr %9, ptr %"control value 250", align 1
  %10 = load ptr, ptr %"control value 250", align 1
  store ptr %10, ptr %"control value 251", align 1
  %11 = load ptr, ptr %"control value 251", align 1
  store ptr %11, ptr %base, align 1
  store ptr %base, ptr %"control value 252", align 1
  %12 = load ptr, ptr %base, align 1
  store ptr %12, ptr %"control value 253", align 1
  %13 = call i64 @tower.fn.GuestLinuxHeaderBytes()
  store i64 %13, ptr %"control value 254", align 1
  %14 = load ptr, ptr %"control value 253", align 1
  %15 = load i64, ptr %"control value 254", align 1
  %16 = mul i64 %15, 1
  %17 = sub i64 0, %16
  %18 = getelementptr i8, ptr %14, i64 %17
  store ptr %18, ptr %"control value 255", align 1
  %19 = load ptr, ptr %"control value 252", align 1
  %20 = load ptr, ptr %"control value 255", align 1
  store ptr %20, ptr %19, align 1
  %21 = load ptr, ptr %base, align 1
  store ptr %21, ptr %"control value 256", align 1
  %22 = load ptr, ptr %"control value 256", align 1
  store ptr %22, ptr %"control value 257", align 1
  %23 = load ptr, ptr %"control value 257", align 1
  store ptr %23, ptr %header, align 1
  %24 = call i64 @guest_linux_unmap_number()
  store i64 %24, ptr %"control value 258", align 1
  %25 = load ptr, ptr %base, align 1
  store ptr %25, ptr %"control value 259", align 1
  %26 = load ptr, ptr %"control value 259", align 1
  %27 = ptrtoint ptr %26 to i64
  store i64 %27, ptr %"control value 260", align 1
  %28 = load ptr, ptr %header, align 1
  store ptr %28, ptr %"control value 261", align 1
  %29 = load ptr, ptr %"control value 261", align 1
  %30 = getelementptr i8, ptr %29, i64 0
  %31 = load i64, ptr %30, align 1
  store i64 %31, ptr %"control value 262", align 1
  %32 = load i64, ptr %"control value 262", align 1
  store i64 %32, ptr %"control value 263", align 1
  %33 = load i64, ptr %"control value 258", align 1
  %34 = load i64, ptr %"control value 260", align 1
  %35 = load i64, ptr %"control value 263", align 1
  %36 = call i64 @system_call(i64 %33, i64 %34, i64 %35, i64 0, i64 0, i64 0, i64 0)
  store i64 %36, ptr %"control value 264", align 1
  ret void
}

define ptr @guest_host_reallocate(ptr %0, i64 %1) {
entry:
  %pointer = alloca ptr, align 8
  %bytes = alloca i64, align 8
  %absent = alloca i8, align 1
  %empty = alloca i8, align 1
  %base = alloca ptr, align 8
  %header = alloca ptr, align 8
  %old = alloca i64, align 8
  %result = alloca ptr, align 8
  %allocated = alloca i8, align 1
  %smaller = alloca i8, align 1
  %"control value 265" = alloca ptr, align 8
  %"control value 266" = alloca i8, align 1
  %"control value 267" = alloca i8, align 1
  %"control value 268" = alloca i64, align 8
  %"control value 269" = alloca ptr, align 8
  %"control value 270" = alloca i64, align 8
  %"control value 271" = alloca i8, align 1
  %"control value 272" = alloca i8, align 1
  %"control value 273" = alloca ptr, align 8
  %"control value 274" = alloca ptr, align 8
  %"control value 275" = alloca ptr, align 8
  %"control value 276" = alloca ptr, align 8
  %"control value 277" = alloca ptr, align 8
  %"control value 278" = alloca i64, align 8
  %"control value 279" = alloca ptr, align 8
  %"control value 280" = alloca ptr, align 8
  %"control value 281" = alloca ptr, align 8
  %"control value 282" = alloca ptr, align 8
  %"control value 283" = alloca i64, align 8
  %"control value 284" = alloca i64, align 8
  %"control value 285" = alloca i64, align 8
  %"control value 286" = alloca i64, align 8
  %"control value 287" = alloca ptr, align 8
  %"control value 288" = alloca ptr, align 8
  %"control value 289" = alloca i8, align 1
  %"control value 290" = alloca i8, align 1
  %"control value 291" = alloca i64, align 8
  %"control value 292" = alloca i64, align 8
  %"control value 293" = alloca i8, align 1
  %"control value 294" = alloca i8, align 1
  %"control value 295" = alloca ptr, align 8
  %"control value 296" = alloca i64, align 8
  %"control value 297" = alloca ptr, align 8
  %"control value 298" = alloca ptr, align 8
  %"control value 299" = alloca i64, align 8
  %"control value 300" = alloca ptr, align 8
  %"control value 301" = alloca ptr, align 8
  store ptr %0, ptr %pointer, align 1
  store i64 %1, ptr %bytes, align 1
  %2 = load ptr, ptr %pointer, align 1
  store ptr %2, ptr %"control value 265", align 1
  %3 = load ptr, ptr %"control value 265", align 1
  %4 = icmp eq ptr %3, null
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %"control value 266", align 1
  %6 = load i8, ptr %"control value 266", align 1
  store i8 %6, ptr %absent, align 1
  %7 = load i8, ptr %absent, align 1
  store i8 %7, ptr %"control value 267", align 1
  %8 = load i8, ptr %"control value 267", align 1
  %9 = icmp ne i8 %8, 0
  br i1 %9, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  %10 = load i64, ptr %bytes, align 1
  store i64 %10, ptr %"control value 268", align 1
  %11 = load i64, ptr %"control value 268", align 1
  %12 = call ptr @guest_host_allocate(i64 %11)
  store ptr %12, ptr %"control value 269", align 1
  %13 = load ptr, ptr %"control value 269", align 1
  ret ptr %13

if.else:                                          ; preds = %entry
  br label %if.end

if.end:                                           ; preds = %if.else
  %14 = load i64, ptr %bytes, align 1
  store i64 %14, ptr %"control value 270", align 1
  %15 = load i64, ptr %"control value 270", align 1
  %16 = icmp eq i64 %15, 0
  %17 = zext i1 %16 to i8
  store i8 %17, ptr %"control value 271", align 1
  %18 = load i8, ptr %"control value 271", align 1
  store i8 %18, ptr %empty, align 1
  %19 = load i8, ptr %empty, align 1
  store i8 %19, ptr %"control value 272", align 1
  %20 = load i8, ptr %"control value 272", align 1
  %21 = icmp ne i8 %20, 0
  br i1 %21, label %if.body1, label %if.else2

if.body1:                                         ; preds = %if.end
  %22 = load ptr, ptr %pointer, align 1
  store ptr %22, ptr %"control value 273", align 1
  %23 = load ptr, ptr %"control value 273", align 1
  call void @guest_host_free(ptr %23)
  ret ptr null

if.else2:                                         ; preds = %if.end
  br label %if.end3

if.end3:                                          ; preds = %if.else2
  %24 = load ptr, ptr %pointer, align 1
  store ptr %24, ptr %"control value 274", align 1
  %25 = load ptr, ptr %"control value 274", align 1
  store ptr %25, ptr %"control value 275", align 1
  %26 = load ptr, ptr %"control value 275", align 1
  store ptr %26, ptr %base, align 1
  store ptr %base, ptr %"control value 276", align 1
  %27 = load ptr, ptr %base, align 1
  store ptr %27, ptr %"control value 277", align 1
  %28 = call i64 @tower.fn.GuestLinuxHeaderBytes()
  store i64 %28, ptr %"control value 278", align 1
  %29 = load ptr, ptr %"control value 277", align 1
  %30 = load i64, ptr %"control value 278", align 1
  %31 = mul i64 %30, 1
  %32 = sub i64 0, %31
  %33 = getelementptr i8, ptr %29, i64 %32
  store ptr %33, ptr %"control value 279", align 1
  %34 = load ptr, ptr %"control value 276", align 1
  %35 = load ptr, ptr %"control value 279", align 1
  store ptr %35, ptr %34, align 1
  %36 = load ptr, ptr %base, align 1
  store ptr %36, ptr %"control value 280", align 1
  %37 = load ptr, ptr %"control value 280", align 1
  store ptr %37, ptr %"control value 281", align 1
  %38 = load ptr, ptr %"control value 281", align 1
  store ptr %38, ptr %header, align 1
  %39 = load ptr, ptr %header, align 1
  store ptr %39, ptr %"control value 282", align 1
  %40 = load ptr, ptr %"control value 282", align 1
  %41 = getelementptr i8, ptr %40, i64 0
  %42 = load i64, ptr %41, align 1
  store i64 %42, ptr %"control value 283", align 1
  %43 = call i64 @tower.fn.GuestLinuxHeaderBytes()
  store i64 %43, ptr %"control value 284", align 1
  %44 = load i64, ptr %"control value 283", align 1
  %45 = load i64, ptr %"control value 284", align 1
  %46 = sub i64 %44, %45
  store i64 %46, ptr %"control value 285", align 1
  %47 = load i64, ptr %"control value 285", align 1
  store i64 %47, ptr %old, align 1
  %48 = load i64, ptr %bytes, align 1
  store i64 %48, ptr %"control value 286", align 1
  %49 = load i64, ptr %"control value 286", align 1
  %50 = call ptr @guest_host_allocate(i64 %49)
  store ptr %50, ptr %"control value 287", align 1
  %51 = load ptr, ptr %"control value 287", align 1
  store ptr %51, ptr %result, align 1
  %52 = load ptr, ptr %result, align 1
  store ptr %52, ptr %"control value 288", align 1
  %53 = load ptr, ptr %"control value 288", align 1
  %54 = icmp ne ptr %53, null
  %55 = zext i1 %54 to i8
  store i8 %55, ptr %"control value 289", align 1
  %56 = load i8, ptr %"control value 289", align 1
  store i8 %56, ptr %allocated, align 1
  %57 = load i8, ptr %allocated, align 1
  store i8 %57, ptr %"control value 290", align 1
  %58 = load i8, ptr %"control value 290", align 1
  %59 = icmp ne i8 %58, 0
  br i1 %59, label %if.body4, label %if.else5

if.body4:                                         ; preds = %if.end3
  %60 = load i64, ptr %bytes, align 1
  store i64 %60, ptr %"control value 291", align 1
  %61 = load i64, ptr %old, align 1
  store i64 %61, ptr %"control value 292", align 1
  %62 = load i64, ptr %"control value 291", align 1
  %63 = load i64, ptr %"control value 292", align 1
  %64 = icmp ult i64 %62, %63
  %65 = zext i1 %64 to i8
  store i8 %65, ptr %"control value 293", align 1
  %66 = load i8, ptr %"control value 293", align 1
  store i8 %66, ptr %smaller, align 1
  %67 = load i8, ptr %smaller, align 1
  store i8 %67, ptr %"control value 294", align 1
  %68 = load i8, ptr %"control value 294", align 1
  %69 = icmp ne i8 %68, 0
  br i1 %69, label %if.body7, label %if.else8

if.else5:                                         ; preds = %if.end3
  br label %if.end6

if.end6:                                          ; preds = %if.end9, %if.else5
  %70 = load ptr, ptr %result, align 1
  store ptr %70, ptr %"control value 301", align 1
  %71 = load ptr, ptr %"control value 301", align 1
  ret ptr %71

if.body7:                                         ; preds = %if.body4
  store ptr %old, ptr %"control value 295", align 1
  %72 = load i64, ptr %bytes, align 1
  store i64 %72, ptr %"control value 296", align 1
  %73 = load ptr, ptr %"control value 295", align 1
  %74 = load i64, ptr %"control value 296", align 1
  store i64 %74, ptr %73, align 1
  br label %if.end9

if.else8:                                         ; preds = %if.body4
  br label %if.end9

if.end9:                                          ; preds = %if.else8, %if.body7
  %75 = load ptr, ptr %result, align 1
  store ptr %75, ptr %"control value 297", align 1
  %76 = load ptr, ptr %pointer, align 1
  store ptr %76, ptr %"control value 298", align 1
  %77 = load i64, ptr %old, align 1
  store i64 %77, ptr %"control value 299", align 1
  %78 = load ptr, ptr %"control value 297", align 1
  %79 = load ptr, ptr %"control value 298", align 1
  %80 = load i64, ptr %"control value 299", align 1
  call void @llvm.memmove.p0.p0.i64(ptr align 1 %78, ptr align 1 %79, i64 %80, i1 false)
  %81 = load ptr, ptr %pointer, align 1
  store ptr %81, ptr %"control value 300", align 1
  %82 = load ptr, ptr %"control value 300", align 1
  call void @guest_host_free(ptr %82)
  br label %if.end6
}

define i64 @platform_write(i32 %0, ptr %1, i64 %2) {
entry:
  %stream = alloca i32, align 4
  %bytes = alloca ptr, align 8
  %count = alloca i64, align 8
  %valid = alloca i8, align 1
  %result = alloca i64, align 8
  %failed = alloca i8, align 1
  %"control value 302" = alloca i32, align 4
  %"control value 303" = alloca i8, align 1
  %"control value 304" = alloca i8, align 1
  %"control value 305" = alloca i8, align 1
  %"control value 306" = alloca ptr, align 8
  %"control value 307" = alloca i32, align 4
  %"control value 308" = alloca i8, align 1
  %"control value 309" = alloca i8, align 1
  %"control value 310" = alloca i8, align 1
  %"control value 311" = alloca i64, align 8
  %"control value 312" = alloca i32, align 4
  %"control value 313" = alloca i64, align 8
  %"control value 314" = alloca ptr, align 8
  %"control value 315" = alloca i64, align 8
  %"control value 316" = alloca i64, align 8
  %"control value 317" = alloca i64, align 8
  %"control value 318" = alloca i64, align 8
  %"control value 319" = alloca i64, align 8
  %"control value 320" = alloca i8, align 1
  %"control value 321" = alloca i8, align 1
  %"control value 322" = alloca i64, align 8
  store i32 %0, ptr %stream, align 1
  store ptr %1, ptr %bytes, align 1
  store i64 %2, ptr %count, align 1
  %3 = load i32, ptr %stream, align 1
  store i32 %3, ptr %"control value 302", align 1
  %4 = load i32, ptr %"control value 302", align 1
  %5 = icmp eq i32 %4, 1
  %6 = zext i1 %5 to i8
  store i8 %6, ptr %"control value 303", align 1
  %7 = load i8, ptr %"control value 303", align 1
  store i8 %7, ptr %valid, align 1
  %8 = load i8, ptr %valid, align 1
  store i8 %8, ptr %"control value 304", align 1
  %9 = load i8, ptr %"control value 304", align 1
  %10 = icmp eq i8 0, %9
  %11 = zext i1 %10 to i8
  store i8 %11, ptr %"control value 305", align 1
  %12 = load i8, ptr %"control value 305", align 1
  %13 = icmp ne i8 %12, 0
  br i1 %13, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  store ptr %valid, ptr %"control value 306", align 1
  %14 = load i32, ptr %stream, align 1
  store i32 %14, ptr %"control value 307", align 1
  %15 = load i32, ptr %"control value 307", align 1
  %16 = icmp eq i32 %15, 2
  %17 = zext i1 %16 to i8
  store i8 %17, ptr %"control value 308", align 1
  %18 = load ptr, ptr %"control value 306", align 1
  %19 = load i8, ptr %"control value 308", align 1
  store i8 %19, ptr %18, align 1
  br label %if.end

if.else:                                          ; preds = %entry
  br label %if.end

if.end:                                           ; preds = %if.else, %if.body
  %20 = load i8, ptr %valid, align 1
  store i8 %20, ptr %"control value 309", align 1
  %21 = load i8, ptr %"control value 309", align 1
  %22 = icmp eq i8 0, %21
  %23 = zext i1 %22 to i8
  store i8 %23, ptr %"control value 310", align 1
  %24 = load i8, ptr %"control value 310", align 1
  %25 = icmp ne i8 %24, 0
  br i1 %25, label %if.body1, label %if.else2

if.body1:                                         ; preds = %if.end
  ret i64 -1

if.else2:                                         ; preds = %if.end
  br label %if.end3

if.end3:                                          ; preds = %if.else2
  %26 = call i64 @guest_linux_write_number()
  store i64 %26, ptr %"control value 311", align 1
  %27 = load i32, ptr %stream, align 1
  store i32 %27, ptr %"control value 312", align 1
  %28 = load i32, ptr %"control value 312", align 1
  %29 = zext i32 %28 to i64
  %30 = icmp ule i64 %29, 9223372036854775807
  %31 = and i1 true, %30
  br i1 %31, label %valid4, label %error

valid4:                                           ; preds = %if.end3
  %32 = zext i32 %28 to i64
  store i64 %32, ptr %"control value 313", align 1
  %33 = load ptr, ptr %bytes, align 1
  store ptr %33, ptr %"control value 314", align 1
  %34 = load ptr, ptr %"control value 314", align 1
  %35 = ptrtoint ptr %34 to i64
  store i64 %35, ptr %"control value 315", align 1
  %36 = load i64, ptr %count, align 1
  store i64 %36, ptr %"control value 316", align 1
  %37 = load i64, ptr %"control value 316", align 1
  store i64 %37, ptr %"control value 317", align 1
  %38 = load i64, ptr %"control value 311", align 1
  %39 = load i64, ptr %"control value 313", align 1
  %40 = load i64, ptr %"control value 315", align 1
  %41 = load i64, ptr %"control value 317", align 1
  %42 = call i64 @system_call(i64 %38, i64 %39, i64 %40, i64 %41, i64 0, i64 0, i64 0)
  store i64 %42, ptr %"control value 318", align 1
  %43 = load i64, ptr %"control value 318", align 1
  store i64 %43, ptr %result, align 1
  %44 = load i64, ptr %result, align 1
  store i64 %44, ptr %"control value 319", align 1
  %45 = load i64, ptr %"control value 319", align 1
  %46 = icmp slt i64 %45, 0
  %47 = zext i1 %46 to i8
  store i8 %47, ptr %"control value 320", align 1
  %48 = load i8, ptr %"control value 320", align 1
  store i8 %48, ptr %failed, align 1
  %49 = load i8, ptr %failed, align 1
  store i8 %49, ptr %"control value 321", align 1
  %50 = load i8, ptr %"control value 321", align 1
  %51 = icmp ne i8 %50, 0
  br i1 %51, label %if.body5, label %if.else6

error:                                            ; preds = %if.end3
  call void @tower_trap(ptr @1, i64 14793)
  unreachable

if.body5:                                         ; preds = %valid4
  ret i64 -1

if.else6:                                         ; preds = %valid4
  br label %if.end7

if.end7:                                          ; preds = %if.else6
  %52 = load i64, ptr %result, align 1
  store i64 %52, ptr %"control value 322", align 1
  %53 = load i64, ptr %"control value 322", align 1
  ret i64 %53
}

define void @guest_exit(i32 %0) {
entry:
  %status = alloca i32, align 4
  %"control value 323" = alloca i64, align 8
  %"control value 324" = alloca i32, align 4
  %"control value 325" = alloca i64, align 8
  %"control value 326" = alloca i64, align 8
  store i32 %0, ptr %status, align 1
  %1 = call i64 @guest_linux_exit_number()
  store i64 %1, ptr %"control value 323", align 1
  %2 = load i32, ptr %status, align 1
  store i32 %2, ptr %"control value 324", align 1
  %3 = load i32, ptr %"control value 324", align 1
  %4 = sext i32 %3 to i64
  %5 = icmp sge i64 %4, -9223372036854775808
  %6 = icmp sle i64 %4, 9223372036854775807
  %7 = and i1 %5, %6
  br i1 %7, label %valid, label %error

valid:                                            ; preds = %entry
  %8 = sext i32 %3 to i64
  store i64 %8, ptr %"control value 325", align 1
  %9 = load i64, ptr %"control value 323", align 1
  %10 = load i64, ptr %"control value 325", align 1
  %11 = call i64 @system_call(i64 %9, i64 %10, i64 0, i64 0, i64 0, i64 0, i64 0)
  store i64 %11, ptr %"control value 326", align 1
  ret void

error:                                            ; preds = %entry
  call void @tower_trap(ptr @2, i64 14793)
  unreachable
}

define i64 @guest_linux_write_number() {
entry:
  ret i64 64
}

define i64 @guest_linux_exit_number() {
entry:
  ret i64 93
}

define i64 @guest_linux_map_number() {
entry:
  ret i64 222
}

define i64 @guest_linux_unmap_number() {
entry:
  ret i64 215
}

define ptr @memcpy(ptr %0, ptr %1, i64 %2) {
entry:
  %destination = alloca ptr, align 8
  %source = alloca ptr, align 8
  %count = alloca i64, align 8
  %out = alloca ptr, align 8
  %input = alloca ptr, align 8
  %i = alloca i64, align 8
  %"control value 170" = alloca i8, align 1
  %"control value 327" = alloca ptr, align 8
  %"control value 328" = alloca ptr, align 8
  %"control value 329" = alloca ptr, align 8
  %"control value 330" = alloca ptr, align 8
  %"control value 331" = alloca i64, align 8
  %"control value 332" = alloca i64, align 8
  %"control value 333" = alloca i8, align 1
  %"control value 334" = alloca i8, align 1
  %"control value 335" = alloca ptr, align 8
  %"control value 336" = alloca i64, align 8
  %"control value 337" = alloca ptr, align 8
  %"control value 338" = alloca ptr, align 8
  %"control value 339" = alloca i64, align 8
  %"control value 340" = alloca i8, align 1
  %"control value 341" = alloca ptr, align 8
  %"control value 342" = alloca i64, align 8
  %"control value 343" = alloca i64, align 8
  %"control value 344" = alloca ptr, align 8
  store ptr %0, ptr %destination, align 1
  store ptr %1, ptr %source, align 1
  store i64 %2, ptr %count, align 1
  %3 = load ptr, ptr %destination, align 1
  store ptr %3, ptr %"control value 327", align 1
  %4 = load ptr, ptr %"control value 327", align 1
  store ptr %4, ptr %"control value 328", align 1
  %5 = load ptr, ptr %"control value 328", align 1
  store ptr %5, ptr %out, align 1
  %6 = load ptr, ptr %source, align 1
  store ptr %6, ptr %"control value 329", align 1
  %7 = load ptr, ptr %"control value 329", align 1
  store ptr %7, ptr %"control value 330", align 1
  %8 = load ptr, ptr %"control value 330", align 1
  store ptr %8, ptr %input, align 1
  store i64 0, ptr %i, align 1
  br label %loop

loop:                                             ; preds = %if.end, %entry
  %9 = load i64, ptr %i, align 1
  store i64 %9, ptr %"control value 331", align 1
  %10 = load i64, ptr %count, align 1
  store i64 %10, ptr %"control value 332", align 1
  %11 = load i64, ptr %"control value 331", align 1
  %12 = load i64, ptr %"control value 332", align 1
  %13 = icmp ult i64 %11, %12
  %14 = zext i1 %13 to i8
  store i8 %14, ptr %"control value 333", align 1
  %15 = load i8, ptr %"control value 333", align 1
  store i8 %15, ptr %"control value 170", align 1
  %16 = load i8, ptr %"control value 170", align 1
  store i8 %16, ptr %"control value 334", align 1
  %17 = load i8, ptr %"control value 334", align 1
  %18 = icmp ne i8 %17, 0
  br i1 %18, label %if.body, label %if.else

loop.end:                                         ; preds = %if.else
  %19 = load ptr, ptr %destination, align 1
  store ptr %19, ptr %"control value 344", align 1
  %20 = load ptr, ptr %"control value 344", align 1
  ret ptr %20

if.body:                                          ; preds = %loop
  %21 = load ptr, ptr %out, align 1
  store ptr %21, ptr %"control value 335", align 1
  %22 = load i64, ptr %i, align 1
  store i64 %22, ptr %"control value 336", align 1
  %23 = load ptr, ptr %"control value 335", align 1
  %24 = load i64, ptr %"control value 336", align 1
  %25 = mul i64 %24, 1
  %26 = getelementptr i8, ptr %23, i64 %25
  store ptr %26, ptr %"control value 337", align 1
  %27 = load ptr, ptr %input, align 1
  store ptr %27, ptr %"control value 338", align 1
  %28 = load i64, ptr %i, align 1
  store i64 %28, ptr %"control value 339", align 1
  %29 = load ptr, ptr %"control value 338", align 1
  %30 = load i64, ptr %"control value 339", align 1
  %31 = mul i64 %30, 1
  %32 = getelementptr i8, ptr %29, i64 %31
  %33 = load i8, ptr %32, align 1
  store i8 %33, ptr %"control value 340", align 1
  %34 = load ptr, ptr %"control value 337", align 1
  %35 = load i8, ptr %"control value 340", align 1
  store i8 %35, ptr %34, align 1
  store ptr %i, ptr %"control value 341", align 1
  %36 = load ptr, ptr %"control value 341", align 1
  %37 = load i64, ptr %36, align 1
  store i64 %37, ptr %"control value 342", align 1
  %38 = load i64, ptr %"control value 342", align 1
  %39 = add i64 %38, 1
  store i64 %39, ptr %"control value 343", align 1
  %40 = load ptr, ptr %"control value 341", align 1
  %41 = load i64, ptr %"control value 343", align 1
  store i64 %41, ptr %40, align 1
  br label %if.end

if.else:                                          ; preds = %loop
  br label %loop.end

if.end:                                           ; preds = %if.body
  br label %loop
}

define ptr @memmove(ptr %0, ptr %1, i64 %2) {
entry:
  %destination = alloca ptr, align 8
  %source = alloca ptr, align 8
  %count = alloca i64, align 8
  %out = alloca ptr, align 8
  %input = alloca ptr, align 8
  %forward = alloca i8, align 1
  %i = alloca i64, align 8
  %"control value 171" = alloca i8, align 1
  %"control value 345" = alloca ptr, align 8
  %"control value 346" = alloca ptr, align 8
  %"control value 347" = alloca ptr, align 8
  %"control value 348" = alloca ptr, align 8
  %"control value 349" = alloca ptr, align 8
  %"control value 350" = alloca i64, align 8
  %"control value 351" = alloca ptr, align 8
  %"control value 352" = alloca i64, align 8
  %"control value 353" = alloca i8, align 1
  %"control value 354" = alloca i8, align 1
  %"control value 355" = alloca ptr, align 8
  %"control value 356" = alloca ptr, align 8
  %"control value 357" = alloca i64, align 8
  %"control value 358" = alloca ptr, align 8
  %"control value 359" = alloca i64, align 8
  %"control value 360" = alloca i64, align 8
  %"control value 361" = alloca i8, align 1
  %"control value 362" = alloca i8, align 1
  %"control value 363" = alloca ptr, align 8
  %"control value 364" = alloca i64, align 8
  %"control value 365" = alloca i64, align 8
  %"control value 366" = alloca ptr, align 8
  %"control value 367" = alloca i64, align 8
  %"control value 368" = alloca ptr, align 8
  %"control value 369" = alloca ptr, align 8
  %"control value 370" = alloca i64, align 8
  %"control value 371" = alloca i8, align 1
  %"control value 372" = alloca ptr, align 8
  store ptr %0, ptr %destination, align 1
  store ptr %1, ptr %source, align 1
  store i64 %2, ptr %count, align 1
  %3 = load ptr, ptr %destination, align 1
  store ptr %3, ptr %"control value 345", align 1
  %4 = load ptr, ptr %"control value 345", align 1
  store ptr %4, ptr %"control value 346", align 1
  %5 = load ptr, ptr %"control value 346", align 1
  store ptr %5, ptr %out, align 1
  %6 = load ptr, ptr %source, align 1
  store ptr %6, ptr %"control value 347", align 1
  %7 = load ptr, ptr %"control value 347", align 1
  store ptr %7, ptr %"control value 348", align 1
  %8 = load ptr, ptr %"control value 348", align 1
  store ptr %8, ptr %input, align 1
  %9 = load ptr, ptr %out, align 1
  store ptr %9, ptr %"control value 349", align 1
  %10 = load ptr, ptr %"control value 349", align 1
  %11 = ptrtoint ptr %10 to i64
  store i64 %11, ptr %"control value 350", align 1
  %12 = load ptr, ptr %input, align 1
  store ptr %12, ptr %"control value 351", align 1
  %13 = load ptr, ptr %"control value 351", align 1
  %14 = ptrtoint ptr %13 to i64
  store i64 %14, ptr %"control value 352", align 1
  %15 = load i64, ptr %"control value 350", align 1
  %16 = load i64, ptr %"control value 352", align 1
  %17 = icmp ult i64 %15, %16
  %18 = zext i1 %17 to i8
  store i8 %18, ptr %"control value 353", align 1
  %19 = load i8, ptr %"control value 353", align 1
  store i8 %19, ptr %forward, align 1
  %20 = load i8, ptr %forward, align 1
  store i8 %20, ptr %"control value 354", align 1
  %21 = load i8, ptr %"control value 354", align 1
  %22 = icmp ne i8 %21, 0
  br i1 %22, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  %23 = load ptr, ptr %destination, align 1
  store ptr %23, ptr %"control value 355", align 1
  %24 = load ptr, ptr %source, align 1
  store ptr %24, ptr %"control value 356", align 1
  %25 = load i64, ptr %count, align 1
  store i64 %25, ptr %"control value 357", align 1
  %26 = load ptr, ptr %"control value 355", align 1
  %27 = load ptr, ptr %"control value 356", align 1
  %28 = load i64, ptr %"control value 357", align 1
  %29 = call ptr @memcpy(ptr %26, ptr %27, i64 %28)
  store ptr %29, ptr %"control value 358", align 1
  %30 = load ptr, ptr %"control value 358", align 1
  ret ptr %30

if.else:                                          ; preds = %entry
  br label %if.end

if.end:                                           ; preds = %if.else
  %31 = load i64, ptr %count, align 1
  store i64 %31, ptr %"control value 359", align 1
  %32 = load i64, ptr %"control value 359", align 1
  store i64 %32, ptr %i, align 1
  br label %loop

loop:                                             ; preds = %if.end3, %if.end
  %33 = load i64, ptr %i, align 1
  store i64 %33, ptr %"control value 360", align 1
  %34 = load i64, ptr %"control value 360", align 1
  %35 = icmp ne i64 %34, 0
  %36 = zext i1 %35 to i8
  store i8 %36, ptr %"control value 361", align 1
  %37 = load i8, ptr %"control value 361", align 1
  store i8 %37, ptr %"control value 171", align 1
  %38 = load i8, ptr %"control value 171", align 1
  store i8 %38, ptr %"control value 362", align 1
  %39 = load i8, ptr %"control value 362", align 1
  %40 = icmp ne i8 %39, 0
  br i1 %40, label %if.body1, label %if.else2

loop.end:                                         ; preds = %if.else2
  %41 = load ptr, ptr %destination, align 1
  store ptr %41, ptr %"control value 372", align 1
  %42 = load ptr, ptr %"control value 372", align 1
  ret ptr %42

if.body1:                                         ; preds = %loop
  store ptr %i, ptr %"control value 363", align 1
  %43 = load ptr, ptr %"control value 363", align 1
  %44 = load i64, ptr %43, align 1
  store i64 %44, ptr %"control value 364", align 1
  %45 = load i64, ptr %"control value 364", align 1
  %46 = sub i64 %45, 1
  store i64 %46, ptr %"control value 365", align 1
  %47 = load ptr, ptr %"control value 363", align 1
  %48 = load i64, ptr %"control value 365", align 1
  store i64 %48, ptr %47, align 1
  %49 = load ptr, ptr %out, align 1
  store ptr %49, ptr %"control value 366", align 1
  %50 = load i64, ptr %i, align 1
  store i64 %50, ptr %"control value 367", align 1
  %51 = load ptr, ptr %"control value 366", align 1
  %52 = load i64, ptr %"control value 367", align 1
  %53 = mul i64 %52, 1
  %54 = getelementptr i8, ptr %51, i64 %53
  store ptr %54, ptr %"control value 368", align 1
  %55 = load ptr, ptr %input, align 1
  store ptr %55, ptr %"control value 369", align 1
  %56 = load i64, ptr %i, align 1
  store i64 %56, ptr %"control value 370", align 1
  %57 = load ptr, ptr %"control value 369", align 1
  %58 = load i64, ptr %"control value 370", align 1
  %59 = mul i64 %58, 1
  %60 = getelementptr i8, ptr %57, i64 %59
  %61 = load i8, ptr %60, align 1
  store i8 %61, ptr %"control value 371", align 1
  %62 = load ptr, ptr %"control value 368", align 1
  %63 = load i8, ptr %"control value 371", align 1
  store i8 %63, ptr %62, align 1
  br label %if.end3

if.else2:                                         ; preds = %loop
  br label %loop.end

if.end3:                                          ; preds = %if.body1
  br label %loop
}

define ptr @memset(ptr %0, i32 %1, i64 %2) {
entry:
  %destination = alloca ptr, align 8
  %value = alloca i32, align 4
  %count = alloca i64, align 8
  %out = alloca ptr, align 8
  %low = alloca i32, align 4
  %byte = alloca i8, align 1
  %i = alloca i64, align 8
  %"control value 172" = alloca i8, align 1
  %"control value 373" = alloca ptr, align 8
  %"control value 374" = alloca ptr, align 8
  %"control value 375" = alloca i32, align 4
  %"control value 376" = alloca i32, align 4
  %"control value 377" = alloca i32, align 4
  %"control value 378" = alloca i32, align 4
  %"control value 379" = alloca i8, align 1
  %"control value 380" = alloca i64, align 8
  %"control value 381" = alloca i64, align 8
  %"control value 382" = alloca i8, align 1
  %"control value 383" = alloca i8, align 1
  %"control value 384" = alloca ptr, align 8
  %"control value 385" = alloca i64, align 8
  %"control value 386" = alloca ptr, align 8
  %"control value 387" = alloca i8, align 1
  %"control value 388" = alloca ptr, align 8
  %"control value 389" = alloca i64, align 8
  %"control value 390" = alloca i64, align 8
  %"control value 391" = alloca ptr, align 8
  store ptr %0, ptr %destination, align 1
  store i32 %1, ptr %value, align 1
  store i64 %2, ptr %count, align 1
  %3 = load ptr, ptr %destination, align 1
  store ptr %3, ptr %"control value 373", align 1
  %4 = load ptr, ptr %"control value 373", align 1
  store ptr %4, ptr %"control value 374", align 1
  %5 = load ptr, ptr %"control value 374", align 1
  store ptr %5, ptr %out, align 1
  %6 = load i32, ptr %value, align 1
  store i32 %6, ptr %"control value 375", align 1
  %7 = load i32, ptr %"control value 375", align 1
  store i32 %7, ptr %"control value 376", align 1
  %8 = load i32, ptr %"control value 376", align 1
  %9 = and i32 %8, 255
  store i32 %9, ptr %"control value 377", align 1
  %10 = load i32, ptr %"control value 377", align 1
  store i32 %10, ptr %low, align 1
  %11 = load i32, ptr %low, align 1
  store i32 %11, ptr %"control value 378", align 1
  %12 = load i32, ptr %"control value 378", align 1
  %13 = zext i32 %12 to i64
  %14 = icmp ule i64 %13, 255
  %15 = and i1 true, %14
  br i1 %15, label %valid, label %error

valid:                                            ; preds = %entry
  %16 = trunc i32 %12 to i8
  store i8 %16, ptr %"control value 379", align 1
  %17 = load i8, ptr %"control value 379", align 1
  store i8 %17, ptr %byte, align 1
  store i64 0, ptr %i, align 1
  br label %loop

error:                                            ; preds = %entry
  call void @tower_trap(ptr @3, i64 17933)
  unreachable

loop:                                             ; preds = %if.end, %valid
  %18 = load i64, ptr %i, align 1
  store i64 %18, ptr %"control value 380", align 1
  %19 = load i64, ptr %count, align 1
  store i64 %19, ptr %"control value 381", align 1
  %20 = load i64, ptr %"control value 380", align 1
  %21 = load i64, ptr %"control value 381", align 1
  %22 = icmp ult i64 %20, %21
  %23 = zext i1 %22 to i8
  store i8 %23, ptr %"control value 382", align 1
  %24 = load i8, ptr %"control value 382", align 1
  store i8 %24, ptr %"control value 172", align 1
  %25 = load i8, ptr %"control value 172", align 1
  store i8 %25, ptr %"control value 383", align 1
  %26 = load i8, ptr %"control value 383", align 1
  %27 = icmp ne i8 %26, 0
  br i1 %27, label %if.body, label %if.else

loop.end:                                         ; preds = %if.else
  %28 = load ptr, ptr %destination, align 1
  store ptr %28, ptr %"control value 391", align 1
  %29 = load ptr, ptr %"control value 391", align 1
  ret ptr %29

if.body:                                          ; preds = %loop
  %30 = load ptr, ptr %out, align 1
  store ptr %30, ptr %"control value 384", align 1
  %31 = load i64, ptr %i, align 1
  store i64 %31, ptr %"control value 385", align 1
  %32 = load ptr, ptr %"control value 384", align 1
  %33 = load i64, ptr %"control value 385", align 1
  %34 = mul i64 %33, 1
  %35 = getelementptr i8, ptr %32, i64 %34
  store ptr %35, ptr %"control value 386", align 1
  %36 = load i8, ptr %byte, align 1
  store i8 %36, ptr %"control value 387", align 1
  %37 = load ptr, ptr %"control value 386", align 1
  %38 = load i8, ptr %"control value 387", align 1
  store i8 %38, ptr %37, align 1
  store ptr %i, ptr %"control value 388", align 1
  %39 = load ptr, ptr %"control value 388", align 1
  %40 = load i64, ptr %39, align 1
  store i64 %40, ptr %"control value 389", align 1
  %41 = load i64, ptr %"control value 389", align 1
  %42 = add i64 %41, 1
  store i64 %42, ptr %"control value 390", align 1
  %43 = load ptr, ptr %"control value 388", align 1
  %44 = load i64, ptr %"control value 390", align 1
  store i64 %44, ptr %43, align 1
  br label %if.end

if.else:                                          ; preds = %loop
  br label %loop.end

if.end:                                           ; preds = %if.body
  br label %loop
}

define i64 @runtime_format_value(ptr %0, i64 %1, i32 %2, i64 %3, i32 %4) {
entry:
  %output = alloca ptr, align 8
  %capacity = alloca i64, align 8
  %kind = alloca i32, align 4
  %value = alloca i64, align 8
  %pointer_bytes = alloca i32, align 4
  %buffer = alloca [80 x i8], align 1
  %length = alloca i64, align 8
  %boolean = alloca i8, align 1
  %truth = alloca i8, align 1
  %pointer = alloca i8, align 1
  %valid = alloca i8, align 1
  %digits = alloca i64, align 8
  %at = alloca i64, align 8
  %hex = alloca ptr, align 8
  %done = alloca i8, align 1
  %index = alloca i64, align 8
  %narrow = alloca i8, align 1
  %negative = alloca i8, align 1
  %signed = alloca i8, align 1
  %zero = alloca i64, align 8
  %digits1 = alloca [24 x i8], align 1
  %count = alloca i64, align 8
  %digit = alloca i64, align 8
  %done2 = alloca i8, align 1
  %done3 = alloca i8, align 1
  %enough = alloca i8, align 1
  %"control value 392" = alloca i32, align 4
  %"control value 393" = alloca i8, align 1
  %"control value 394" = alloca i8, align 1
  %"control value 395" = alloca i64, align 8
  %"control value 396" = alloca i8, align 1
  %"control value 397" = alloca i8, align 1
  %"control value 398" = alloca ptr, align 8
  %"control value 399" = alloca ptr, align 8
  %"control value 400" = alloca ptr, align 8
  %"control value 401" = alloca ptr, align 8
  %"control value 402" = alloca i32, align 4
  %"control value 403" = alloca i8, align 1
  %"control value 404" = alloca i8, align 1
  %"control value 405" = alloca i32, align 4
  %"control value 406" = alloca i8, align 1
  %"control value 407" = alloca ptr, align 8
  %"control value 408" = alloca i8, align 1
  %"control value 409" = alloca i8, align 1
  %"control value 410" = alloca i8, align 1
  %"control value 411" = alloca i32, align 4
  %"control value 412" = alloca i8, align 1
  %"control value 413" = alloca i8, align 1
  %"control value 414" = alloca i8, align 1
  %"control value 415" = alloca ptr, align 8
  %"control value 416" = alloca ptr, align 8
  %"control value 417" = alloca i32, align 4
  %"control value 418" = alloca i64, align 8
  %"control value 419" = alloca i64, align 8
  %"control value 420" = alloca ptr, align 8
  %"control value 421" = alloca i64, align 8
  %"control value 422" = alloca i64, align 8
  %"control value 423" = alloca i64, align 8
  %"control value 424" = alloca i64, align 8
  %"control value 425" = alloca i8, align 1
  %"control value 426" = alloca i8, align 1
  %"control value 427" = alloca ptr, align 8
  %"control value 428" = alloca i64, align 8
  %"control value 429" = alloca i64, align 8
  %"control value 430" = alloca i64, align 8
  %"control value 431" = alloca i64, align 8
  %"control value 432" = alloca i64, align 8
  %"control value 433" = alloca ptr, align 8
  %"control value 434" = alloca ptr, align 8
  %"control value 435" = alloca i64, align 8
  %"control value 436" = alloca i8, align 1
  %"control value 437" = alloca ptr, align 8
  %"control value 438" = alloca i64, align 8
  %"control value 439" = alloca i64, align 8
  %"control value 440" = alloca i32, align 4
  %"control value 441" = alloca i8, align 1
  %"control value 442" = alloca i8, align 1
  %"control value 443" = alloca ptr, align 8
  %"control value 444" = alloca i64, align 8
  %"control value 445" = alloca i64, align 8
  %"control value 446" = alloca ptr, align 8
  %"control value 447" = alloca i64, align 8
  %"control value 448" = alloca i8, align 1
  %"control value 449" = alloca i32, align 4
  %"control value 450" = alloca i8, align 1
  %"control value 451" = alloca i8, align 1
  %"control value 452" = alloca ptr, align 8
  %"control value 453" = alloca i64, align 8
  %"control value 454" = alloca i8, align 1
  %"control value 455" = alloca i8, align 1
  %"control value 456" = alloca ptr, align 8
  %"control value 457" = alloca ptr, align 8
  %"control value 458" = alloca ptr, align 8
  %"control value 459" = alloca i64, align 8
  %"control value 460" = alloca i64, align 8
  %"control value 461" = alloca i64, align 8
  %"control value 462" = alloca i8, align 1
  %"control value 463" = alloca ptr, align 8
  %"control value 464" = alloca i64, align 8
  %"control value 465" = alloca i64, align 8
  %"control value 466" = alloca i64, align 8
  %"control value 467" = alloca i64, align 8
  %"control value 468" = alloca ptr, align 8
  %"control value 469" = alloca i64, align 8
  %"control value 470" = alloca i64, align 8
  %"control value 471" = alloca i64, align 8
  %"control value 472" = alloca ptr, align 8
  %"control value 473" = alloca i64, align 8
  %"control value 474" = alloca i8, align 1
  %"control value 475" = alloca ptr, align 8
  %"control value 476" = alloca i64, align 8
  %"control value 477" = alloca i64, align 8
  %"control value 478" = alloca ptr, align 8
  %"control value 479" = alloca i64, align 8
  %"control value 480" = alloca i64, align 8
  %"control value 481" = alloca i64, align 8
  %"control value 482" = alloca i8, align 1
  %"control value 483" = alloca i8, align 1
  %"control value 484" = alloca i64, align 8
  %"control value 485" = alloca i8, align 1
  %"control value 486" = alloca i8, align 1
  %"control value 487" = alloca ptr, align 8
  %"control value 488" = alloca i64, align 8
  %"control value 489" = alloca i64, align 8
  %"control value 490" = alloca i64, align 8
  %"control value 491" = alloca ptr, align 8
  %"control value 492" = alloca i64, align 8
  %"control value 493" = alloca i8, align 1
  %"control value 494" = alloca ptr, align 8
  %"control value 495" = alloca i64, align 8
  %"control value 496" = alloca i64, align 8
  %"control value 497" = alloca i64, align 8
  %"control value 498" = alloca ptr, align 8
  %"control value 499" = alloca ptr, align 8
  %"control value 500" = alloca i64, align 8
  %"control value 501" = alloca i64, align 8
  %"control value 502" = alloca i64, align 8
  %"control value 503" = alloca i64, align 8
  %"control value 504" = alloca i8, align 1
  %"control value 505" = alloca i8, align 1
  %"control value 506" = alloca ptr, align 8
  %"control value 507" = alloca ptr, align 8
  %"control value 508" = alloca i64, align 8
  %"control value 509" = alloca i64, align 8
  store ptr %0, ptr %output, align 1
  store i64 %1, ptr %capacity, align 1
  store i32 %2, ptr %kind, align 1
  store i64 %3, ptr %value, align 1
  store i32 %4, ptr %pointer_bytes, align 1
  store i64 0, ptr %length, align 1
  %5 = load i32, ptr %kind, align 1
  store i32 %5, ptr %"control value 392", align 1
  %6 = load i32, ptr %"control value 392", align 1
  %7 = icmp eq i32 %6, 2
  %8 = zext i1 %7 to i8
  store i8 %8, ptr %"control value 393", align 1
  %9 = load i8, ptr %"control value 393", align 1
  store i8 %9, ptr %boolean, align 1
  %10 = load i8, ptr %boolean, align 1
  store i8 %10, ptr %"control value 394", align 1
  %11 = load i8, ptr %"control value 394", align 1
  %12 = icmp ne i8 %11, 0
  br i1 %12, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  %13 = load i64, ptr %value, align 1
  store i64 %13, ptr %"control value 395", align 1
  %14 = load i64, ptr %"control value 395", align 1
  %15 = icmp ne i64 %14, 0
  %16 = zext i1 %15 to i8
  store i8 %16, ptr %"control value 396", align 1
  %17 = load i8, ptr %"control value 396", align 1
  store i8 %17, ptr %truth, align 1
  %18 = load i8, ptr %truth, align 1
  store i8 %18, ptr %"control value 397", align 1
  %19 = load i8, ptr %"control value 397", align 1
  %20 = icmp ne i8 %19, 0
  br i1 %20, label %if.body4, label %if.else5

if.else:                                          ; preds = %entry
  %21 = load i32, ptr %kind, align 1
  store i32 %21, ptr %"control value 402", align 1
  %22 = load i32, ptr %"control value 402", align 1
  %23 = icmp eq i32 %22, 3
  %24 = zext i1 %23 to i8
  store i8 %24, ptr %"control value 403", align 1
  %25 = load i8, ptr %"control value 403", align 1
  store i8 %25, ptr %pointer, align 1
  %26 = load i8, ptr %pointer, align 1
  store i8 %26, ptr %"control value 404", align 1
  %27 = load i8, ptr %"control value 404", align 1
  %28 = icmp ne i8 %27, 0
  br i1 %28, label %if.body7, label %if.else8

if.end:                                           ; preds = %if.end9, %if.end6
  %29 = load i64, ptr %capacity, align 1
  store i64 %29, ptr %"control value 502", align 1
  %30 = load i64, ptr %length, align 1
  store i64 %30, ptr %"control value 503", align 1
  %31 = load i64, ptr %"control value 502", align 1
  %32 = load i64, ptr %"control value 503", align 1
  %33 = icmp uge i64 %31, %32
  %34 = zext i1 %33 to i8
  store i8 %34, ptr %"control value 504", align 1
  %35 = load i8, ptr %"control value 504", align 1
  store i8 %35, ptr %enough, align 1
  %36 = load i8, ptr %enough, align 1
  store i8 %36, ptr %"control value 505", align 1
  %37 = load i8, ptr %"control value 505", align 1
  %38 = icmp ne i8 %37, 0
  br i1 %38, label %if.body52, label %if.else53

if.body4:                                         ; preds = %if.body
  %39 = getelementptr i8, ptr %buffer, i64 0
  store ptr %39, ptr %"control value 398", align 1
  %40 = load ptr, ptr %"control value 398", align 1
  call void @llvm.memmove.p0.p0.i64(ptr align 1 %40, ptr align 1 @tower.string, i64 5, i1 false)
  store ptr %length, ptr %"control value 399", align 1
  %41 = load ptr, ptr %"control value 399", align 1
  store i64 5, ptr %41, align 1
  br label %if.end6

if.else5:                                         ; preds = %if.body
  %42 = getelementptr i8, ptr %buffer, i64 0
  store ptr %42, ptr %"control value 400", align 1
  %43 = load ptr, ptr %"control value 400", align 1
  call void @llvm.memmove.p0.p0.i64(ptr align 1 %43, ptr align 1 @tower.string.1, i64 6, i1 false)
  store ptr %length, ptr %"control value 401", align 1
  %44 = load ptr, ptr %"control value 401", align 1
  store i64 6, ptr %44, align 1
  br label %if.end6

if.end6:                                          ; preds = %if.else5, %if.body4
  br label %if.end

if.body7:                                         ; preds = %if.else
  %45 = load i32, ptr %pointer_bytes, align 1
  store i32 %45, ptr %"control value 405", align 1
  %46 = load i32, ptr %"control value 405", align 1
  %47 = icmp eq i32 %46, 4
  %48 = zext i1 %47 to i8
  store i8 %48, ptr %"control value 406", align 1
  %49 = load i8, ptr %"control value 406", align 1
  store i8 %49, ptr %valid, align 1
  store ptr %valid, ptr %"control value 407", align 1
  %50 = load ptr, ptr %"control value 407", align 1
  %51 = load i8, ptr %50, align 1
  store i8 %51, ptr %"control value 408", align 1
  %52 = load i8, ptr %"control value 408", align 1
  store i8 %52, ptr %"control value 409", align 1
  %53 = load i8, ptr %"control value 409", align 1
  store i8 %53, ptr %"control value 410", align 1
  %54 = load i8, ptr %"control value 409", align 1
  %55 = icmp ne i8 %54, 0
  br i1 %55, label %if.body10, label %if.else11

if.else8:                                         ; preds = %if.else
  %56 = load i32, ptr %kind, align 1
  store i32 %56, ptr %"control value 440", align 1
  %57 = load i32, ptr %"control value 440", align 1
  %58 = icmp eq i32 %57, 0
  %59 = zext i1 %58 to i8
  store i8 %59, ptr %"control value 441", align 1
  %60 = load i8, ptr %"control value 441", align 1
  store i8 %60, ptr %narrow, align 1
  store i8 0, ptr %negative, align 1
  %61 = load i8, ptr %narrow, align 1
  store i8 %61, ptr %"control value 442", align 1
  %62 = load i8, ptr %"control value 442", align 1
  %63 = icmp ne i8 %62, 0
  br i1 %63, label %if.body24, label %if.else25

if.end9:                                          ; preds = %loop.end48, %loop.end
  %64 = load i64, ptr %length, align 1
  store i64 %64, ptr %"control value 497", align 1
  %65 = load i64, ptr %"control value 497", align 1
  %66 = mul i64 %65, 1
  %67 = getelementptr i8, ptr %buffer, i64 %66
  store ptr %67, ptr %"control value 498", align 1
  %68 = load ptr, ptr %"control value 498", align 1
  store i8 10, ptr %68, align 1
  store ptr %length, ptr %"control value 499", align 1
  %69 = load ptr, ptr %"control value 499", align 1
  %70 = load i64, ptr %69, align 1
  store i64 %70, ptr %"control value 500", align 1
  %71 = load i64, ptr %"control value 500", align 1
  %72 = add i64 %71, 1
  store i64 %72, ptr %"control value 501", align 1
  %73 = load ptr, ptr %"control value 499", align 1
  %74 = load i64, ptr %"control value 501", align 1
  store i64 %74, ptr %73, align 1
  br label %if.end

if.body10:                                        ; preds = %if.body7
  br label %if.end12

if.else11:                                        ; preds = %if.body7
  %75 = load i32, ptr %pointer_bytes, align 1
  store i32 %75, ptr %"control value 411", align 1
  %76 = load i32, ptr %"control value 411", align 1
  %77 = icmp eq i32 %76, 8
  %78 = zext i1 %77 to i8
  store i8 %78, ptr %"control value 412", align 1
  %79 = load i8, ptr %"control value 412", align 1
  store i8 %79, ptr %"control value 410", align 1
  %80 = load ptr, ptr %"control value 407", align 1
  %81 = load i8, ptr %"control value 412", align 1
  store i8 %81, ptr %80, align 1
  br label %if.end12

if.end12:                                         ; preds = %if.else11, %if.body10
  %82 = load i8, ptr %valid, align 1
  store i8 %82, ptr %"control value 413", align 1
  %83 = load i8, ptr %"control value 413", align 1
  %84 = icmp eq i8 0, %83
  %85 = zext i1 %84 to i8
  store i8 %85, ptr %"control value 414", align 1
  %86 = load i8, ptr %"control value 414", align 1
  %87 = icmp ne i8 %86, 0
  br i1 %87, label %if.body13, label %if.else14

if.body13:                                        ; preds = %if.end12
  ret i64 0

if.else14:                                        ; preds = %if.end12
  br label %if.end15

if.end15:                                         ; preds = %if.else14
  %88 = getelementptr i8, ptr %buffer, i64 0
  store ptr %88, ptr %"control value 415", align 1
  %89 = load ptr, ptr %"control value 415", align 1
  store i8 48, ptr %89, align 1
  %90 = getelementptr i8, ptr %buffer, i64 1
  store ptr %90, ptr %"control value 416", align 1
  %91 = load ptr, ptr %"control value 416", align 1
  store i8 120, ptr %91, align 1
  %92 = load i32, ptr %pointer_bytes, align 1
  store i32 %92, ptr %"control value 417", align 1
  %93 = load i32, ptr %"control value 417", align 1
  %94 = zext i32 %93 to i64
  %95 = icmp ule i64 %94, -1
  %96 = and i1 true, %95
  br i1 %96, label %valid16, label %error

valid16:                                          ; preds = %if.end15
  %97 = zext i32 %93 to i64
  store i64 %97, ptr %"control value 418", align 1
  %98 = load i64, ptr %"control value 418", align 1
  %99 = mul i64 %98, 2
  store i64 %99, ptr %"control value 419", align 1
  %100 = load i64, ptr %"control value 419", align 1
  store i64 %100, ptr %digits, align 1
  store ptr %length, ptr %"control value 420", align 1
  %101 = load i64, ptr %digits, align 1
  store i64 %101, ptr %"control value 421", align 1
  %102 = load i64, ptr %"control value 421", align 1
  %103 = add i64 %102, 2
  store i64 %103, ptr %"control value 422", align 1
  %104 = load ptr, ptr %"control value 420", align 1
  %105 = load i64, ptr %"control value 422", align 1
  store i64 %105, ptr %104, align 1
  %106 = load i64, ptr %length, align 1
  store i64 %106, ptr %"control value 423", align 1
  %107 = load i64, ptr %"control value 423", align 1
  store i64 %107, ptr %at, align 1
  store ptr @tower.string.2, ptr %hex, align 1
  br label %loop

error:                                            ; preds = %if.end15
  call void @tower_trap(ptr @4, i64 19028)
  unreachable

loop:                                             ; preds = %valid22, %valid16
  %108 = load i64, ptr %at, align 1
  store i64 %108, ptr %"control value 424", align 1
  %109 = load i64, ptr %"control value 424", align 1
  %110 = icmp eq i64 %109, 2
  %111 = zext i1 %110 to i8
  store i8 %111, ptr %"control value 425", align 1
  %112 = load i8, ptr %"control value 425", align 1
  store i8 %112, ptr %done, align 1
  %113 = load i8, ptr %done, align 1
  store i8 %113, ptr %"control value 426", align 1
  %114 = load i8, ptr %"control value 426", align 1
  %115 = icmp ne i8 %114, 0
  br i1 %115, label %if.body17, label %if.else18

loop.end:                                         ; preds = %if.body17
  br label %if.end9

if.body17:                                        ; preds = %loop
  br label %loop.end

if.else18:                                        ; preds = %loop
  br label %if.end19

if.end19:                                         ; preds = %if.else18
  store ptr %at, ptr %"control value 427", align 1
  %116 = load ptr, ptr %"control value 427", align 1
  %117 = load i64, ptr %116, align 1
  store i64 %117, ptr %"control value 428", align 1
  %118 = load i64, ptr %"control value 428", align 1
  %119 = sub i64 %118, 1
  store i64 %119, ptr %"control value 429", align 1
  %120 = load ptr, ptr %"control value 427", align 1
  %121 = load i64, ptr %"control value 429", align 1
  store i64 %121, ptr %120, align 1
  %122 = load i64, ptr %value, align 1
  store i64 %122, ptr %"control value 430", align 1
  %123 = load i64, ptr %"control value 430", align 1
  br i1 true, label %valid20, label %error21

valid20:                                          ; preds = %if.end19
  %124 = urem i64 %123, 16
  store i64 %124, ptr %"control value 431", align 1
  %125 = load i64, ptr %"control value 431", align 1
  store i64 %125, ptr %index, align 1
  %126 = load i64, ptr %at, align 1
  store i64 %126, ptr %"control value 432", align 1
  %127 = load i64, ptr %"control value 432", align 1
  %128 = mul i64 %127, 1
  %129 = getelementptr i8, ptr %buffer, i64 %128
  store ptr %129, ptr %"control value 433", align 1
  %130 = load ptr, ptr %hex, align 1
  store ptr %130, ptr %"control value 434", align 1
  %131 = load i64, ptr %index, align 1
  store i64 %131, ptr %"control value 435", align 1
  %132 = load ptr, ptr %"control value 434", align 1
  %133 = load i64, ptr %"control value 435", align 1
  %134 = mul i64 %133, 1
  %135 = getelementptr i8, ptr %132, i64 %134
  %136 = load i8, ptr %135, align 1
  store i8 %136, ptr %"control value 436", align 1
  %137 = load ptr, ptr %"control value 433", align 1
  %138 = load i8, ptr %"control value 436", align 1
  store i8 %138, ptr %137, align 1
  store ptr %value, ptr %"control value 437", align 1
  %139 = load i64, ptr %value, align 1
  store i64 %139, ptr %"control value 438", align 1
  %140 = load i64, ptr %"control value 438", align 1
  br i1 true, label %valid22, label %error23

error21:                                          ; preds = %if.end19
  call void @tower_trap(ptr @5, i64 19028)
  unreachable

valid22:                                          ; preds = %valid20
  %141 = udiv i64 %140, 16
  store i64 %141, ptr %"control value 439", align 1
  %142 = load ptr, ptr %"control value 437", align 1
  %143 = load i64, ptr %"control value 439", align 1
  store i64 %143, ptr %142, align 1
  br label %loop

error23:                                          ; preds = %valid20
  call void @tower_trap(ptr @6, i64 19028)
  unreachable

if.body24:                                        ; preds = %if.else8
  store ptr %value, ptr %"control value 443", align 1
  %144 = load i64, ptr %value, align 1
  store i64 %144, ptr %"control value 444", align 1
  %145 = load i64, ptr %"control value 444", align 1
  %146 = and i64 %145, 4294967295
  store i64 %146, ptr %"control value 445", align 1
  %147 = load ptr, ptr %"control value 443", align 1
  %148 = load i64, ptr %"control value 445", align 1
  store i64 %148, ptr %147, align 1
  store ptr %negative, ptr %"control value 446", align 1
  %149 = load i64, ptr %value, align 1
  store i64 %149, ptr %"control value 447", align 1
  %150 = load i64, ptr %"control value 447", align 1
  %151 = icmp uge i64 %150, 2147483648
  %152 = zext i1 %151 to i8
  store i8 %152, ptr %"control value 448", align 1
  %153 = load ptr, ptr %"control value 446", align 1
  %154 = load i8, ptr %"control value 448", align 1
  store i8 %154, ptr %153, align 1
  br label %if.end26

if.else25:                                        ; preds = %if.else8
  %155 = load i32, ptr %kind, align 1
  store i32 %155, ptr %"control value 449", align 1
  %156 = load i32, ptr %"control value 449", align 1
  %157 = icmp eq i32 %156, 6
  %158 = zext i1 %157 to i8
  store i8 %158, ptr %"control value 450", align 1
  %159 = load i8, ptr %"control value 450", align 1
  store i8 %159, ptr %signed, align 1
  %160 = load i8, ptr %signed, align 1
  store i8 %160, ptr %"control value 451", align 1
  %161 = load i8, ptr %"control value 451", align 1
  %162 = icmp ne i8 %161, 0
  br i1 %162, label %if.body27, label %if.else28

if.end26:                                         ; preds = %if.end29, %if.body24
  %163 = load i8, ptr %negative, align 1
  store i8 %163, ptr %"control value 455", align 1
  %164 = load i8, ptr %"control value 455", align 1
  %165 = icmp ne i8 %164, 0
  br i1 %165, label %if.body30, label %if.else31

if.body27:                                        ; preds = %if.else25
  store ptr %negative, ptr %"control value 452", align 1
  %166 = load i64, ptr %value, align 1
  store i64 %166, ptr %"control value 453", align 1
  %167 = load i64, ptr %"control value 453", align 1
  %168 = icmp uge i64 %167, -9223372036854775808
  %169 = zext i1 %168 to i8
  store i8 %169, ptr %"control value 454", align 1
  %170 = load ptr, ptr %"control value 452", align 1
  %171 = load i8, ptr %"control value 454", align 1
  store i8 %171, ptr %170, align 1
  br label %if.end29

if.else28:                                        ; preds = %if.else25
  br label %if.end29

if.end29:                                         ; preds = %if.else28, %if.body27
  br label %if.end26

if.body30:                                        ; preds = %if.end26
  %172 = getelementptr i8, ptr %buffer, i64 0
  store ptr %172, ptr %"control value 456", align 1
  %173 = load ptr, ptr %"control value 456", align 1
  store i8 45, ptr %173, align 1
  store ptr %length, ptr %"control value 457", align 1
  %174 = load ptr, ptr %"control value 457", align 1
  store i64 1, ptr %174, align 1
  store i64 0, ptr %zero, align 1
  store ptr %value, ptr %"control value 458", align 1
  %175 = load i64, ptr %zero, align 1
  store i64 %175, ptr %"control value 459", align 1
  %176 = load i64, ptr %value, align 1
  store i64 %176, ptr %"control value 460", align 1
  %177 = load i64, ptr %"control value 459", align 1
  %178 = load i64, ptr %"control value 460", align 1
  %179 = sub i64 %177, %178
  store i64 %179, ptr %"control value 461", align 1
  %180 = load ptr, ptr %"control value 458", align 1
  %181 = load i64, ptr %"control value 461", align 1
  store i64 %181, ptr %180, align 1
  %182 = load i8, ptr %narrow, align 1
  store i8 %182, ptr %"control value 462", align 1
  %183 = load i8, ptr %"control value 462", align 1
  %184 = icmp ne i8 %183, 0
  br i1 %184, label %if.body33, label %if.else34

if.else31:                                        ; preds = %if.end26
  br label %if.end32

if.end32:                                         ; preds = %if.end35, %if.else31
  store i64 0, ptr %count, align 1
  br label %loop36

if.body33:                                        ; preds = %if.body30
  store ptr %value, ptr %"control value 463", align 1
  %185 = load i64, ptr %value, align 1
  store i64 %185, ptr %"control value 464", align 1
  %186 = load i64, ptr %"control value 464", align 1
  %187 = and i64 %186, 4294967295
  store i64 %187, ptr %"control value 465", align 1
  %188 = load ptr, ptr %"control value 463", align 1
  %189 = load i64, ptr %"control value 465", align 1
  store i64 %189, ptr %188, align 1
  br label %if.end35

if.else34:                                        ; preds = %if.body30
  br label %if.end35

if.end35:                                         ; preds = %if.else34, %if.body33
  br label %if.end32

loop36:                                           ; preds = %if.end46, %if.end32
  %190 = load i64, ptr %value, align 1
  store i64 %190, ptr %"control value 466", align 1
  %191 = load i64, ptr %"control value 466", align 1
  br i1 true, label %valid38, label %error39

loop.end37:                                       ; preds = %if.body44
  br label %loop47

valid38:                                          ; preds = %loop36
  %192 = urem i64 %191, 10
  store i64 %192, ptr %"control value 467", align 1
  %193 = load i64, ptr %"control value 467", align 1
  store i64 %193, ptr %digit, align 1
  store ptr %digit, ptr %"control value 468", align 1
  %194 = load i64, ptr %digit, align 1
  store i64 %194, ptr %"control value 469", align 1
  %195 = load i64, ptr %"control value 469", align 1
  %196 = add i64 %195, 48
  store i64 %196, ptr %"control value 470", align 1
  %197 = load ptr, ptr %"control value 468", align 1
  %198 = load i64, ptr %"control value 470", align 1
  store i64 %198, ptr %197, align 1
  %199 = load i64, ptr %count, align 1
  store i64 %199, ptr %"control value 471", align 1
  %200 = load i64, ptr %"control value 471", align 1
  %201 = mul i64 %200, 1
  %202 = getelementptr i8, ptr %digits1, i64 %201
  store ptr %202, ptr %"control value 472", align 1
  %203 = load i64, ptr %digit, align 1
  store i64 %203, ptr %"control value 473", align 1
  %204 = load i64, ptr %"control value 473", align 1
  %205 = icmp ule i64 %204, 255
  %206 = and i1 true, %205
  br i1 %206, label %valid40, label %error41

error39:                                          ; preds = %loop36
  call void @tower_trap(ptr @7, i64 19028)
  unreachable

valid40:                                          ; preds = %valid38
  %207 = trunc i64 %204 to i8
  store i8 %207, ptr %"control value 474", align 1
  %208 = load ptr, ptr %"control value 472", align 1
  %209 = load i8, ptr %"control value 474", align 1
  store i8 %209, ptr %208, align 1
  store ptr %count, ptr %"control value 475", align 1
  %210 = load ptr, ptr %"control value 475", align 1
  %211 = load i64, ptr %210, align 1
  store i64 %211, ptr %"control value 476", align 1
  %212 = load i64, ptr %"control value 476", align 1
  %213 = add i64 %212, 1
  store i64 %213, ptr %"control value 477", align 1
  %214 = load ptr, ptr %"control value 475", align 1
  %215 = load i64, ptr %"control value 477", align 1
  store i64 %215, ptr %214, align 1
  store ptr %value, ptr %"control value 478", align 1
  %216 = load i64, ptr %value, align 1
  store i64 %216, ptr %"control value 479", align 1
  %217 = load i64, ptr %"control value 479", align 1
  br i1 true, label %valid42, label %error43

error41:                                          ; preds = %valid38
  call void @tower_trap(ptr @8, i64 19028)
  unreachable

valid42:                                          ; preds = %valid40
  %218 = udiv i64 %217, 10
  store i64 %218, ptr %"control value 480", align 1
  %219 = load ptr, ptr %"control value 478", align 1
  %220 = load i64, ptr %"control value 480", align 1
  store i64 %220, ptr %219, align 1
  %221 = load i64, ptr %value, align 1
  store i64 %221, ptr %"control value 481", align 1
  %222 = load i64, ptr %"control value 481", align 1
  %223 = icmp eq i64 %222, 0
  %224 = zext i1 %223 to i8
  store i8 %224, ptr %"control value 482", align 1
  %225 = load i8, ptr %"control value 482", align 1
  store i8 %225, ptr %done2, align 1
  %226 = load i8, ptr %done2, align 1
  store i8 %226, ptr %"control value 483", align 1
  %227 = load i8, ptr %"control value 483", align 1
  %228 = icmp ne i8 %227, 0
  br i1 %228, label %if.body44, label %if.else45

error43:                                          ; preds = %valid40
  call void @tower_trap(ptr @9, i64 19028)
  unreachable

if.body44:                                        ; preds = %valid42
  br label %loop.end37

if.else45:                                        ; preds = %valid42
  br label %if.end46

if.end46:                                         ; preds = %if.else45
  br label %loop36

loop47:                                           ; preds = %if.end51, %loop.end37
  %229 = load i64, ptr %count, align 1
  store i64 %229, ptr %"control value 484", align 1
  %230 = load i64, ptr %"control value 484", align 1
  %231 = icmp eq i64 %230, 0
  %232 = zext i1 %231 to i8
  store i8 %232, ptr %"control value 485", align 1
  %233 = load i8, ptr %"control value 485", align 1
  store i8 %233, ptr %done3, align 1
  %234 = load i8, ptr %done3, align 1
  store i8 %234, ptr %"control value 486", align 1
  %235 = load i8, ptr %"control value 486", align 1
  %236 = icmp ne i8 %235, 0
  br i1 %236, label %if.body49, label %if.else50

loop.end48:                                       ; preds = %if.body49
  br label %if.end9

if.body49:                                        ; preds = %loop47
  br label %loop.end48

if.else50:                                        ; preds = %loop47
  br label %if.end51

if.end51:                                         ; preds = %if.else50
  store ptr %count, ptr %"control value 487", align 1
  %237 = load ptr, ptr %"control value 487", align 1
  %238 = load i64, ptr %237, align 1
  store i64 %238, ptr %"control value 488", align 1
  %239 = load i64, ptr %"control value 488", align 1
  %240 = sub i64 %239, 1
  store i64 %240, ptr %"control value 489", align 1
  %241 = load ptr, ptr %"control value 487", align 1
  %242 = load i64, ptr %"control value 489", align 1
  store i64 %242, ptr %241, align 1
  %243 = load i64, ptr %length, align 1
  store i64 %243, ptr %"control value 490", align 1
  %244 = load i64, ptr %"control value 490", align 1
  %245 = mul i64 %244, 1
  %246 = getelementptr i8, ptr %buffer, i64 %245
  store ptr %246, ptr %"control value 491", align 1
  %247 = load i64, ptr %count, align 1
  store i64 %247, ptr %"control value 492", align 1
  %248 = load i64, ptr %"control value 492", align 1
  %249 = mul i64 %248, 1
  %250 = getelementptr i8, ptr %digits1, i64 %249
  %251 = load i8, ptr %250, align 1
  store i8 %251, ptr %"control value 493", align 1
  %252 = load ptr, ptr %"control value 491", align 1
  %253 = load i8, ptr %"control value 493", align 1
  store i8 %253, ptr %252, align 1
  store ptr %length, ptr %"control value 494", align 1
  %254 = load ptr, ptr %"control value 494", align 1
  %255 = load i64, ptr %254, align 1
  store i64 %255, ptr %"control value 495", align 1
  %256 = load i64, ptr %"control value 495", align 1
  %257 = add i64 %256, 1
  store i64 %257, ptr %"control value 496", align 1
  %258 = load ptr, ptr %"control value 494", align 1
  %259 = load i64, ptr %"control value 496", align 1
  store i64 %259, ptr %258, align 1
  br label %loop47

if.body52:                                        ; preds = %if.end
  %260 = load ptr, ptr %output, align 1
  store ptr %260, ptr %"control value 506", align 1
  %261 = getelementptr i8, ptr %buffer, i64 0
  store ptr %261, ptr %"control value 507", align 1
  %262 = load i64, ptr %length, align 1
  store i64 %262, ptr %"control value 508", align 1
  %263 = load ptr, ptr %"control value 506", align 1
  %264 = load ptr, ptr %"control value 507", align 1
  %265 = load i64, ptr %"control value 508", align 1
  call void @llvm.memmove.p0.p0.i64(ptr align 1 %263, ptr align 1 %264, i64 %265, i1 false)
  %266 = load i64, ptr %length, align 1
  store i64 %266, ptr %"control value 509", align 1
  %267 = load i64, ptr %"control value 509", align 1
  ret i64 %267

if.else53:                                        ; preds = %if.end
  br label %if.end54

if.end54:                                         ; preds = %if.else53
  ret i64 0
}

define zeroext i8 @runtime_write_all(i32 %0, ptr %1, i64 %2) {
entry:
  %stream = alloca i32, align 4
  %data = alloca ptr, align 8
  %length = alloca i64, align 8
  %valid = alloca i8, align 1
  %at = alloca i64, align 8
  %done = alloca i8, align 1
  %remaining = alloca i64, align 8
  %written = alloca i64, align 8
  %failed = alloca i8, align 1
  %count = alloca i64, align 8
  %invalid = alloca i8, align 1
  %"control value 510" = alloca i32, align 4
  %"control value 511" = alloca i8, align 1
  %"control value 512" = alloca ptr, align 8
  %"control value 513" = alloca i8, align 1
  %"control value 514" = alloca i8, align 1
  %"control value 515" = alloca i8, align 1
  %"control value 516" = alloca i32, align 4
  %"control value 517" = alloca i8, align 1
  %"control value 518" = alloca i8, align 1
  %"control value 519" = alloca i8, align 1
  %"control value 520" = alloca i64, align 8
  %"control value 521" = alloca i64, align 8
  %"control value 522" = alloca i8, align 1
  %"control value 523" = alloca i8, align 1
  %"control value 524" = alloca i64, align 8
  %"control value 525" = alloca i64, align 8
  %"control value 526" = alloca i64, align 8
  %"control value 527" = alloca i32, align 4
  %"control value 528" = alloca ptr, align 8
  %"control value 529" = alloca i64, align 8
  %"control value 530" = alloca ptr, align 8
  %"control value 531" = alloca i64, align 8
  %"control value 532" = alloca i64, align 8
  %"control value 533" = alloca i64, align 8
  %"control value 534" = alloca i8, align 1
  %"control value 535" = alloca i8, align 1
  %"control value 536" = alloca i64, align 8
  %"control value 537" = alloca i64, align 8
  %"control value 538" = alloca i64, align 8
  %"control value 539" = alloca i64, align 8
  %"control value 540" = alloca i64, align 8
  %"control value 541" = alloca i8, align 1
  %"control value 542" = alloca i8, align 1
  %"control value 543" = alloca ptr, align 8
  %"control value 544" = alloca i64, align 8
  %"control value 545" = alloca i64, align 8
  %"control value 546" = alloca i64, align 8
  %"control value 547" = alloca i64, align 8
  store i32 %0, ptr %stream, align 1
  store ptr %1, ptr %data, align 1
  store i64 %2, ptr %length, align 1
  %3 = load i32, ptr %stream, align 1
  store i32 %3, ptr %"control value 510", align 1
  %4 = load i32, ptr %"control value 510", align 1
  %5 = icmp eq i32 %4, 1
  %6 = zext i1 %5 to i8
  store i8 %6, ptr %"control value 511", align 1
  %7 = load i8, ptr %"control value 511", align 1
  store i8 %7, ptr %valid, align 1
  store ptr %valid, ptr %"control value 512", align 1
  %8 = load ptr, ptr %"control value 512", align 1
  %9 = load i8, ptr %8, align 1
  store i8 %9, ptr %"control value 513", align 1
  %10 = load i8, ptr %"control value 513", align 1
  store i8 %10, ptr %"control value 514", align 1
  %11 = load i8, ptr %"control value 514", align 1
  store i8 %11, ptr %"control value 515", align 1
  %12 = load i8, ptr %"control value 514", align 1
  %13 = icmp ne i8 %12, 0
  br i1 %13, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  br label %if.end

if.else:                                          ; preds = %entry
  %14 = load i32, ptr %stream, align 1
  store i32 %14, ptr %"control value 516", align 1
  %15 = load i32, ptr %"control value 516", align 1
  %16 = icmp eq i32 %15, 2
  %17 = zext i1 %16 to i8
  store i8 %17, ptr %"control value 517", align 1
  %18 = load i8, ptr %"control value 517", align 1
  store i8 %18, ptr %"control value 515", align 1
  %19 = load ptr, ptr %"control value 512", align 1
  %20 = load i8, ptr %"control value 517", align 1
  store i8 %20, ptr %19, align 1
  br label %if.end

if.end:                                           ; preds = %if.else, %if.body
  %21 = load i8, ptr %valid, align 1
  store i8 %21, ptr %"control value 518", align 1
  %22 = load i8, ptr %"control value 518", align 1
  %23 = icmp eq i8 0, %22
  %24 = zext i1 %23 to i8
  store i8 %24, ptr %"control value 519", align 1
  %25 = load i8, ptr %"control value 519", align 1
  %26 = icmp ne i8 %25, 0
  br i1 %26, label %if.body1, label %if.else2

if.body1:                                         ; preds = %if.end
  ret i8 0

if.else2:                                         ; preds = %if.end
  br label %if.end3

if.end3:                                          ; preds = %if.else2
  store i64 0, ptr %at, align 1
  br label %loop

loop:                                             ; preds = %valid16, %if.end3
  %27 = load i64, ptr %at, align 1
  store i64 %27, ptr %"control value 520", align 1
  %28 = load i64, ptr %length, align 1
  store i64 %28, ptr %"control value 521", align 1
  %29 = load i64, ptr %"control value 520", align 1
  %30 = load i64, ptr %"control value 521", align 1
  %31 = icmp eq i64 %29, %30
  %32 = zext i1 %31 to i8
  store i8 %32, ptr %"control value 522", align 1
  %33 = load i8, ptr %"control value 522", align 1
  store i8 %33, ptr %done, align 1
  %34 = load i8, ptr %done, align 1
  store i8 %34, ptr %"control value 523", align 1
  %35 = load i8, ptr %"control value 523", align 1
  %36 = icmp ne i8 %35, 0
  br i1 %36, label %if.body4, label %if.else5

loop.end:                                         ; No predecessors!
  unreachable

if.body4:                                         ; preds = %loop
  ret i8 1

if.else5:                                         ; preds = %loop
  br label %if.end6

if.end6:                                          ; preds = %if.else5
  %37 = load i64, ptr %length, align 1
  store i64 %37, ptr %"control value 524", align 1
  %38 = load i64, ptr %at, align 1
  store i64 %38, ptr %"control value 525", align 1
  %39 = load i64, ptr %"control value 524", align 1
  %40 = load i64, ptr %"control value 525", align 1
  %41 = sub i64 %39, %40
  store i64 %41, ptr %"control value 526", align 1
  %42 = load i64, ptr %"control value 526", align 1
  store i64 %42, ptr %remaining, align 1
  %43 = load i32, ptr %stream, align 1
  store i32 %43, ptr %"control value 527", align 1
  %44 = load ptr, ptr %data, align 1
  store ptr %44, ptr %"control value 528", align 1
  %45 = load i64, ptr %at, align 1
  store i64 %45, ptr %"control value 529", align 1
  %46 = load ptr, ptr %"control value 528", align 1
  %47 = load i64, ptr %"control value 529", align 1
  %48 = mul i64 %47, 1
  %49 = getelementptr i8, ptr %46, i64 %48
  store ptr %49, ptr %"control value 530", align 1
  %50 = load i64, ptr %remaining, align 1
  store i64 %50, ptr %"control value 531", align 1
  %51 = load i32, ptr %"control value 527", align 1
  %52 = load ptr, ptr %"control value 530", align 1
  %53 = load i64, ptr %"control value 531", align 1
  %54 = call i64 @platform_write(i32 %51, ptr %52, i64 %53)
  store i64 %54, ptr %"control value 532", align 1
  %55 = load i64, ptr %"control value 532", align 1
  store i64 %55, ptr %written, align 1
  %56 = load i64, ptr %written, align 1
  store i64 %56, ptr %"control value 533", align 1
  %57 = load i64, ptr %"control value 533", align 1
  %58 = icmp sle i64 %57, 0
  %59 = zext i1 %58 to i8
  store i8 %59, ptr %"control value 534", align 1
  %60 = load i8, ptr %"control value 534", align 1
  store i8 %60, ptr %failed, align 1
  %61 = load i8, ptr %failed, align 1
  store i8 %61, ptr %"control value 535", align 1
  %62 = load i8, ptr %"control value 535", align 1
  %63 = icmp ne i8 %62, 0
  br i1 %63, label %if.body7, label %if.else8

if.body7:                                         ; preds = %if.end6
  ret i8 0

if.else8:                                         ; preds = %if.end6
  br label %if.end9

if.end9:                                          ; preds = %if.else8
  %64 = load i64, ptr %written, align 1
  store i64 %64, ptr %"control value 536", align 1
  %65 = load i64, ptr %"control value 536", align 1
  %66 = icmp sge i64 %65, 0
  %67 = icmp ule i64 %65, -1
  %68 = and i1 %66, %67
  br i1 %68, label %valid10, label %error

valid10:                                          ; preds = %if.end9
  store i64 %65, ptr %"control value 537", align 1
  %69 = load i64, ptr %"control value 537", align 1
  store i64 %69, ptr %count, align 1
  %70 = load i64, ptr %count, align 1
  store i64 %70, ptr %"control value 538", align 1
  %71 = load i64, ptr %remaining, align 1
  store i64 %71, ptr %"control value 539", align 1
  %72 = load i64, ptr %"control value 539", align 1
  %73 = icmp ule i64 %72, -1
  %74 = and i1 true, %73
  br i1 %74, label %valid11, label %error12

error:                                            ; preds = %if.end9
  call void @tower_trap(ptr @10, i64 19028)
  unreachable

valid11:                                          ; preds = %valid10
  store i64 %72, ptr %"control value 540", align 1
  %75 = load i64, ptr %"control value 538", align 1
  %76 = load i64, ptr %"control value 540", align 1
  %77 = icmp ugt i64 %75, %76
  %78 = zext i1 %77 to i8
  store i8 %78, ptr %"control value 541", align 1
  %79 = load i8, ptr %"control value 541", align 1
  store i8 %79, ptr %invalid, align 1
  %80 = load i8, ptr %invalid, align 1
  store i8 %80, ptr %"control value 542", align 1
  %81 = load i8, ptr %"control value 542", align 1
  %82 = icmp ne i8 %81, 0
  br i1 %82, label %if.body13, label %if.else14

error12:                                          ; preds = %valid10
  call void @tower_trap(ptr @11, i64 19028)
  unreachable

if.body13:                                        ; preds = %valid11
  ret i8 0

if.else14:                                        ; preds = %valid11
  br label %if.end15

if.end15:                                         ; preds = %if.else14
  store ptr %at, ptr %"control value 543", align 1
  %83 = load i64, ptr %at, align 1
  store i64 %83, ptr %"control value 544", align 1
  %84 = load i64, ptr %count, align 1
  store i64 %84, ptr %"control value 545", align 1
  %85 = load i64, ptr %"control value 545", align 1
  %86 = icmp ule i64 %85, -1
  %87 = and i1 true, %86
  br i1 %87, label %valid16, label %error17

valid16:                                          ; preds = %if.end15
  store i64 %85, ptr %"control value 546", align 1
  %88 = load i64, ptr %"control value 544", align 1
  %89 = load i64, ptr %"control value 546", align 1
  %90 = add i64 %88, %89
  store i64 %90, ptr %"control value 547", align 1
  %91 = load ptr, ptr %"control value 543", align 1
  %92 = load i64, ptr %"control value 547", align 1
  store i64 %92, ptr %91, align 1
  br label %loop

error17:                                          ; preds = %if.end15
  call void @tower_trap(ptr @12, i64 19028)
  unreachable
}

define zeroext i8 @runtime_print_value(i32 %0, i64 %1, i32 %2) {
entry:
  %kind = alloca i32, align 4
  %value = alloca i64, align 8
  %pointer_bytes = alloca i32, align 4
  %buffer = alloca [80 x i8], align 1
  %length = alloca i64, align 8
  %invalid = alloca i8, align 1
  %"control value 548" = alloca ptr, align 8
  %"control value 549" = alloca i32, align 4
  %"control value 550" = alloca i64, align 8
  %"control value 551" = alloca i32, align 4
  %"control value 552" = alloca i64, align 8
  %"control value 553" = alloca i64, align 8
  %"control value 554" = alloca i8, align 1
  %"control value 555" = alloca i8, align 1
  %"control value 556" = alloca ptr, align 8
  %"control value 557" = alloca i64, align 8
  %"control value 558" = alloca i8, align 1
  store i32 %0, ptr %kind, align 1
  store i64 %1, ptr %value, align 1
  store i32 %2, ptr %pointer_bytes, align 1
  %3 = getelementptr i8, ptr %buffer, i64 0
  store ptr %3, ptr %"control value 548", align 1
  %4 = load i32, ptr %kind, align 1
  store i32 %4, ptr %"control value 549", align 1
  %5 = load i64, ptr %value, align 1
  store i64 %5, ptr %"control value 550", align 1
  %6 = load i32, ptr %pointer_bytes, align 1
  store i32 %6, ptr %"control value 551", align 1
  %7 = load ptr, ptr %"control value 548", align 1
  %8 = load i32, ptr %"control value 549", align 1
  %9 = load i64, ptr %"control value 550", align 1
  %10 = load i32, ptr %"control value 551", align 1
  %11 = call i64 @runtime_format_value(ptr %7, i64 80, i32 %8, i64 %9, i32 %10)
  store i64 %11, ptr %"control value 552", align 1
  %12 = load i64, ptr %"control value 552", align 1
  store i64 %12, ptr %length, align 1
  %13 = load i64, ptr %length, align 1
  store i64 %13, ptr %"control value 553", align 1
  %14 = load i64, ptr %"control value 553", align 1
  %15 = icmp eq i64 %14, 0
  %16 = zext i1 %15 to i8
  store i8 %16, ptr %"control value 554", align 1
  %17 = load i8, ptr %"control value 554", align 1
  store i8 %17, ptr %invalid, align 1
  %18 = load i8, ptr %invalid, align 1
  store i8 %18, ptr %"control value 555", align 1
  %19 = load i8, ptr %"control value 555", align 1
  %20 = icmp ne i8 %19, 0
  br i1 %20, label %if.body, label %if.else

if.body:                                          ; preds = %entry
  ret i8 0

if.else:                                          ; preds = %entry
  br label %if.end

if.end:                                           ; preds = %if.else
  %21 = getelementptr i8, ptr %buffer, i64 0
  store ptr %21, ptr %"control value 556", align 1
  %22 = load i64, ptr %length, align 1
  store i64 %22, ptr %"control value 557", align 1
  %23 = load ptr, ptr %"control value 556", align 1
  %24 = load i64, ptr %"control value 557", align 1
  %25 = call zeroext i8 @runtime_write_all(i32 1, ptr %23, i64 %24)
  store i8 %25, ptr %"control value 558", align 1
  %26 = load i8, ptr %"control value 558", align 1
  ret i8 %26
}

define void @tower_print(i32 %0, i64 %1, i32 %2) {
entry:
  %kind = alloca i32, align 4
  %value = alloca i64, align 8
  %pointer_bytes = alloca i32, align 4
  %"control value 559" = alloca i32, align 4
  %"control value 560" = alloca i64, align 8
  %"control value 561" = alloca i32, align 4
  %"control value 562" = alloca i8, align 1
  store i32 %0, ptr %kind, align 1
  store i64 %1, ptr %value, align 1
  store i32 %2, ptr %pointer_bytes, align 1
  %3 = load i32, ptr %kind, align 1
  store i32 %3, ptr %"control value 559", align 1
  %4 = load i64, ptr %value, align 1
  store i64 %4, ptr %"control value 560", align 1
  %5 = load i32, ptr %pointer_bytes, align 1
  store i32 %5, ptr %"control value 561", align 1
  %6 = load i32, ptr %"control value 559", align 1
  %7 = load i64, ptr %"control value 560", align 1
  %8 = load i32, ptr %"control value 561", align 1
  %9 = call zeroext i8 @runtime_print_value(i32 %6, i64 %7, i32 %8)
  store i8 %9, ptr %"control value 562", align 1
  ret void
}

define void @tower_trap(ptr %0, i64 %1) {
entry:
  %message = alloca ptr, align 8
  %offset = alloca i64, align 8
  %length = alloca i64, align 8
  %"control value 173" = alloca i8, align 1
  %"control value 563" = alloca ptr, align 8
  %"control value 564" = alloca i64, align 8
  %"control value 565" = alloca i8, align 1
  %"control value 566" = alloca i8, align 1
  %"control value 567" = alloca i8, align 1
  %"control value 568" = alloca ptr, align 8
  %"control value 569" = alloca i64, align 8
  %"control value 570" = alloca i64, align 8
  %"control value 571" = alloca ptr, align 8
  %"control value 572" = alloca i64, align 8
  %"control value 573" = alloca i8, align 1
  %"control value 574" = alloca i8, align 1
  store ptr %0, ptr %message, align 1
  store i64 %1, ptr %offset, align 1
  store i64 0, ptr %length, align 1
  br label %loop

loop:                                             ; preds = %if.end, %entry
  %2 = load ptr, ptr %message, align 1
  store ptr %2, ptr %"control value 563", align 1
  %3 = load i64, ptr %length, align 1
  store i64 %3, ptr %"control value 564", align 1
  %4 = load ptr, ptr %"control value 563", align 1
  %5 = load i64, ptr %"control value 564", align 1
  %6 = mul i64 %5, 1
  %7 = getelementptr i8, ptr %4, i64 %6
  %8 = load i8, ptr %7, align 1
  store i8 %8, ptr %"control value 565", align 1
  %9 = load i8, ptr %"control value 565", align 1
  %10 = icmp ne i8 %9, 0
  %11 = zext i1 %10 to i8
  store i8 %11, ptr %"control value 566", align 1
  %12 = load i8, ptr %"control value 566", align 1
  store i8 %12, ptr %"control value 173", align 1
  %13 = load i8, ptr %"control value 173", align 1
  store i8 %13, ptr %"control value 567", align 1
  %14 = load i8, ptr %"control value 567", align 1
  %15 = icmp ne i8 %14, 0
  br i1 %15, label %if.body, label %if.else

loop.end:                                         ; preds = %if.else
  %16 = load ptr, ptr %message, align 1
  store ptr %16, ptr %"control value 571", align 1
  %17 = load i64, ptr %length, align 1
  store i64 %17, ptr %"control value 572", align 1
  %18 = load ptr, ptr %"control value 571", align 1
  %19 = load i64, ptr %"control value 572", align 1
  %20 = call zeroext i8 @runtime_write_all(i32 2, ptr %18, i64 %19)
  store i8 %20, ptr %"control value 573", align 1
  %21 = call zeroext i8 @runtime_write_all(i32 2, ptr @tower.string.3, i64 1)
  store i8 %21, ptr %"control value 574", align 1
  call void @guest_exit(i32 1)
  ret void

if.body:                                          ; preds = %loop
  store ptr %length, ptr %"control value 568", align 1
  %22 = load ptr, ptr %"control value 568", align 1
  %23 = load i64, ptr %22, align 1
  store i64 %23, ptr %"control value 569", align 1
  %24 = load i64, ptr %"control value 569", align 1
  %25 = add i64 %24, 1
  store i64 %25, ptr %"control value 570", align 1
  %26 = load ptr, ptr %"control value 568", align 1
  %27 = load i64, ptr %"control value 570", align 1
  store i64 %27, ptr %26, align 1
  br label %if.end

if.else:                                          ; preds = %loop
  br label %loop.end

if.end:                                           ; preds = %if.body
  br label %loop
}

declare void @tower_main()

define void @tower_start() {
entry:
  call void @tower_main()
  call void @guest_exit(i32 0)
  ret void
}

define i32 @guest_runtime_main() {
entry:
  call void @tower_main()
  ret i32 0
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memmove.p0.p0.i64(ptr nocapture writeonly, ptr nocapture readonly, i64, i1 immarg) #0

; Function Attrs: naked
define void @_start() #1 {
entry:
  call void asm sideeffect "bl tower_start", ""()
  unreachable
}

attributes #0 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #1 = { naked }
