# Original D1 ThreadSanitizer ELF on Vast slot 6

Both requested invocations passed once with the producer's 180-second bound.
The archived executable was extracted from bin/thread-tower-lr-work-tests.
Its SHA-256 before and after execution was
`f3171a3e4a294098c4665b6bd7adac160251e8a859f085dc4337cc40acc32bbf`.
The producer archive SHA-256 was
`41aeba4281e6136b842335cf65282b47ab112ea3809cb70885da2bf268133663`.
All 440 entries verified. The original 39-entry LR manifest (SHA-256
`3d496f4d6bcab754ee870c05be2551f2d9ea8905791ad587f797ee82f4c23d59`)
verifies on base 12ab4cae. The full 1,232-entry scaffolding manifest verifies
after applying the producer patch that yields fixture blob 2fb874d3. See
the two scaffolding checks for the post-patch bytes before/after execution.

| Selection | Exit | Wall s | CPU s | Peak RSS KiB | Checked output |
| --- | ---: | ---: | ---: | ---: | --- |
| lr-bounded | 0 | 0.20 | 0.22 | 105,212 | Empty stdout and stderr, including the extended two-lane action-row refusal and retry checks. |
| lr | 0 | 74.66 | 252.74 | 1,971,636 | Exact worker-policy success line with empty stderr. |

The slot had CPUs 0–11, quota 11.52 CPUs, memory cap 32,282,509,312 B and
zero swap. No CPU throttling, OOM events, startup failures, timeouts, skips
or sanitizer reports occurred. The largest whole-slot memory.current sample
was 10,085,580,800 B. The kernel lacks memory.peak. These single process
measurements cover the executed native Linux x64 selectors.

The two producer attempts are preserved in producer/thread_*. Each exited
139 during TSan's personality check before test entry. The manager recorded
a bounded pass and a 120-second full-LR timeout on its host. Slot 6 previously
tested rebuilt module-enabled LR binaries 2160f9a4 and 8c1f383a. This replay
exercised the module-tests-off producer binary directly. Its LR test object
had the same hash as in the rebuilt frozen runner, with a different parser
provider and ELF. Only the two requested selectors ran.

Read each .command, .exit, .stdout, .stderr, .before, .after, .memory and
.time for the raw invocation. producer/ contains the earlier logs and input
and build records. elf, libraries and libraries.sha256 identify the executable
and resolved runtime on the execution host. run.sh records input verification,
working directory and the options used. Verify the extracted files with
`sha256sum -c SHA256SUMS` inside the packet.
