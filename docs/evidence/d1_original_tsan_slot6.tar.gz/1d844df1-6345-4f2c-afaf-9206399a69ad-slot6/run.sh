set -euo pipefail
. "$(dirname "$0")/context.sh"
w=/home/agent/.cache/tower/producer-replay-1d844df1-6345-4f2c-afaf-9206399a69ad
exe=$w/bin/thread-tower-lr-work-tests
roots=$w/replay-source
exec 9<>"$pre/build.lock"
flock -n 9
mkdir "$roots"
git -C "$repo" archive 12ab4cae717d4879e393704a8d3b9a1f635bd4f2 scaffolding | tar -xf - -C "$roots"
cd "$roots"
sha256sum -c "$w/input/lr.sha256" > "$r/lr-base-inputs.check"
git apply --check "$w/input/shared-row.patch"
git apply "$w/input/shared-row.patch"
test "$(git hash-object --no-filters scaffolding/tests/lr_budget.tower)" = 2fb874d38ced3be9d9fdf3fedd74861b2560d5b4
sha256sum -c "$w/input/shared-scaffolding.sha256" > "$r/scaffolding.before"
cd "$roots/scaffolding"
pwd > "$r/cwd"
rg 'Cpus_allowed|Mems_allowed|Seccomp|NoNewPrivs' /proc/self/status > "$r/host"
uname -a >> "$r/host"
lscpu >> "$r/host"
readelf -h -n -d "$exe" > "$r/elf"
ldd "$exe" > "$r/libraries"
awk '/=> \// {print $3} /^\s*\/.*ld-linux/{print $1}' "$r/libraries" | sort -u | xargs sha256sum > "$r/libraries.sha256"
nm -D "$exe" | rg '(__tsan_init|work_thread_entry|named_worker_entry|backend_thread_entry)$' > "$r/symbols"
sha256sum "$exe" > "$r/runner.sha256"
rc=0
for selector in lr-bounded lr; do
  measure "$selector" timeout 180 "$exe" "$roots/scaffolding" "$selector" || rc=1
done
(cd "$roots" && sha256sum -c "$w/input/shared-scaffolding.sha256") > "$r/scaffolding.after"
sha256sum -c "$r/runner.sha256" > "$r/runner.after"
test "$rc" = 0
test ! -s "$r/lr-bounded.stdout"
test ! -s "$r/lr-bounded.stderr"
test ! -s "$r/lr.stderr"
printf '%s\n' 'Native production worker policy: serial/threaded LR graph and lifetime comparisons passed.' | cmp - "$r/lr.stdout"
