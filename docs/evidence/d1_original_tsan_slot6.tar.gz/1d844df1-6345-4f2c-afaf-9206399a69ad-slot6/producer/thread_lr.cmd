timeout 180 /home/agent/projects/tower/build/cloud_slot7/thread/tower-lr-work-tests /home/agent/projects/tower/scaffolding lr 
/home/agent/projects/tower/scaffolding
