r=/home/agent/tower-evidence/1d844df1-6345-4f2c-afaf-9206399a69ad-slot6
base=12ab4cae717d4879e393704a8d3b9a1f635bd4f2
cache=/home/agent/.cache/tower/kinmen-preflight-tsan-$base
src=$cache/source
b=$cache/build
pre=/home/agent/tower-reports/preflight-tsan
repo=/home/agent/projects/tower
export PATH=/usr/lib/llvm-19/bin:$PATH
export TSAN_OPTIONS=halt_on_error=1:exitcode=66 LLVM_SYMBOLIZER_PATH=/usr/bin/llvm-symbolizer-19
snap() {
  date -u --iso-8601=ns
  for f in cpuset.cpus.effective cpu.max cpu.stat memory.current memory.peak memory.max memory.events memory.swap.max; do
    if [ -r "/sys/fs/cgroup/$f" ]; then echo "[$f]"; cat "/sys/fs/cgroup/$f"; else echo "[$f unavailable]"; fi
  done
}
measure() {
  local phase=$1 rc=0 pid
  shift
  snap > "$r/$phase.before"
  printf '%q ' "$@" > "$r/$phase.command"
  /usr/bin/time -v -o "$r/$phase.time" "$@" >"$r/$phase.stdout" 2>"$r/$phase.stderr" &
  pid=$!
  while kill -0 "$pid" 2>/dev/null; do
    paste <(date +%s.%N) /sys/fs/cgroup/memory.current >> "$r/$phase.memory"
    sleep .25
  done
  wait "$pid" || rc=$?
  echo "$rc" > "$r/$phase.exit"
  snap > "$r/$phase.after"
  return "$rc"
}
