set -euo pipefail
. "$(dirname "$0")/context.sh"
cd "$r"
printf 'phase\texit\twall_h:mm:ss_or_m:ss\tuser_s\tsystem_s\tpeak_child_RSS_KiB\tshared_cgroup_sampled_max_bytes\tdelta_throttled_usec\n'
for phase in lr-bounded lr; do
  [ -s "$phase.time" ] || continue
  rc=$(awk '/Exit status:/{print $NF}' "$phase.time")
  stats=$(awk '/Elapsed \(wall clock\)/{w=$NF} /User time \(seconds\)/{u=$NF} /System time \(seconds\)/{s=$NF} /Maximum resident set size/{r=$NF} END{printf "%s\t%s\t%s\t%s",w,u,s,r}' "$phase.time")
  peak=unavailable; delta=unavailable
  if [[ -s "$phase.memory" ]]; then
    peak=$(awk '{if($2>m)m=$2}END{print m}' "$phase.memory")
    a=$(awk '/^throttled_usec /{print $2}' "$phase.before")
    z=$(awk '/^throttled_usec /{print $2}' "$phase.after")
    delta=$((z-a))
  fi
  printf '%s\t%s\t%s\t%s\t%s\n' "$phase" "$rc" "$stats" "$peak" "$delta"
done
