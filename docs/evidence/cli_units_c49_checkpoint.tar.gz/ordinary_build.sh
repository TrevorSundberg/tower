set -euo pipefail
r=/cache/cli_units_c49_b2
cd "$r/source"
export PATH=/cache/build_tools_c934d02d:$PATH
cp "$r/driver_units.original" scaffolding/host/driver_units.tower
cp "$r/frontend_units.original" scaffolding/compiler/frontend_units.tower
touch scaffolding/host/driver_units.tower scaffolding/compiler/frontend_units.tower
/cache/process_profile /cache/build_tools_c934d02d/cmake --build "$r/native" --target towerc --parallel 2 > "$r/ordinary_build.log" 2>&1
mkdir "$r/before";cp "$r/native/towerc" "$r/before";cp -a "$r/public/share" "$r/before/"
sha256sum "$r/before/towerc" "$r/public/towerc" > "$r/ordinary_identity.txt"
git apply --whitespace=nowarn "$r/candidate.patch"
/cache/process_profile /cache/build_tools_c934d02d/cmake --build "$r/native" --target towerc --parallel 2 > "$r/candidate_build.log" 2>&1
mkdir "$r/after";cp "$r/native/towerc" "$r/after";cp -a "$r/public/share" "$r/after/"

