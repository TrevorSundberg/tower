set -euo pipefail
r=/cache/cli_units_c49_b2
cd "$r"
ps -eo pid,ppid,stat,comm | awk '$3 !~ /^Z/ && $4 ~ /^(towerc|clang.*|ninja|cmake|generator|process_profile|tower-driver-test.*|ld\.lld)$/ ' > live_jobs_after.txt
test ! -s live_jobs_after.txt
cat checks/original/'driver stderr.txt'
sha256sum source.tar public/towerc before/towerc observe/towerc after/towerc native/tower-driver-tests candidate.patch final_checkpoint.patch > frozen.sha256
{ uname -a; clang-19 --version; cat /sys/fs/cgroup/cpuset.cpus.effective /sys/fs/cgroup/cpu.max /sys/fs/cgroup/memory.max /sys/fs/cgroup/memory.swap.max /sys/fs/cgroup/memory.events; df -B1 /cache; } > environment.txt
find runs checks fixtures -type f -print0 | sort -z | xargs -0 sha256sum > results.sha256
{
 find . -maxdepth 1 -type f \( -name '*.sh' -o -name '*.patch' -o -name '*.tower' -o -name '*.log' -o -name '*.txt' -o -name '*.sha256' \) -printf '%P\n'
 find fixtures runs checks -type f ! -name '*.o' ! -name program ! -name 'driver units executable'
} | sort -u > members.txt
tar --verbatim-files-from -czf cloud_checkpoint.tar.gz -T members.txt
sha256sum cloud_checkpoint.tar.gz
wc -c cloud_checkpoint.tar.gz
for s in small uneven core_small core_uneven; do for n in 1 4 8 12; do
 d=runs/public/$s/$n/first; printf '%s/%s ' "$s" "$n"; paste -s -d' ' "$d/exit" "$d/cost" | head -2 | tr '\n' ' '; echo
done; done
cat fixtures/small/expected fixtures/uneven/expected
for f in runs/clang/{small,uneven}/{1,4,8,12}/{compile,link}.cost;do printf '%s ' "$f"; head -n 1 "$f";done
