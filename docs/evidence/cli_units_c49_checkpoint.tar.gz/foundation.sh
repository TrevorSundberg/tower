set -euo pipefail
r=/cache/cli_units_c49_b2
for shape in small uneven; do
 prev="$r/fixtures/foundation_$shape"; dst="$r/fixtures/core_$shape"
 cp -a "$prev" "$dst"
 cd "$dst"
 echo 'import foundation; fn adjusted(price:i32,band:i32):i32{var tax:i32=price*band; tax=tax/10; var net:i32=price+tax;return net;}' > rates.tower
 sed -i -E 's/return adjusted\(base\+([0-9]+),/var price:i32=base+\1;return adjusted(price,/' unit*.tower
 sha256sum *.tower *.c *.h ledger.o expected > inputs.sha256
done
for n in 1 4 8 12; do for shape in core_small core_uneven; do
 if ! bash "$r/run_one.sh" public "$shape" "$n" first; then echo "retained $shape/$n"; fi
done; done
