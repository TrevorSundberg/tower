set -eu
r=/cache/cli_units_c49_b2
cd "$r"
mkdir -p fixtures reference
unset TOWER_BOOTSTRAP_COMPILER
"$r/public/towerc" invoice_inputs.tower --library --emit object --jobs 1 -o invoice_inputs.o
clang-19 invoice_inputs.o -o generator
for shape in small uneven; do
 d="$r/fixtures/$shape"; mkdir -p "$d"; cd "$d"
 v=0; if [ "$shape" = uneven ]; then v=1; fi
 echo 'import tower; fn adjusted(price:i32,band:i32):i32{return price+(price*band)/10;}' > rates.tower
 echo 'static int adjusted(int price,int band){return price+price*band/10;}' > rates.h
 echo 'static int order; void ledger_note(int id){order=(order*13+id)%10007;} int ledger_order(void){return order;}' > ledger.c
 clang-19 -std=c11 -m64 -O2 -fwrapv -c ledger.c -o ledger.o
 for u in $(seq 0 12); do name=unit$u; if [ "$u" = 0 ]; then name=main; fi
  "$r/generator" T "$u" "$v" > "$name.tower"; "$r/generator" C "$u" "$v" > "$name.c"
 done
 "$r/generator" E 0 "$v" > expected
 sha256sum *.tower *.c *.h ledger.o expected > inputs.sha256
done
