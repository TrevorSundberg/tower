set -eu
r=/cache/cli_units_c49_b2
for n in 12 4 8 1; do for shape in small uneven; do
 if [ "$n" = 1 ] && [ "$shape" = small ]; then continue; fi
 bash "$r/run_one.sh" public "$shape" "$n" first
done; done
