set -eu
r=/cache/cli_units_c49_b2
arm=$1; shape=$2; n=$3; sample=$4
out=$r/runs/$arm/$shape/$n/$sample
mkdir -p "$out/tmp"
cd "$r/fixtures/$shape"
args=(main.tower)
for u in $(seq 1 12); do args+=(--unit "unit$u.tower"); done
args+=(--jobs "$n" --link ledger.o --timings --cc clang-19 -o "$out/program" --depfile "$out/program.d")
if [ "${COHORT_LIMIT:-}" ]; then args+=(--unit-retained-bytes "$COHORT_LIMIT"); fi
cmd=$r/$arm/towerc
printf '%q ' "$cmd" "${args[@]}" > "$out/command.txt"
export TMPDIR="$out/tmp"
set +e
/cache/process_profile /usr/bin/timeout 180 "$cmd" "${args[@]}" > "$out/cost" 2> "$out/stderr"
status=$?
set -e
echo "$status" > "$out/exit"
if [ "$status" -ne 0 ]; then cat "$out/stderr" >&2; exit "$status"; fi
"$out/program" > "$out/output"
cmp expected "$out/output"
llvm-nm-19 -D --defined-only "$out/program" > "$out/exports"
for u in $(seq 1 12); do grep -Eq " T invoice_${u}$" "$out/exports"; done
for f in main.tower unit{1..12}.tower rates.tower tower.tower foundation.tower types.tower bedrock.tower foundation_syntax.tower; do grep -Fq "/$f" "$out/program.d" || { echo "missing depfile input $f" >&2; exit 3; }; done
test -z "$(ls -A "$out/tmp")"
cat "$out/stderr"
