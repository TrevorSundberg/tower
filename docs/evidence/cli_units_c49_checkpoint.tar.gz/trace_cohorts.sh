set -eu
r=/cache/cli_units_c49_b2
for n in 4 8 1 12; do for shape in uneven small; do
 d=$r/runs/public/$shape/$n/first
 if [ -e "$d/exit" ]; then continue; fi
 if ! bash "$r/run_one.sh" public "$shape" "$n" first; then echo "preserved $shape/$n"; fi
done; done
for shape in small uneven; do
 dst=$r/fixtures/foundation_$shape; cp -a "$r/fixtures/$shape" "$dst"
 sed -i 's/^import tower;/import foundation;/' "$dst/rates.tower"
 for f in "$dst"/unit*.tower; do sed -i 's/total+=/total=total+/g' "$f"; done
 (cd "$dst"; sha256sum *.tower *.c *.h ledger.o expected > inputs.sha256)
done
for n in 12 1 8 4; do for shape in foundation_small foundation_uneven; do
 if ! bash "$r/run_one.sh" public "$shape" "$n" first; then echo "preserved $shape/$n"; fi
done; done
