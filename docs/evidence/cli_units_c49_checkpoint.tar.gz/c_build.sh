set -eu
r=/cache/cli_units_c49_b2
for shape in small uneven; do for n in 1 4 8 12; do
 d="$r/runs/clang/$shape/$n"; mkdir -p "$d"; cd "$r/fixtures/$shape"
 export d
 /cache/process_profile /usr/bin/xargs -P "$n" -I@ /bin/bash -c 'f=$1; clang-19 -std=c11 -m64 -O2 -fwrapv -fPIE -MMD -MF "$d/${f%.c}.d" -c "$f" -o "$d/${f%.c}.o"' _ @ > "$d/compile.cost" < <(printf '%s\n' main.c unit{1..12}.c)
 objs=("$d/main.o"); opts=()
 for u in $(seq 1 12);do objs+=("$d/unit$u.o"); opts+=("-Wl,--export-dynamic-symbol=invoice_$u");grep -Fq rates.h "$d/unit$u.d"; done
 /cache/process_profile /usr/bin/clang-19 -m64 -pie "${objs[@]}" ledger.o "${opts[@]}" -o "$d/program" > "$d/link.cost"
 "$d/program" > "$d/output"; cmp expected "$d/output"
 llvm-nm-19 -D --defined-only "$d/program" > "$d/exports"
 for u in $(seq 1 12);do grep -Eq " T invoice_${u}$" "$d/exports";done
done;done
