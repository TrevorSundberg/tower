#include "rates.h"
extern void ledger_note(int);
static int line_0(int base){return adjusted(base+0,1);}
static int line_1(int base){return adjusted(base+1,2);}
static int line_2(int base){return adjusted(base+2,3);}
static int line_3(int base){return adjusted(base+3,4);}
static int line_4(int base){return adjusted(base+4,1);}
static int line_5(int base){return adjusted(base+5,2);}
static int line_6(int base){return adjusted(base+6,3);}
static int line_7(int base){return adjusted(base+7,4);}
static int line_8(int base){return adjusted(base+8,1);}
static int line_9(int base){return adjusted(base+9,2);}
static int line_10(int base){return adjusted(base+10,3);}
static int line_11(int base){return adjusted(base+11,4);}
static int line_12(int base){return adjusted(base+12,1);}
static int line_13(int base){return adjusted(base+13,2);}
static int line_14(int base){return adjusted(base+14,3);}
static int line_15(int base){return adjusted(base+15,4);}
static int line_16(int base){return adjusted(base+16,1);}
static int line_17(int base){return adjusted(base+17,2);}
static int line_18(int base){return adjusted(base+18,3);}
static int line_19(int base){return adjusted(base+19,4);}
static int line_20(int base){return adjusted(base+20,1);}
static int line_21(int base){return adjusted(base+21,2);}
static int line_22(int base){return adjusted(base+22,3);}
static int line_23(int base){return adjusted(base+23,4);}
static int line_24(int base){return adjusted(base+24,1);}
static int line_25(int base){return adjusted(base+25,2);}
static int line_26(int base){return adjusted(base+26,3);}
static int line_27(int base){return adjusted(base+27,4);}
static int line_28(int base){return adjusted(base+28,1);}
static int line_29(int base){return adjusted(base+29,2);}
static int line_30(int base){return adjusted(base+30,3);}
static int line_31(int base){return adjusted(base+31,4);}
static int line_32(int base){return adjusted(base+32,1);}
static int line_33(int base){return adjusted(base+33,2);}
static int line_34(int base){return adjusted(base+34,3);}
static int line_35(int base){return adjusted(base+35,4);}
static int line_36(int base){return adjusted(base+36,1);}
static int line_37(int base){return adjusted(base+37,2);}
static int line_38(int base){return adjusted(base+38,3);}
static int line_39(int base){return adjusted(base+39,4);}
static int line_40(int base){return adjusted(base+40,1);}
static int line_41(int base){return adjusted(base+41,2);}
static int line_42(int base){return adjusted(base+42,3);}
static int line_43(int base){return adjusted(base+43,4);}
static int line_44(int base){return adjusted(base+44,1);}
static int line_45(int base){return adjusted(base+45,2);}
static int line_46(int base){return adjusted(base+46,3);}
static int line_47(int base){return adjusted(base+47,4);}
static int line_48(int base){return adjusted(base+48,1);}
static int line_49(int base){return adjusted(base+49,2);}
static int line_50(int base){return adjusted(base+50,3);}
static int line_51(int base){return adjusted(base+51,4);}
static int line_52(int base){return adjusted(base+52,1);}
static int line_53(int base){return adjusted(base+53,2);}
static int line_54(int base){return adjusted(base+54,3);}
static int line_55(int base){return adjusted(base+55,4);}
static int line_56(int base){return adjusted(base+56,1);}
static int line_57(int base){return adjusted(base+57,2);}
static int line_58(int base){return adjusted(base+58,3);}
static int line_59(int base){return adjusted(base+59,4);}
static int line_60(int base){return adjusted(base+60,1);}
static int line_61(int base){return adjusted(base+61,2);}
static int line_62(int base){return adjusted(base+62,3);}
static int line_63(int base){return adjusted(base+63,4);}
static int line_64(int base){return adjusted(base+64,1);}
static int line_65(int base){return adjusted(base+65,2);}
static int line_66(int base){return adjusted(base+66,3);}
static int line_67(int base){return adjusted(base+67,4);}
static int line_68(int base){return adjusted(base+68,1);}
static int line_69(int base){return adjusted(base+69,2);}
static int line_70(int base){return adjusted(base+70,3);}
static int line_71(int base){return adjusted(base+71,4);}
static int line_72(int base){return adjusted(base+72,1);}
static int line_73(int base){return adjusted(base+73,2);}
static int line_74(int base){return adjusted(base+74,3);}
static int line_75(int base){return adjusted(base+75,4);}
static int line_76(int base){return adjusted(base+76,1);}
static int line_77(int base){return adjusted(base+77,2);}
static int line_78(int base){return adjusted(base+78,3);}
static int line_79(int base){return adjusted(base+79,4);}
static int line_80(int base){return adjusted(base+80,1);}
static int line_81(int base){return adjusted(base+81,2);}
static int line_82(int base){return adjusted(base+82,3);}
static int line_83(int base){return adjusted(base+83,4);}
static int line_84(int base){return adjusted(base+84,1);}
static int line_85(int base){return adjusted(base+85,2);}
static int line_86(int base){return adjusted(base+86,3);}
static int line_87(int base){return adjusted(base+87,4);}
static int line_88(int base){return adjusted(base+88,1);}
static int line_89(int base){return adjusted(base+89,2);}
static int line_90(int base){return adjusted(base+90,3);}
static int line_91(int base){return adjusted(base+91,4);}
static int line_92(int base){return adjusted(base+92,1);}
static int line_93(int base){return adjusted(base+93,2);}
static int line_94(int base){return adjusted(base+94,3);}
static int line_95(int base){return adjusted(base+95,4);}
static int line_96(int base){return adjusted(base+96,1);}
static int line_97(int base){return adjusted(base+97,2);}
static int line_98(int base){return adjusted(base+98,3);}
static int line_99(int base){return adjusted(base+99,4);}
static int line_100(int base){return adjusted(base+100,1);}
static int line_101(int base){return adjusted(base+101,2);}
static int line_102(int base){return adjusted(base+102,3);}
static int line_103(int base){return adjusted(base+103,4);}
static int line_104(int base){return adjusted(base+104,1);}
static int line_105(int base){return adjusted(base+105,2);}
static int line_106(int base){return adjusted(base+106,3);}
static int line_107(int base){return adjusted(base+107,4);}
static int line_108(int base){return adjusted(base+108,1);}
static int line_109(int base){return adjusted(base+109,2);}
static int line_110(int base){return adjusted(base+110,3);}
static int line_111(int base){return adjusted(base+111,4);}
static int line_112(int base){return adjusted(base+112,1);}
static int line_113(int base){return adjusted(base+113,2);}
static int line_114(int base){return adjusted(base+114,3);}
static int line_115(int base){return adjusted(base+115,4);}
static int line_116(int base){return adjusted(base+116,1);}
static int line_117(int base){return adjusted(base+117,2);}
static int line_118(int base){return adjusted(base+118,3);}
static int line_119(int base){return adjusted(base+119,4);}
static int line_120(int base){return adjusted(base+120,1);}
static int line_121(int base){return adjusted(base+121,2);}
static int line_122(int base){return adjusted(base+122,3);}
static int line_123(int base){return adjusted(base+123,4);}
static int line_124(int base){return adjusted(base+124,1);}
static int line_125(int base){return adjusted(base+125,2);}
static int line_126(int base){return adjusted(base+126,3);}
static int line_127(int base){return adjusted(base+127,4);}
static int line_128(int base){return adjusted(base+128,1);}
static int line_129(int base){return adjusted(base+129,2);}
static int line_130(int base){return adjusted(base+130,3);}
static int line_131(int base){return adjusted(base+131,4);}
static int line_132(int base){return adjusted(base+132,1);}
static int line_133(int base){return adjusted(base+133,2);}
static int line_134(int base){return adjusted(base+134,3);}
static int line_135(int base){return adjusted(base+135,4);}
static int line_136(int base){return adjusted(base+136,1);}
static int line_137(int base){return adjusted(base+137,2);}
static int line_138(int base){return adjusted(base+138,3);}
static int line_139(int base){return adjusted(base+139,4);}
static int line_140(int base){return adjusted(base+140,1);}
static int line_141(int base){return adjusted(base+141,2);}
static int line_142(int base){return adjusted(base+142,3);}
static int line_143(int base){return adjusted(base+143,4);}
static int line_144(int base){return adjusted(base+144,1);}
static int line_145(int base){return adjusted(base+145,2);}
static int line_146(int base){return adjusted(base+146,3);}
static int line_147(int base){return adjusted(base+147,4);}
static int line_148(int base){return adjusted(base+148,1);}
static int line_149(int base){return adjusted(base+149,2);}
static int line_150(int base){return adjusted(base+150,3);}
static int line_151(int base){return adjusted(base+151,4);}
static int line_152(int base){return adjusted(base+152,1);}
static int line_153(int base){return adjusted(base+153,2);}
static int line_154(int base){return adjusted(base+154,3);}
static int line_155(int base){return adjusted(base+155,4);}
static int line_156(int base){return adjusted(base+156,1);}
static int line_157(int base){return adjusted(base+157,2);}
static int line_158(int base){return adjusted(base+158,3);}
static int line_159(int base){return adjusted(base+159,4);}
static int line_160(int base){return adjusted(base+160,1);}
static int line_161(int base){return adjusted(base+161,2);}
static int line_162(int base){return adjusted(base+162,3);}
static int line_163(int base){return adjusted(base+163,4);}
static int line_164(int base){return adjusted(base+164,1);}
static int line_165(int base){return adjusted(base+165,2);}
static int line_166(int base){return adjusted(base+166,3);}
static int line_167(int base){return adjusted(base+167,4);}
static int line_168(int base){return adjusted(base+168,1);}
static int line_169(int base){return adjusted(base+169,2);}
static int line_170(int base){return adjusted(base+170,3);}
static int line_171(int base){return adjusted(base+171,4);}
static int line_172(int base){return adjusted(base+172,1);}
static int line_173(int base){return adjusted(base+173,2);}
static int line_174(int base){return adjusted(base+174,3);}
static int line_175(int base){return adjusted(base+175,4);}
static int line_176(int base){return adjusted(base+176,1);}
static int line_177(int base){return adjusted(base+177,2);}
static int line_178(int base){return adjusted(base+178,3);}
static int line_179(int base){return adjusted(base+179,4);}
static int line_180(int base){return adjusted(base+180,1);}
static int line_181(int base){return adjusted(base+181,2);}
static int line_182(int base){return adjusted(base+182,3);}
static int line_183(int base){return adjusted(base+183,4);}
static int line_184(int base){return adjusted(base+184,1);}
static int line_185(int base){return adjusted(base+185,2);}
static int line_186(int base){return adjusted(base+186,3);}
static int line_187(int base){return adjusted(base+187,4);}
static int line_188(int base){return adjusted(base+188,1);}
static int line_189(int base){return adjusted(base+189,2);}
static int line_190(int base){return adjusted(base+190,3);}
static int line_191(int base){return adjusted(base+191,4);}
static int line_192(int base){return adjusted(base+192,1);}
static int line_193(int base){return adjusted(base+193,2);}
static int line_194(int base){return adjusted(base+194,3);}
static int line_195(int base){return adjusted(base+195,4);}
static int line_196(int base){return adjusted(base+196,1);}
static int line_197(int base){return adjusted(base+197,2);}
static int line_198(int base){return adjusted(base+198,3);}
static int line_199(int base){return adjusted(base+199,4);}
static int line_200(int base){return adjusted(base+200,1);}
static int line_201(int base){return adjusted(base+201,2);}
static int line_202(int base){return adjusted(base+202,3);}
static int line_203(int base){return adjusted(base+203,4);}
static int line_204(int base){return adjusted(base+204,1);}
static int line_205(int base){return adjusted(base+205,2);}
static int line_206(int base){return adjusted(base+206,3);}
static int line_207(int base){return adjusted(base+207,4);}
static int line_208(int base){return adjusted(base+208,1);}
static int line_209(int base){return adjusted(base+209,2);}
static int line_210(int base){return adjusted(base+210,3);}
static int line_211(int base){return adjusted(base+211,4);}
static int line_212(int base){return adjusted(base+212,1);}
static int line_213(int base){return adjusted(base+213,2);}
static int line_214(int base){return adjusted(base+214,3);}
static int line_215(int base){return adjusted(base+215,4);}
static int line_216(int base){return adjusted(base+216,1);}
static int line_217(int base){return adjusted(base+217,2);}
static int line_218(int base){return adjusted(base+218,3);}
static int line_219(int base){return adjusted(base+219,4);}
static int line_220(int base){return adjusted(base+220,1);}
static int line_221(int base){return adjusted(base+221,2);}
static int line_222(int base){return adjusted(base+222,3);}
static int line_223(int base){return adjusted(base+223,4);}
static int line_224(int base){return adjusted(base+224,1);}
static int line_225(int base){return adjusted(base+225,2);}
static int line_226(int base){return adjusted(base+226,3);}
static int line_227(int base){return adjusted(base+227,4);}
static int line_228(int base){return adjusted(base+228,1);}
static int line_229(int base){return adjusted(base+229,2);}
static int line_230(int base){return adjusted(base+230,3);}
static int line_231(int base){return adjusted(base+231,4);}
static int line_232(int base){return adjusted(base+232,1);}
static int line_233(int base){return adjusted(base+233,2);}
static int line_234(int base){return adjusted(base+234,3);}
static int line_235(int base){return adjusted(base+235,4);}
static int line_236(int base){return adjusted(base+236,1);}
static int line_237(int base){return adjusted(base+237,2);}
static int line_238(int base){return adjusted(base+238,3);}
static int line_239(int base){return adjusted(base+239,4);}
static int line_240(int base){return adjusted(base+240,1);}
static int line_241(int base){return adjusted(base+241,2);}
static int line_242(int base){return adjusted(base+242,3);}
static int line_243(int base){return adjusted(base+243,4);}
static int line_244(int base){return adjusted(base+244,1);}
static int line_245(int base){return adjusted(base+245,2);}
static int line_246(int base){return adjusted(base+246,3);}
static int line_247(int base){return adjusted(base+247,4);}
static int line_248(int base){return adjusted(base+248,1);}
static int line_249(int base){return adjusted(base+249,2);}
static int line_250(int base){return adjusted(base+250,3);}
static int line_251(int base){return adjusted(base+251,4);}
static int line_252(int base){return adjusted(base+252,1);}
static int line_253(int base){return adjusted(base+253,2);}
static int line_254(int base){return adjusted(base+254,3);}
static int line_255(int base){return adjusted(base+255,4);}
int invoice_1(int base){int total=0;ledger_note(1);
total+=line_0(base);
total+=line_1(base);
total+=line_2(base);
total+=line_3(base);
total+=line_4(base);
total+=line_5(base);
total+=line_6(base);
total+=line_7(base);
total+=line_8(base);
total+=line_9(base);
total+=line_10(base);
total+=line_11(base);
total+=line_12(base);
total+=line_13(base);
total+=line_14(base);
total+=line_15(base);
total+=line_16(base);
total+=line_17(base);
total+=line_18(base);
total+=line_19(base);
total+=line_20(base);
total+=line_21(base);
total+=line_22(base);
total+=line_23(base);
total+=line_24(base);
total+=line_25(base);
total+=line_26(base);
total+=line_27(base);
total+=line_28(base);
total+=line_29(base);
total+=line_30(base);
total+=line_31(base);
total+=line_32(base);
total+=line_33(base);
total+=line_34(base);
total+=line_35(base);
total+=line_36(base);
total+=line_37(base);
total+=line_38(base);
total+=line_39(base);
total+=line_40(base);
total+=line_41(base);
total+=line_42(base);
total+=line_43(base);
total+=line_44(base);
total+=line_45(base);
total+=line_46(base);
total+=line_47(base);
total+=line_48(base);
total+=line_49(base);
total+=line_50(base);
total+=line_51(base);
total+=line_52(base);
total+=line_53(base);
total+=line_54(base);
total+=line_55(base);
total+=line_56(base);
total+=line_57(base);
total+=line_58(base);
total+=line_59(base);
total+=line_60(base);
total+=line_61(base);
total+=line_62(base);
total+=line_63(base);
total+=line_64(base);
total+=line_65(base);
total+=line_66(base);
total+=line_67(base);
total+=line_68(base);
total+=line_69(base);
total+=line_70(base);
total+=line_71(base);
total+=line_72(base);
total+=line_73(base);
total+=line_74(base);
total+=line_75(base);
total+=line_76(base);
total+=line_77(base);
total+=line_78(base);
total+=line_79(base);
total+=line_80(base);
total+=line_81(base);
total+=line_82(base);
total+=line_83(base);
total+=line_84(base);
total+=line_85(base);
total+=line_86(base);
total+=line_87(base);
total+=line_88(base);
total+=line_89(base);
total+=line_90(base);
total+=line_91(base);
total+=line_92(base);
total+=line_93(base);
total+=line_94(base);
total+=line_95(base);
total+=line_96(base);
total+=line_97(base);
total+=line_98(base);
total+=line_99(base);
total+=line_100(base);
total+=line_101(base);
total+=line_102(base);
total+=line_103(base);
total+=line_104(base);
total+=line_105(base);
total+=line_106(base);
total+=line_107(base);
total+=line_108(base);
total+=line_109(base);
total+=line_110(base);
total+=line_111(base);
total+=line_112(base);
total+=line_113(base);
total+=line_114(base);
total+=line_115(base);
total+=line_116(base);
total+=line_117(base);
total+=line_118(base);
total+=line_119(base);
total+=line_120(base);
total+=line_121(base);
total+=line_122(base);
total+=line_123(base);
total+=line_124(base);
total+=line_125(base);
total+=line_126(base);
total+=line_127(base);
total+=line_128(base);
total+=line_129(base);
total+=line_130(base);
total+=line_131(base);
total+=line_132(base);
total+=line_133(base);
total+=line_134(base);
total+=line_135(base);
total+=line_136(base);
total+=line_137(base);
total+=line_138(base);
total+=line_139(base);
total+=line_140(base);
total+=line_141(base);
total+=line_142(base);
total+=line_143(base);
total+=line_144(base);
total+=line_145(base);
total+=line_146(base);
total+=line_147(base);
total+=line_148(base);
total+=line_149(base);
total+=line_150(base);
total+=line_151(base);
total+=line_152(base);
total+=line_153(base);
total+=line_154(base);
total+=line_155(base);
total+=line_156(base);
total+=line_157(base);
total+=line_158(base);
total+=line_159(base);
total+=line_160(base);
total+=line_161(base);
total+=line_162(base);
total+=line_163(base);
total+=line_164(base);
total+=line_165(base);
total+=line_166(base);
total+=line_167(base);
total+=line_168(base);
total+=line_169(base);
total+=line_170(base);
total+=line_171(base);
total+=line_172(base);
total+=line_173(base);
total+=line_174(base);
total+=line_175(base);
total+=line_176(base);
total+=line_177(base);
total+=line_178(base);
total+=line_179(base);
total+=line_180(base);
total+=line_181(base);
total+=line_182(base);
total+=line_183(base);
total+=line_184(base);
total+=line_185(base);
total+=line_186(base);
total+=line_187(base);
total+=line_188(base);
total+=line_189(base);
total+=line_190(base);
total+=line_191(base);
total+=line_192(base);
total+=line_193(base);
total+=line_194(base);
total+=line_195(base);
total+=line_196(base);
total+=line_197(base);
total+=line_198(base);
total+=line_199(base);
total+=line_200(base);
total+=line_201(base);
total+=line_202(base);
total+=line_203(base);
total+=line_204(base);
total+=line_205(base);
total+=line_206(base);
total+=line_207(base);
total+=line_208(base);
total+=line_209(base);
total+=line_210(base);
total+=line_211(base);
total+=line_212(base);
total+=line_213(base);
total+=line_214(base);
total+=line_215(base);
total+=line_216(base);
total+=line_217(base);
total+=line_218(base);
total+=line_219(base);
total+=line_220(base);
total+=line_221(base);
total+=line_222(base);
total+=line_223(base);
total+=line_224(base);
total+=line_225(base);
total+=line_226(base);
total+=line_227(base);
total+=line_228(base);
total+=line_229(base);
total+=line_230(base);
total+=line_231(base);
total+=line_232(base);
total+=line_233(base);
total+=line_234(base);
total+=line_235(base);
total+=line_236(base);
total+=line_237(base);
total+=line_238(base);
total+=line_239(base);
total+=line_240(base);
total+=line_241(base);
total+=line_242(base);
total+=line_243(base);
total+=line_244(base);
total+=line_245(base);
total+=line_246(base);
total+=line_247(base);
total+=line_248(base);
total+=line_249(base);
total+=line_250(base);
total+=line_251(base);
total+=line_252(base);
total+=line_253(base);
total+=line_254(base);
total+=line_255(base);
return total;}
