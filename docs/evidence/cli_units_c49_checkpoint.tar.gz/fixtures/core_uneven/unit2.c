#include "rates.h"
extern void ledger_note(int);
static int line_0(int base){return adjusted(base+0,1);}
static int line_1(int base){return adjusted(base+1,2);}
static int line_2(int base){return adjusted(base+2,3);}
static int line_3(int base){return adjusted(base+3,4);}
static int line_4(int base){return adjusted(base+4,1);}
static int line_5(int base){return adjusted(base+5,2);}
static int line_6(int base){return adjusted(base+6,3);}
static int line_7(int base){return adjusted(base+7,4);}
static int line_8(int base){return adjusted(base+8,1);}
static int line_9(int base){return adjusted(base+9,2);}
static int line_10(int base){return adjusted(base+10,3);}
static int line_11(int base){return adjusted(base+11,4);}
static int line_12(int base){return adjusted(base+12,1);}
static int line_13(int base){return adjusted(base+13,2);}
static int line_14(int base){return adjusted(base+14,3);}
static int line_15(int base){return adjusted(base+15,4);}
static int line_16(int base){return adjusted(base+16,1);}
static int line_17(int base){return adjusted(base+17,2);}
static int line_18(int base){return adjusted(base+18,3);}
static int line_19(int base){return adjusted(base+19,4);}
static int line_20(int base){return adjusted(base+20,1);}
static int line_21(int base){return adjusted(base+21,2);}
static int line_22(int base){return adjusted(base+22,3);}
static int line_23(int base){return adjusted(base+23,4);}
static int line_24(int base){return adjusted(base+24,1);}
static int line_25(int base){return adjusted(base+25,2);}
static int line_26(int base){return adjusted(base+26,3);}
static int line_27(int base){return adjusted(base+27,4);}
static int line_28(int base){return adjusted(base+28,1);}
static int line_29(int base){return adjusted(base+29,2);}
static int line_30(int base){return adjusted(base+30,3);}
static int line_31(int base){return adjusted(base+31,4);}
static int line_32(int base){return adjusted(base+32,1);}
static int line_33(int base){return adjusted(base+33,2);}
static int line_34(int base){return adjusted(base+34,3);}
static int line_35(int base){return adjusted(base+35,4);}
static int line_36(int base){return adjusted(base+36,1);}
static int line_37(int base){return adjusted(base+37,2);}
static int line_38(int base){return adjusted(base+38,3);}
static int line_39(int base){return adjusted(base+39,4);}
static int line_40(int base){return adjusted(base+40,1);}
static int line_41(int base){return adjusted(base+41,2);}
static int line_42(int base){return adjusted(base+42,3);}
static int line_43(int base){return adjusted(base+43,4);}
static int line_44(int base){return adjusted(base+44,1);}
static int line_45(int base){return adjusted(base+45,2);}
static int line_46(int base){return adjusted(base+46,3);}
static int line_47(int base){return adjusted(base+47,4);}
static int line_48(int base){return adjusted(base+48,1);}
static int line_49(int base){return adjusted(base+49,2);}
static int line_50(int base){return adjusted(base+50,3);}
static int line_51(int base){return adjusted(base+51,4);}
static int line_52(int base){return adjusted(base+52,1);}
static int line_53(int base){return adjusted(base+53,2);}
static int line_54(int base){return adjusted(base+54,3);}
static int line_55(int base){return adjusted(base+55,4);}
static int line_56(int base){return adjusted(base+56,1);}
static int line_57(int base){return adjusted(base+57,2);}
static int line_58(int base){return adjusted(base+58,3);}
static int line_59(int base){return adjusted(base+59,4);}
static int line_60(int base){return adjusted(base+60,1);}
static int line_61(int base){return adjusted(base+61,2);}
static int line_62(int base){return adjusted(base+62,3);}
static int line_63(int base){return adjusted(base+63,4);}
int invoice_2(int base){int total=0;ledger_note(2);
total+=line_0(base);
total+=line_1(base);
total+=line_2(base);
total+=line_3(base);
total+=line_4(base);
total+=line_5(base);
total+=line_6(base);
total+=line_7(base);
total+=line_8(base);
total+=line_9(base);
total+=line_10(base);
total+=line_11(base);
total+=line_12(base);
total+=line_13(base);
total+=line_14(base);
total+=line_15(base);
total+=line_16(base);
total+=line_17(base);
total+=line_18(base);
total+=line_19(base);
total+=line_20(base);
total+=line_21(base);
total+=line_22(base);
total+=line_23(base);
total+=line_24(base);
total+=line_25(base);
total+=line_26(base);
total+=line_27(base);
total+=line_28(base);
total+=line_29(base);
total+=line_30(base);
total+=line_31(base);
total+=line_32(base);
total+=line_33(base);
total+=line_34(base);
total+=line_35(base);
total+=line_36(base);
total+=line_37(base);
total+=line_38(base);
total+=line_39(base);
total+=line_40(base);
total+=line_41(base);
total+=line_42(base);
total+=line_43(base);
total+=line_44(base);
total+=line_45(base);
total+=line_46(base);
total+=line_47(base);
total+=line_48(base);
total+=line_49(base);
total+=line_50(base);
total+=line_51(base);
total+=line_52(base);
total+=line_53(base);
total+=line_54(base);
total+=line_55(base);
total+=line_56(base);
total+=line_57(base);
total+=line_58(base);
total+=line_59(base);
total+=line_60(base);
total+=line_61(base);
total+=line_62(base);
total+=line_63(base);
return total;}
