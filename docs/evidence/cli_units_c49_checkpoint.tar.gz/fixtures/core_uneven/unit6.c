#include "rates.h"
extern void ledger_note(int);
static int line_0(int base){return adjusted(base+0,1);}
static int line_1(int base){return adjusted(base+1,2);}
static int line_2(int base){return adjusted(base+2,3);}
static int line_3(int base){return adjusted(base+3,4);}
static int line_4(int base){return adjusted(base+4,1);}
static int line_5(int base){return adjusted(base+5,2);}
static int line_6(int base){return adjusted(base+6,3);}
static int line_7(int base){return adjusted(base+7,4);}
int invoice_6(int base){int total=0;ledger_note(6);
total+=line_0(base);
total+=line_1(base);
total+=line_2(base);
total+=line_3(base);
total+=line_4(base);
total+=line_5(base);
total+=line_6(base);
total+=line_7(base);
return total;}
