#include <stdio.h>
extern int ledger_order(void);
extern int invoice_1(int);
extern int invoice_2(int);
extern int invoice_3(int);
extern int invoice_4(int);
extern int invoice_5(int);
extern int invoice_6(int);
extern int invoice_7(int);
extern int invoice_8(int);
extern int invoice_9(int);
extern int invoice_10(int);
extern int invoice_11(int);
extern int invoice_12(int);
int main(void){int total=0;
total+=invoice_1(10);
total+=invoice_2(13);
total+=invoice_3(16);
total+=invoice_4(19);
total+=invoice_5(22);
total+=invoice_6(25);
total+=invoice_7(28);
total+=invoice_8(31);
total+=invoice_9(34);
total+=invoice_10(37);
total+=invoice_11(40);
total+=invoice_12(43);
printf("%d\n%d\n",total,ledger_order());return 0;}
