#include "rates.h"
extern void ledger_note(int);
static int line_0(int base){return adjusted(base+0,1);}
static int line_1(int base){return adjusted(base+1,2);}
static int line_2(int base){return adjusted(base+2,3);}
static int line_3(int base){return adjusted(base+3,4);}
int invoice_3(int base){int total=0;ledger_note(3);
total+=line_0(base);
total+=line_1(base);
total+=line_2(base);
total+=line_3(base);
return total;}
