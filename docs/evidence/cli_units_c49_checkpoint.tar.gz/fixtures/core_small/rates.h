static int adjusted(int price,int band){return price+price*band/10;}
