static int order; void ledger_note(int id){order=(order*13+id)%10007;} int ledger_order(void){return order;}
