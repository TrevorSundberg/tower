set -eu
r=/cache/cli_units_c49_b2
cd "$r/source"
f=scaffolding/host/driver_units_observation.tower
sed -i -E 's/trial_field\((snapshot\.[a-z_]+|i|span.worker)\)/trial_field(convert(u64,\1))/g' "$f"
cp "$f" "$r/observer_final.tower"
export PATH=/cache/build_tools_c934d02d:$PATH
/cache/process_profile /cache/build_tools_c934d02d/cmake --build "$r/native" --target towerc --parallel 2 > "$r/observe_rebuild.log" 2>&1
mkdir "$r/observe";cp "$r/native/towerc" "$r/observe";cp -a "$r/public/share" "$r/observe/"
for shape in small uneven core_small core_uneven; do for n in 1 4 8 12; do
 if ! bash "$r/run_one.sh" observe "$shape" "$n" attribution;then echo "retained $shape/$n"; fi
done; done
