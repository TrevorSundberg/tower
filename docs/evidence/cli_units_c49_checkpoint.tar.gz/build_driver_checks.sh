set -eu
r=/cache/cli_units_c49_b2;cd "$r"
export PATH=/cache/build_tools_c934d02d:$PATH
cmake -S "$r/source" -B "$r/native" -DTOWER_DRIVER_TESTS=ON > configure_checks.log 2>&1
/cache/process_profile /cache/build_tools_c934d02d/cmake --build "$r/native" --target tower-driver-tests --parallel 2 > build_checks.log 2>&1
mkdir -p checks/original;cd checks/original
/cache/process_profile /usr/bin/timeout 180 "$r/native/tower-driver-tests" --units "$r/public/towerc" > first.log 2>&1
