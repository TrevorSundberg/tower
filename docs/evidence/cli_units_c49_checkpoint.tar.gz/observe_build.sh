set -euo pipefail
r=/cache/cli_units_c49_b2
cd "$r/source"
cp -a "$r/public/." bootstrap/linux-x64/
f=scaffolding/host/driver_units.tower
cp "$f" "$r/driver_units.original"
g=scaffolding/compiler/frontend_units.tower
cp "$g" "$r/frontend_units.original"
cp "$r/driver_units_observation.tower" scaffolding/host/
sed -i '1a import driver_units_observation;' "$f"
sed -i '/    while !backend_units_step(batch.backend, true)/i\    var events:TrialEvents={count:count,spans:alloc(TrialSpan,count*2)}; if events.spans==null{trap("events",0);} for(var e:usize=0;e<count*2;e++){events.spans[e]=default;} defer free(events.spans); if !frontend_units_observer(batch.frontend,bits(void*,\&events),trial_event){trap("observer",0);}' "$f"
sed -i '/    while !backend_units_step(batch.backend, true)/a\    trial_report(\&events,batch.frontend);' "$f"
sed -i '/job.success = syntax_baseline_install(job.world.*bedrock/a\    frontend_units_observe(batch, CompilerQuery.Join, job.ordinal, true);' "$g"
sed -i '/job.success \&\&= syntax_baseline_install(job.world.*foundation/a\    frontend_units_observe(batch, CompilerQuery.BackendJoin, job.ordinal, true);' "$g"
export TOWER_NATIVE_BUILD="$r/native" TOWER_BUILD_JOBS=2 PATH="/cache/build_tools_c934d02d:$PATH"
unset TOWER_BOOTSTRAP_COMPILER
/cache/process_profile /bin/bash playground/scripts/build-native.sh -DTOWER_COMPILER_JOBS=1 > "$r/observe_build.log" 2>&1
mkdir -p "$r/observe"; cp "$r/native/towerc" "$r/observe/"; cp -a "$r/public/share" "$r/observe/"

