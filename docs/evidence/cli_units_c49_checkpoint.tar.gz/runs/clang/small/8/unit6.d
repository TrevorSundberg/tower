/cache/cli_units_c49_b2/runs/clang/small/8/unit6.o: unit6.c rates.h
