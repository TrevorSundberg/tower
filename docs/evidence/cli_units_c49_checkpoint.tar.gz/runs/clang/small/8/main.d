/cache/cli_units_c49_b2/runs/clang/small/8/main.o: main.c
