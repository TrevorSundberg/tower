/cache/cli_units_c49_b2/runs/clang/small/8/unit3.o: unit3.c rates.h
