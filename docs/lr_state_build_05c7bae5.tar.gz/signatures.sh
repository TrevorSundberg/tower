set -euo pipefail
b=/cache/state_build_05c7bae5
export PATH=/usr/lib/llvm-19/bin:$PATH
exec >"$b/obs/signatures.build" 2>&1
trap 'echo $? >"$b/obs/signatures.status"' EXIT
cmake --build /cache/native --target towerc --parallel 2
cp /cache/native/towerc "$b/obs/runtime/table-signatures"
for s in small large; do
 /usr/bin/timeout 180 "$b/obs/runtime/table-signatures" "$b/reference/$s.tower" --jobs 1 --emit object --timings --target x86_64-unknown-linux-gnu --bedrock "$b/source/scaffolding/bedrock.tower" --foundation "$b/source/scaffolding/foundation.tower" -o "$b/obs/$s.sig.o" >"$b/obs/$s.sig.out" 2>"$b/obs/$s.sig.log"
 cmp "$b/obs/$s.sig.o" "$b/reference/$s.reference.o"
done
git diff --binary -- scaffolding >"$b/obs/signatures.patch"