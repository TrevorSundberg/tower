set -eu
export PATH=/usr/lib/llvm-19/bin:$PATH
unset TOWER_BOOTSTRAP_COMPILER
b=/cache/state_build_05c7bae5
exec >"$b/before/build.log" 2>&1
trap 'echo $? >"$b/before/status"' EXIT
mkdir "$b/source"
tar xf "$b/source.tar" -C "$b/source"
cp -a /cache/lexicon_d38396bb/reference "$b/reference"
git rev-parse HEAD 'HEAD^{tree}'
sha256sum bootstrap/linux-x64/towerc "$b/source.tar"
cmake -S /work -B /cache/native -DTOWER_BACKEND_TESTS=OFF -DTOWER_DRIVER_TESTS=OFF -DTOWER_EXECUTION_TESTS=OFF -DTOWER_FORMAT_TESTS=OFF -DTOWER_STORAGE_TESTS=OFF -DTOWER_WORK_TESTS=OFF -DTOWER_MODULE_TESTS=OFF -DTOWER_COMPILER_JOBS=1
/cache/ecs_process_profile /usr/bin/cmake --build /cache/native --target towerc --parallel 2 >"$b/before/cli.log" 2>"$b/before/cli.time"
cp /cache/native/towerc "$b/before/runtime"
cp -a bootstrap/linux-x64/share "$b/before/runtime/"
ninja -C /cache/native -t commands towerc >"$b/before/commands"
sha256sum "$b/before/runtime/towerc"