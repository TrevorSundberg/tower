set -euo pipefail
export PATH=/usr/lib/llvm-19/bin:$PATH
b=/cache/state_build_05c7bae5
exec >"$b/obs/build.log" 2>&1
trap 'echo $? >"$b/obs/status"' EXIT
git diff --binary -- scaffolding >"$b/obs/observer.patch"
cp scaffolding/compiler/lr_build_probe.tower "$b/obs/"
cmake --build /cache/native --target tower-compiler-parser-nodes.o --parallel 2
cmake --build /cache/native --target towerc --parallel 2
mkdir -p "$b/obs/runtime"; cp /cache/native/towerc "$b/obs/runtime/"; cp -a "$b/before/runtime/share" "$b/obs/runtime/"
for shape in small large; do
 /cache/ecs_process_profile /usr/bin/timeout 180 "$b/obs/runtime/towerc" "$b/reference/$shape.tower" --jobs 1 --emit object --timings --target x86_64-unknown-linux-gnu --bedrock "$b/source/scaffolding/bedrock.tower" --foundation "$b/source/scaffolding/foundation.tower" -o "$b/obs/$shape.o" >"$b/obs/$shape.out" 2>"$b/obs/$shape.log"
 cmp "$b/reference/$shape.reference.o" "$b/obs/$shape.o"
done